<?php
defined( 'ABSPATH' ) || exit;

class AWFTP_Session {

    const COOKIE_NAME   = 'awftp_session';
    const SESSION_HOURS = 8;

    public static function login( string $username, string $password ): array {
        $user = wp_authenticate( $username, $password );

        if ( is_wp_error( $user ) ) {
            return [ 'success' => false, 'error' => 'Usuario o contraseña incorrectos.' ];
        }

        $required_cap = apply_filters( 'awftp_required_capability', 'manage_options' );

        if ( ! user_can( $user, $required_cap ) ) {
            return [ 'success' => false, 'error' => 'Tu usuario no tiene permisos para acceder a WebFTP.' ];
        }

        $token = self::create_session( $user->ID );

        return [ 'success' => true, 'token' => $token, 'user' => $user->display_name ];
    }

    public static function create_session( int $user_id ): string {
        global $wpdb;

        $wpdb->delete( $wpdb->prefix . 'awftp_sessions', [ 'user_id' => $user_id ], [ '%d' ] );

        $token      = bin2hex( random_bytes( 32 ) );
        $expires_at = gmdate( 'Y-m-d H:i:s', time() + self::SESSION_HOURS * 3600 );

        $wpdb->insert(
            $wpdb->prefix . 'awftp_sessions',
            [ 'user_id' => $user_id, 'session_token' => $token, 'expires_at' => $expires_at ],
            [ '%d', '%s', '%s' ]
        );

        setcookie( self::COOKIE_NAME, $token, [
            'expires'  => time() + self::SESSION_HOURS * 3600,
            'path'     => '/wp-admin/',
            'secure'   => is_ssl(),
            'httponly' => true,
            'samesite' => 'Strict',
        ]);

        return $token;
    }

    public static function validate(): int|false {
        $token = $_COOKIE[ self::COOKIE_NAME ] ?? '';

        if ( empty( $token ) || strlen( $token ) !== 64 ) return false;

        global $wpdb;

        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT user_id, expires_at FROM {$wpdb->prefix}awftp_sessions WHERE session_token = %s LIMIT 1",
            sanitize_text_field( $token )
        ));

        if ( ! $row ) return false;

        if ( strtotime( $row->expires_at ) < time() ) {
            $wpdb->delete( $wpdb->prefix . 'awftp_sessions', [ 'session_token' => $token ], [ '%s' ] );
            return false;
        }

        $required_cap = apply_filters( 'awftp_required_capability', 'manage_options' );
        if ( ! user_can( (int) $row->user_id, $required_cap ) ) return false;

        return (int) $row->user_id;
    }

    public static function is_logged_in(): bool {
        return self::validate() !== false;
    }

    public static function logout(): void {
        $token = $_COOKIE[ self::COOKIE_NAME ] ?? '';

        if ( ! empty( $token ) ) {
            global $wpdb;
            $wpdb->delete( $wpdb->prefix . 'awftp_sessions', [ 'session_token' => sanitize_text_field( $token ) ], [ '%s' ] );
        }

        setcookie( self::COOKIE_NAME, '', [
            'expires'  => time() - 3600,
            'path'     => '/wp-admin/',
            'secure'   => is_ssl(),
            'httponly' => true,
            'samesite' => 'Strict',
        ]);
    }

    public static function get_current_user(): ?\WP_User {
        $user_id = self::validate();
        if ( ! $user_id ) return null;
        return get_user_by( 'id', $user_id ) ?: null;
    }

    public static function cleanup_expired(): void {
        global $wpdb;
        $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$wpdb->prefix}awftp_sessions WHERE expires_at < %s",
            gmdate( 'Y-m-d H:i:s' )
        ));
    }
}
