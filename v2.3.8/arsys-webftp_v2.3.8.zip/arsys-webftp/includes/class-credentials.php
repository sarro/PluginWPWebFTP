<?php
defined( 'ABSPATH' ) || exit;

class AWFTP_Credentials {

    const OPTION_KEY = 'awftp_sftp_credentials';

    public static function save( array $data ): void {
        $sanitized = [
            'host'      => sanitize_text_field( $data['host']      ?? '' ),
            'port'      => absint( $data['port'] ?? 22 ),
            'username'  => sanitize_text_field( $data['username']  ?? '' ),
            'password'  => $data['password'] ?? '',
            'root_path' => trailingslashit( sanitize_text_field( $data['root_path'] ?? '/' ) ),
        ];
        update_option( self::OPTION_KEY, base64_encode( wp_json_encode( $sanitized ) ), false );
    }

    public static function get(): array {
        $raw = get_option( self::OPTION_KEY, '' );
        if ( empty( $raw ) ) return [];
        $json = base64_decode( $raw, true );
        if ( false === $json ) return [];
        $data = json_decode( $json, true );
        return is_array( $data ) ? $data : [];
    }

    public static function has_credentials(): bool {
        $c = self::get();
        return ! empty( $c['host'] ) && ! empty( $c['username'] );
    }

    public static function delete(): void {
        delete_option( self::OPTION_KEY );
    }
}
