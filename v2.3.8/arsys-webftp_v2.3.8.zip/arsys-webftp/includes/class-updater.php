<?php
defined( 'ABSPATH' ) || exit;

/**
 * Sistema de auto-actualizacion desde GitHub Releases.
 *
 * Consulta: api.github.com/repos/sarro/PluginWPWebFTP/releases/latest
 * El ZIP adjunto a la release se usa como paquete de actualizacion.
 */
class AWFTP_Updater {

    const GITHUB_USER = 'sarro';
    const GITHUB_REPO = 'PluginWPWebFTP';
    const GITHUB_API  = 'https://api.github.com/repos/sarro/PluginWPWebFTP/releases/latest';
    const CACHE_TTL   = 43200; // 12 horas
    const CACHE_KEY   = 'awftp_github_release';

    private string $basename;
    private string $slug;
    private string $current_version;

    public function __construct( string $basename, string $current_version ) {
        $this->basename        = $basename;                // arsys-webftp/arsys-webftp.php
        $this->slug            = dirname( $basename );     // arsys-webftp
        $this->current_version = $current_version;
    }

    // ── Init ──────────────────────────────────────────────────────────────────

    public static function init(): void {
        $instance = new self( AWFTP_BASENAME, AWFTP_VERSION );

        add_filter( 'pre_set_site_transient_update_plugins', [ $instance, 'check_for_update' ] );
        add_filter( 'plugins_api',                           [ $instance, 'plugin_info'      ], 20, 3 );
        add_action( 'upgrader_process_complete',             [ $instance, 'clear_cache'      ], 10, 2 );

        // Fix descarga: headers correctos para GitHub durante actualizacion
        add_filter( 'upgrader_pre_download', [ $instance, 'fix_github_download' ], 10, 3 );

        // Boton de forzar comprobacion desde Configuracion
        add_action( 'admin_post_awftp_force_update_check',   [ self::class, 'force_check' ] );
    }

    // ── Comprobar actualizacion ───────────────────────────────────────────────

    public function check_for_update( $transient ) {
        if ( empty( $transient->checked ) ) return $transient;

        $release = $this->get_latest_release();
        if ( ! $release ) return $transient;

        $latest = ltrim( $release['tag_name'], 'v' );

        if ( version_compare( $latest, $this->current_version, '>' ) ) {
            $download_url = $this->get_download_url( $release );
            if ( $download_url ) {
                $transient->response[ $this->basename ] = (object) [
                    'id'           => $this->basename,
                    'slug'         => $this->slug,
                    'plugin'       => $this->basename,
                    'new_version'  => $latest,
                    'url'          => 'https://github.com/' . self::GITHUB_USER . '/' . self::GITHUB_REPO,
                    'package'      => $download_url,
                    'icons'        => [],
                    'banners'      => [],
                    'requires_php' => '7.4',
                    'tested'       => '6.5',
                ];
            }
        } else {
            // Informar a WP que el plugin esta actualizado
            if ( isset( $transient->no_update ) ) {
                $transient->no_update[ $this->basename ] = (object) [
                    'id'          => $this->basename,
                    'slug'        => $this->slug,
                    'plugin'      => $this->basename,
                    'new_version' => $this->current_version,
                    'url'         => 'https://github.com/' . self::GITHUB_USER . '/' . self::GITHUB_REPO,
                    'package'     => '',
                ];
            }
        }

        return $transient;
    }

    // ── Info del plugin (modal Ver detalles) ──────────────────────────────────

    public function plugin_info( $result, string $action, $args ) {
        if ( $action !== 'plugin_information' ) return $result;
        if ( ! isset( $args->slug ) || $args->slug !== $this->slug ) return $result;

        $release = $this->get_latest_release();
        if ( ! $release ) return $result;

        $latest       = ltrim( $release['tag_name'], 'v' );
        $download_url = $this->get_download_url( $release );
        $changelog    = $this->format_changelog( $release['body'] ?? '' );

        return (object) [
            'name'          => 'Arsys WebFTP',
            'slug'          => $this->slug,
            'version'       => $latest,
            'author'        => '<a href="https://www.arsys.es">Arsys (IONOS Group)</a>',
            'homepage'      => 'https://github.com/' . self::GITHUB_USER . '/' . self::GITHUB_REPO,
            'requires'      => '6.0',
            'tested'        => '6.5',
            'requires_php'  => '7.4',
            'last_updated'  => $release['published_at'] ?? '',
            'sections'      => [
                'description' => 'Explorador SFTP integrado en WordPress con autenticacion de usuario WordPress.',
                'changelog'   => $changelog,
            ],
            'download_link' => $download_url,
        ];
    }

    // ── Limpiar cache ─────────────────────────────────────────────────────────

    public function clear_cache( $upgrader, array $hook_extra ): void {
        if (
            isset( $hook_extra['type'], $hook_extra['plugins'] ) &&
            $hook_extra['type'] === 'plugin' &&
            in_array( $this->basename, $hook_extra['plugins'], true )
        ) {
            delete_transient( self::CACHE_KEY );
        }
    }

    // ── Fix descarga desde GitHub ────────────────────────────────────────────────

    /**
     * Intercepta la descarga del paquete de actualizacion.
     * Si es nuestro plugin, descarga el ZIP con headers correctos para GitHub.
     * Esto evita el error "No se ha podido descomprimir el paquete".
     */
    public function fix_github_download( $reply, string $package, $upgrader ) {
        // Solo actuar si es nuestro plugin
        if ( strpos( $package, 'github.com' ) === false && strpos( $package, 'githubusercontent.com' ) === false ) {
            return $reply;
        }

        // Verificar que es nuestro paquete
        if ( strpos( $package, self::GITHUB_USER . '/' . self::GITHUB_REPO ) === false &&
             strpos( $package, self::GITHUB_USER ) === false ) {
            return $reply;
        }

        // Descargar con headers correctos
        $response = wp_remote_get( $package, [
            'timeout'    => 60,
            'stream'     => true,
            'filename'   => wp_tempnam( $package ),
            'redirection'=> 5,
            'headers'    => [
                'Accept'     => 'application/octet-stream',
                'User-Agent' => 'ArsysWebFTP/' . AWFTP_VERSION . '; WordPress/' . get_bloginfo('version'),
            ],
        ]);

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $tmp_file = $response['filename'] ?? '';
        if ( empty( $tmp_file ) || ! file_exists( $tmp_file ) ) {
            return new \WP_Error( 'awftp_download_failed', 'No se pudo descargar el paquete desde GitHub.' );
        }

        return $tmp_file;
    }

    // ── Forzar comprobacion desde panel ───────────────────────────────────────

    public static function force_check(): void {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'No autorizado.' );
        check_admin_referer( 'awftp_force_check' );
        delete_transient( self::CACHE_KEY );
        delete_site_transient( 'update_plugins' );
        wp_redirect( admin_url( 'admin.php?page=arsys-webftp-settings&tab=sftp&update_checked=1' ) );
        exit;
    }

    // ── API GitHub ────────────────────────────────────────────────────────────

    private function get_latest_release(): ?array {
        $cached = get_transient( self::CACHE_KEY );
        if ( false !== $cached ) return $cached;

        $response = wp_remote_get( self::GITHUB_API, [
            'timeout' => 15,
            'headers' => [
                'Accept'     => 'application/vnd.github.v3+json',
                'User-Agent' => 'ArsysWebFTP/' . AWFTP_VERSION . '; WordPress/' . get_bloginfo('version'),
            ],
        ]);

        if ( is_wp_error( $response ) ) return null;
        if ( wp_remote_retrieve_response_code( $response ) !== 200 ) return null;

        $release = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( ! is_array( $release ) || empty( $release['tag_name'] ) ) return null;

        set_transient( self::CACHE_KEY, $release, self::CACHE_TTL );
        return $release;
    }

    private function get_download_url( array $release ): ?string {
        // Buscar ZIP adjunto en assets
        if ( ! empty( $release['assets'] ) ) {
            foreach ( $release['assets'] as $asset ) {
                if (
                    isset( $asset['browser_download_url'] ) &&
                    strtolower( pathinfo( $asset['name'], PATHINFO_EXTENSION ) ) === 'zip'
                ) {
                    return $asset['browser_download_url'];
                }
            }
        }
        // Fallback: zipball automatico de GitHub
        return $release['zipball_url'] ?? null;
    }

    private function format_changelog( string $text ): string {
        if ( empty( $text ) ) return '<p>Sin notas de version.</p>';
        $html = esc_html( $text );
        $html = preg_replace( '/^### (.+)$/m', '<h4>$1</h4>', $html );
        $html = preg_replace( '/^## (.+)$/m',  '<h3>$1</h3>', $html );
        $html = preg_replace( '/^# (.+)$/m',   '<h2>$1</h2>', $html );
        $html = preg_replace( '/^[\*\-] (.+)$/m', '<li>$1</li>', $html );
        $html = preg_replace( '/(<li>.*?<\/li>(\n|$))+/s', '<ul>$0</ul>', $html );
        $html = preg_replace( '/`([^`]+)`/', '<code>$1</code>', $html );
        return nl2br( $html );
    }
}
