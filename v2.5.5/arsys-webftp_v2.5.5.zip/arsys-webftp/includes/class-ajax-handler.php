<?php
defined( 'ABSPATH' ) || exit;

class AWFTP_Ajax_Handler {

    public static function init(): void {
        $actions = [
            'awftp_login', 'awftp_logout',
            'awftp_list_directory', 'awftp_get_file', 'awftp_save_file',
            'awftp_upload_file', 'awftp_delete', 'awftp_rename',
            'awftp_create_folder', 'awftp_create_file',
            'awftp_download_file', 'awftp_test_connection',
            'awftp_search',
            'awftp_get_log', 'awftp_clear_log', 'awftp_save_upload_security',
        ];
        foreach ( $actions as $action ) {
            add_action( 'wp_ajax_'        . $action, [ self::class, 'dispatch' ] );
            add_action( 'wp_ajax_nopriv_' . $action, [ self::class, 'dispatch' ] );
        }
    }

    public static function dispatch(): void {
        $action = sanitize_text_field( $_REQUEST['action'] ?? '' );

        if ( $action === 'awftp_login' ) {
            self::verify_nonce( 'awftp_login_nonce' );
            self::handle_login();
            return;
        }

        self::verify_nonce( 'awftp_nonce' );

        if ( $action === 'awftp_logout' )       { self::handle_logout();                           return; }
        if ( $action === 'awftp_download_file' ) { self::require_session(); self::handle_download(); return; }

        self::require_session();

        try {
            switch ( $action ) {
                case 'awftp_list_directory': self::handle_list_directory(); break;
                case 'awftp_get_file':       self::handle_get_file();       break;
                case 'awftp_save_file':      self::handle_save_file();      break;
                case 'awftp_upload_file':    self::handle_upload_file();    break;
                case 'awftp_delete':         self::handle_delete();         break;
                case 'awftp_rename':         self::handle_rename();         break;
                case 'awftp_create_folder':  self::handle_create_folder();  break;
                case 'awftp_create_file':    self::handle_create_file();    break;
                case 'awftp_test_connection':self::handle_test_connection(); break;
                case 'awftp_search':         self::handle_search();         break;
                case 'awftp_get_log':        self::handle_get_log();        break;
                case 'awftp_clear_log':         self::handle_clear_log();           break;
                case 'awftp_save_upload_security': self::handle_save_upload_security(); break;
                default: wp_send_json_error( [ 'message' => 'Accion desconocida.' ], 400 );
            }
        } catch ( \RuntimeException $e ) {
            wp_send_json_error( [ 'message' => $e->getMessage() ] );
        } catch ( \Exception $e ) {
            wp_send_json_error( [ 'message' => 'Error interno: ' . $e->getMessage() ] );
        }
    }

    private static function handle_login(): void {
        $username = sanitize_text_field( $_POST['username'] ?? '' );
        $password = $_POST['password'] ?? '';
        if ( empty( $username ) || empty( $password ) ) {
            wp_send_json_error( [ 'message' => 'Introduce usuario y contrasena.' ] );
        }
        $result = AWFTP_Session::login( $username, $password );
        if ( $result['success'] ) {
            AWFTP_Activity_Log::log( AWFTP_Activity_Log::ACTION_LOGIN, '', $username );
            wp_send_json_success( [ 'message' => 'Bienvenido, ' . esc_html( $result['user'] ) . '!', 'reload' => true ] );
        } else {
            wp_send_json_error( [ 'message' => $result['error'] ] );
        }
    }

    private static function handle_logout(): void {
        AWFTP_Activity_Log::log( AWFTP_Activity_Log::ACTION_LOGOUT );
        AWFTP_Session::logout();
        wp_send_json_success( [ 'message' => 'Sesion cerrada.', 'reload' => true ] );
    }

    private static function handle_list_directory(): void {
        $path  = self::param( 'path', '/' );
        $items = AWFTP_SFTP_Manager::connect()->list_directory( $path );
        AWFTP_Activity_Log::log( AWFTP_Activity_Log::ACTION_LIST, $path );
        wp_send_json_success( [ 'items' => $items, 'path' => $path ] );
    }

    private static function handle_get_file(): void {
        $path = self::param( 'path' );
        $sftp = AWFTP_SFTP_Manager::connect();

        // Comprobar limite de tamano antes de descargar (OWASP A05)
        // Solo actua si el limite esta activado en Configuracion -> Seguridad
        if ( AWFTP_Upload_Security::is_max_edit_enabled() ) {
            $items = $sftp->list_directory( dirname( $path ) );
            $filename = basename( $path );
            foreach ( $items as $item ) {
                if ( $item['name'] === $filename && $item['type'] === 'file' ) {
                    if ( ! AWFTP_Upload_Security::can_edit_file( (int) $item['size'] ) ) {
                        $max_mb = AWFTP_Upload_Security::get_max_edit_mb();
                        throw new \RuntimeException(
                            "El archivo supera el limite de edicion ({$max_mb} MB). Descargalo para editarlo localmente."
                        );
                    }
                    break;
                }
            }
        }

        $content = $sftp->get_file( $path );
        AWFTP_Activity_Log::log( AWFTP_Activity_Log::ACTION_EDIT, $path );
        wp_send_json_success( [ 'content' => $content, 'path' => $path ] );
    }

    private static function handle_save_file(): void {
        $path    = self::param( 'path' );
        $content = wp_unslash( $_POST['content'] ?? '' );
        AWFTP_SFTP_Manager::connect()->put_file( $path, $content );
        AWFTP_Activity_Log::log( AWFTP_Activity_Log::ACTION_EDIT, $path, 'guardado' );
        AWFTP_Session::rotate_token(); // Rotar token tras guardar archivo
        wp_send_json_success( [ 'message' => 'Archivo guardado correctamente.' ] );
    }

    private static function handle_upload_file(): void {
        if ( empty( $_FILES['file'] ) ) throw new \RuntimeException( 'No se recibio ningun archivo.' );
        $dir  = self::param( 'path', '/' );
        $sftp = AWFTP_SFTP_Manager::connect();
        $files= self::normalize_files( $_FILES['file'] );
        $ok   = []; $errs = [];
        foreach ( $files as $file ) {
            if ( $file['error'] !== UPLOAD_ERR_OK ) { $errs[] = $file['name'] . ': error.'; continue; }

            // Validacion de seguridad MIME/extension (OWASP A03)
            // Solo actua si la lista negra esta activada en Configuracion
            $validation = AWFTP_Upload_Security::validate( $file['name'], $file['tmp_name'] );
            if ( ! $validation['valid'] ) {
                $errs[] = $validation['error'];
                continue;
            }

            $remote = rtrim( $dir, '/' ) . '/' . basename( $file['name'] );
            try {
                $sftp->upload_file( $remote, $file['tmp_name'] );
                $ok[] = $file['name'];
                AWFTP_Activity_Log::log( AWFTP_Activity_Log::ACTION_UPLOAD, $remote );
            } catch ( \Exception $e ) {
                $errs[] = $file['name'] . ': ' . $e->getMessage();
            }
        }
        if ( empty( $ok ) && ! empty( $errs ) ) throw new \RuntimeException( implode( ' | ', $errs ) );
        wp_send_json_success( [ 'message' => count( $ok ) . ' archivo(s) subido(s).', 'uploaded' => $ok, 'errors' => $errs ] );
    }

    private static function handle_delete(): void {
        $path = self::param( 'path' );
        AWFTP_SFTP_Manager::connect()->delete( $path );
        AWFTP_Activity_Log::log( AWFTP_Activity_Log::ACTION_DELETE, $path );
        AWFTP_Session::rotate_token(); // Rotar token tras operacion destructiva
        wp_send_json_success( [ 'message' => 'Eliminado correctamente.' ] );
    }

    private static function handle_rename(): void {
        $old      = self::param( 'old_path' );
        $new_name = sanitize_text_field( self::param( 'new_name' ) );
        if ( empty( $new_name ) ) throw new \RuntimeException( 'Nombre vacio.' );
        $dir = dirname( $old );
        $new = ( $dir === '.' ? '' : $dir ) . '/' . $new_name;
        AWFTP_SFTP_Manager::connect()->rename( $old, $new );
        AWFTP_Activity_Log::log( AWFTP_Activity_Log::ACTION_RENAME, $old, '> ' . $new_name );
        wp_send_json_success( [ 'message' => 'Renombrado correctamente.' ] );
    }

    private static function handle_create_folder(): void {
        $parent = self::param( 'path', '/' );
        $name   = sanitize_text_field( self::param( 'name' ) );
        if ( empty( $name ) ) throw new \RuntimeException( 'Nombre vacio.' );
        $full = rtrim( $parent, '/' ) . '/' . $name;
        AWFTP_SFTP_Manager::connect()->create_directory( $full );
        AWFTP_Activity_Log::log( AWFTP_Activity_Log::ACTION_CREATE_DIR, $full );
        wp_send_json_success( [ 'message' => 'Carpeta creada.' ] );
    }

    private static function handle_create_file(): void {
        $parent = self::param( 'path', '/' );
        $name   = sanitize_text_field( self::param( 'name' ) );
        if ( empty( $name ) ) throw new \RuntimeException( 'Nombre vacio.' );
        $full = rtrim( $parent, '/' ) . '/' . $name;
        AWFTP_SFTP_Manager::connect()->create_file( $full, '' );
        AWFTP_Activity_Log::log( AWFTP_Activity_Log::ACTION_CREATE_FILE, $full );
        wp_send_json_success( [ 'message' => 'Archivo creado.' ] );
    }

    private static function handle_download(): void {
        $path = self::param( 'path' );
        if ( empty( $path ) ) wp_die( 'Ruta no especificada.' );
        $content   = AWFTP_SFTP_Manager::connect()->get_file( $path );
        $filename  = basename( $path );
        $safe_name = preg_replace( '/[^a-zA-Z0-9_\-\. ]/', '_', $filename );
        AWFTP_Activity_Log::log( AWFTP_Activity_Log::ACTION_DOWNLOAD, $path );
        header( 'Content-Type: application/octet-stream' );
        header( 'Content-Disposition: attachment; filename="' . $safe_name . '"' );
        header( 'Content-Length: ' . strlen( $content ) );
        header( 'Cache-Control: no-cache, no-store, must-revalidate' );
        header( 'Pragma: no-cache' );
        header( 'Expires: 0' );
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo $content;
        exit;
    }

    private static function handle_test_connection(): void {
        $host = sanitize_text_field( $_POST['host'] ?? '' );
        $port = absint( $_POST['port'] ?? 22 );
        $user = sanitize_text_field( $_POST['username'] ?? '' );
        $pass = $_POST['password'] ?? '';
        if ( empty( $host ) || empty( $user ) ) throw new \RuntimeException( 'Host y usuario son obligatorios.' );
        $sftp = AWFTP_SFTP_Manager::connect_with( $host, $port, $user, $pass, '/' );
        wp_send_json_success( [ 'message' => 'Conexion exitosa. Directorio raiz: ' . $sftp->pwd() ] );
    }

    private static function handle_search(): void {
        $query     = sanitize_text_field( self::param( 'query' ) );
        $base_path = self::param( 'path', '/' );
        if ( strlen( $query ) < 2 ) {
            throw new \RuntimeException( 'Introduce al menos 2 caracteres para buscar.' );
        }
        $sftp = AWFTP_SFTP_Manager::connect();

        // Calcular tiempo limite (OWASP A05)
        // Solo actua si el timeout esta activado en Configuracion -> Seguridad
        $deadline = AWFTP_Upload_Security::is_search_timeout_enabled()
            ? time() + AWFTP_Upload_Security::get_search_timeout_secs()
            : 0; // 0 = sin limite

        $results   = self::search_recursive( $sftp, $base_path, $query, 0, $deadline );
        $truncated = isset( $results['_truncated'] ) ? $results['_truncated'] : false;
        if ( $truncated ) unset( $results['_truncated'] );

        AWFTP_Activity_Log::log( AWFTP_Activity_Log::ACTION_SEARCH, $base_path, 'query: ' . $query );
        wp_send_json_success( [
            'results'   => $results,
            'count'     => count( $results ),
            'query'     => $query,
            'truncated' => $truncated, // aviso al frontend si la busqueda fue cortada por timeout
        ]);
    }

    private static function search_recursive( AWFTP_SFTP_Manager $sftp, string $path, string $query, int $depth, int $deadline = 0 ): array {
        if ( $depth > 3 ) return [];

        // Comprobar timeout si esta activado
        if ( $deadline > 0 && time() >= $deadline ) {
            return [ '_truncated' => true ];
        }

        $results = [];
        try {
            $items = $sftp->list_directory( $path );
        } catch ( \Exception $e ) {
            return [];
        }
        foreach ( $items as $item ) {
            if ( count( $results ) >= 200 ) break;

            // Comprobar timeout en cada iteracion
            if ( $deadline > 0 && time() >= $deadline ) {
                $results['_truncated'] = true;
                break;
            }

            if ( stripos( $item['name'], $query ) !== false ) {
                $results[] = array_merge( $item, [
                    'full_path' => rtrim( $path, '/' ) . '/' . $item['name'],
                    'directory' => $path,
                ]);
            }
            if ( $item['type'] === 'dir' ) {
                $sub = self::search_recursive( $sftp, rtrim( $path, '/' ) . '/' . $item['name'], $query, $depth + 1, $deadline );
                // Propagar flag de truncado si viene de recursion
                if ( isset( $sub['_truncated'] ) ) {
                    $results['_truncated'] = true;
                    unset( $sub['_truncated'] );
                }
                $results = array_merge( $results, $sub );
            }
        }
        return $results;
    }

    private static function handle_get_log(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Acceso no autorizado.' ], 403 );
        }
        $page    = max( 1, (int) self::param( 'page', '1' ) );
        $limit   = 50;
        $entries = AWFTP_Activity_Log::get_entries( [
            'limit'     => $limit,
            'offset'    => ( $page - 1 ) * $limit,
            'action'    => self::param( 'filter_action' ),
            'username'  => self::param( 'filter_user' ),
            'date_from' => self::param( 'date_from' ),
            'date_to'   => self::param( 'date_to' ),
        ]);
        $total = AWFTP_Activity_Log::count_entries();
        wp_send_json_success( [
            'entries' => $entries,
            'total'   => $total,
            'page'    => $page,
            'pages'   => (int) ceil( $total / $limit ),
        ]);
    }

    private static function handle_clear_log(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Acceso no autorizado.' ], 403 );
        }
        AWFTP_Activity_Log::clear();
        wp_send_json_success( [ 'message' => 'Log vaciado correctamente.' ] );
    }

    private static function handle_save_upload_security(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Acceso no autorizado.' ], 403 );
        }
        AWFTP_Upload_Security::save_all_settings([
            'blacklist_enabled'      => $_POST['blacklist_enabled']      ?? false,
            'extensions'             => sanitize_textarea_field( $_POST['extensions'] ?? '' ),
            'max_edit_enabled'       => $_POST['max_edit_enabled']       ?? false,
            'max_edit_mb'            => $_POST['max_edit_mb']            ?? 2,
            'search_timeout_enabled' => $_POST['search_timeout_enabled'] ?? false,
            'search_timeout_secs'    => $_POST['search_timeout_secs']    ?? 10,
        ]);
        wp_send_json_success( [ 'message' => 'Configuracion de seguridad guardada.' ] );
    }

    private static function verify_nonce( string $action ): void {
        if ( ! wp_verify_nonce( sanitize_text_field( $_REQUEST['nonce'] ?? '' ), $action ) ) {
            wp_send_json_error( [ 'message' => 'Peticion no valida. Recarga la pagina.' ], 403 );
        }
    }

    private static function require_session(): void {
        if ( ! AWFTP_Session::is_logged_in() ) {
            wp_send_json_error( [ 'message' => 'Sesion expirada. Vuelve a iniciar sesion.', 'session_expired' => true ], 401 );
        }
    }

    private static function param( string $key, string $default = '' ): string {
        return wp_unslash( (string) ( $_REQUEST[ $key ] ?? $default ) );
    }

    private static function normalize_files( array $f ): array {
        if ( ! is_array( $f['name'] ) ) return [ $f ];
        $out = [];
        for ( $i = 0; $i < count( $f['name'] ); $i++ ) {
            $out[] = [ 'name' => $f['name'][$i], 'tmp_name' => $f['tmp_name'][$i], 'error' => $f['error'][$i], 'size' => $f['size'][$i] ];
        }
        return $out;
    }
}
