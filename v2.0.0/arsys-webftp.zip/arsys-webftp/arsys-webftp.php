<?php
/**
 * Plugin Name:       Arsys WebFTP
 * Plugin URI:        https://www.arsys.es
 * Description:       Explorador SFTP integrado en WordPress. Acceso protegido con login de usuario WordPress.
 * Version:           2.0.0
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            Arsys (IONOS Group)
 * License:           GPL-2.0+
 * Text Domain:       arsys-webftp
 */

defined( 'ABSPATH' ) || exit;

define( 'AWFTP_VERSION',  '2.0.0' );
define( 'AWFTP_DIR',      plugin_dir_path( __FILE__ ) );
define( 'AWFTP_URL',      plugin_dir_url( __FILE__ ) );
define( 'AWFTP_BASENAME', plugin_basename( __FILE__ ) );
define( 'AWFTP_VENDOR',   AWFTP_DIR . 'vendor/autoload.php' );

// ── Activación ───────────────────────────────────────────────────────────────
register_activation_hook( __FILE__, 'awftp_activate' );
function awftp_activate(): void {
    awftp_create_session_table();

    if ( ! file_exists( AWFTP_VENDOR ) ) {
        awftp_try_composer_install();
    }
}

function awftp_create_session_table(): void {
    global $wpdb;
    $table   = $wpdb->prefix . 'awftp_sessions';
    $charset = $wpdb->get_charset_collate();
    $sql     = "CREATE TABLE IF NOT EXISTS {$table} (
        id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id       BIGINT UNSIGNED NOT NULL,
        session_token VARCHAR(64)     NOT NULL,
        created_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        expires_at    DATETIME        NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY session_token (session_token),
        KEY user_id (user_id)
    ) {$charset};";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql );
}

function awftp_try_composer_install(): void {
    // Buscar composer en el sistema
    foreach ( [ 'composer', 'composer.phar', '/usr/local/bin/composer', '/usr/bin/composer' ] as $bin ) {
        $found = trim( (string) shell_exec( 'which ' . escapeshellarg( $bin ) . ' 2>/dev/null' ) );
        if ( $found && is_executable( $found ) ) {
            $cwd = getcwd();
            chdir( AWFTP_DIR );
            shell_exec( escapeshellcmd( $found ) . ' install --no-dev --optimize-autoloader --no-interaction 2>&1' );
            chdir( $cwd );
            return;
        }
    }
    // Si no hay composer, dejar aviso para que el admin instale manualmente
    update_option( 'awftp_dep_missing', 1 );
}

// ── Desactivación ────────────────────────────────────────────────────────────
register_deactivation_hook( __FILE__, 'awftp_deactivate' );
function awftp_deactivate(): void {
    global $wpdb;
    $wpdb->query( "DELETE FROM {$wpdb->prefix}awftp_sessions WHERE 1=1" );
}

// ── Cargar vendor (phpseclib3) ────────────────────────────────────────────────
add_action( 'plugins_loaded', function () {
    if ( file_exists( AWFTP_VENDOR ) ) {
        require_once AWFTP_VENDOR;
    }
}, 1 );

// ── Cargar clases del plugin ──────────────────────────────────────────────────
add_action( 'plugins_loaded', function () {
    // Aviso si faltan dependencias
    if ( ! file_exists( AWFTP_VENDOR ) ) {
        add_action( 'admin_notices', function () {
            echo '<div class="notice notice-error"><p>';
            echo '<strong>Arsys WebFTP:</strong> Faltan dependencias. ';
            echo 'Ejecuta <code>composer install --no-dev</code> en el directorio del plugin: ';
            echo '<code>' . esc_html( AWFTP_DIR ) . '</code>';
            echo '</p></div>';
        });
        return;
    }

    require_once AWFTP_DIR . 'includes/class-credentials.php';
    require_once AWFTP_DIR . 'includes/class-session.php';
    require_once AWFTP_DIR . 'includes/class-sftp-manager.php';
    require_once AWFTP_DIR . 'includes/class-admin-page.php';
    require_once AWFTP_DIR . 'includes/class-ajax-handler.php';

    AWFTP_Admin_Page::init();
    AWFTP_Ajax_Handler::init();
}, 10 );
