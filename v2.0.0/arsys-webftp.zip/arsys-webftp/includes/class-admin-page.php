<?php
defined( 'ABSPATH' ) || exit;

class AWFTP_Admin_Page {

    public static function init(): void {
        $self = new self();
        add_action( 'admin_menu',            [ $self, 'register_menu' ] );
        add_action( 'admin_enqueue_scripts', [ $self, 'enqueue_assets' ] );
        add_action( 'admin_post_awftp_save_credentials', [ $self, 'handle_save_credentials' ] );
        add_action( 'wp_scheduled_delete',   [ self::class, 'cleanup_sessions' ] );
    }

    // ── Menú ─────────────────────────────────────────────────────────────────

    public function register_menu(): void {
        add_menu_page(
            'Arsys WebFTP', 'WebFTP', 'read',
            'arsys-webftp', [ $this, 'render_page' ],
            'dashicons-portfolio', 80
        );
        add_submenu_page(
            'arsys-webftp', 'Explorador', 'Explorador',
            'read', 'arsys-webftp', [ $this, 'render_page' ]
        );
        add_submenu_page(
            'arsys-webftp', 'Configuración SFTP', 'Configuración',
            'manage_options', 'arsys-webftp-settings', [ $this, 'render_settings' ]
        );
    }

    // ── Assets ───────────────────────────────────────────────────────────────

    public function enqueue_assets( string $hook ): void {
        if ( strpos( $hook, 'arsys-webftp' ) === false ) return;

        wp_enqueue_style(
            'awftp-style',
            AWFTP_URL . 'assets/css/webftp.css',
            [], AWFTP_VERSION
        );

        wp_enqueue_script(
            'awftp-app',
            AWFTP_URL . 'assets/js/webftp.js',
            [ 'jquery' ], AWFTP_VERSION, true
        );

        wp_localize_script( 'awftp-app', 'AWFTP', [
            'ajax_url'    => admin_url( 'admin-ajax.php' ),
            'nonce'       => wp_create_nonce( 'awftp_nonce' ),
            'login_nonce' => wp_create_nonce( 'awftp_login_nonce' ),
            'logged_in'   => AWFTP_Session::is_logged_in() ? '1' : '0',
            'root'        => AWFTP_Credentials::get()['root_path'] ?? '/',
        ]);
    }

    // ── Router principal ─────────────────────────────────────────────────────

    public function render_page(): void {
        if ( ! AWFTP_Session::is_logged_in() ) {
            $this->render_login();
            return;
        }

        if ( ! AWFTP_Credentials::has_credentials() ) {
            echo '<div class="wrap">';
            echo '<div class="notice notice-warning"><p>';
            if ( current_user_can( 'manage_options' ) ) {
                echo 'WebFTP no está configurado. <a href="' . esc_url( admin_url( 'admin.php?page=arsys-webftp-settings' ) ) . '">Ir a Configuración →</a>';
            } else {
                echo 'WebFTP no está configurado. Contacta con el administrador.';
            }
            echo '</p></div></div>';
            return;
        }

        $this->render_explorer();
    }

    // ── Pantalla de login ─────────────────────────────────────────────────────

    private function render_login(): void {
        $current_wp_user = wp_get_current_user();
        ?>
        <div class="awftp-login-wrap">
            <div class="awftp-login-card" id="awftp-login-card">

                <div class="awftp-login-logo">
                    <span class="awftp-login-icon">⚡</span>
                    <h1>Arsys <strong>WebFTP</strong></h1>
                    <p class="awftp-login-sub">Explorador SFTP seguro</p>
                </div>

                <div id="awftp-login-error" class="awftp-login-error" style="display:none"></div>

                <div class="awftp-login-form">
                    <div class="awftp-field">
                        <label for="awftp-login-user">Usuario de WordPress</label>
                        <div class="awftp-input-wrap">
                            <span class="awftp-input-icon">👤</span>
                            <input
                                type="text"
                                id="awftp-login-user"
                                value="<?php echo esc_attr( $current_wp_user->user_login ?? '' ); ?>"
                                placeholder="usuario"
                                autocomplete="username"
                            />
                        </div>
                    </div>
                    <div class="awftp-field">
                        <label for="awftp-login-pass">Contraseña</label>
                        <div class="awftp-input-wrap">
                            <span class="awftp-input-icon">🔑</span>
                            <input
                                type="password"
                                id="awftp-login-pass"
                                placeholder="••••••••"
                                autocomplete="current-password"
                            />
                        </div>
                    </div>
                    <button id="awftp-login-btn" class="awftp-login-submit">
                        <span class="awftp-login-btn-text">Acceder al explorador</span>
                        <span class="awftp-login-spinner" style="display:none"><span class="awftp-spinner"></span></span>
                    </button>
                </div>

                <p class="awftp-login-note">
                    🔒 Usa tu usuario y contraseña de WordPress.<br>
                    <small>Solo administradores pueden acceder.</small>
                </p>

            </div>
        </div>
        <?php
    }

    // ── Explorador de archivos ────────────────────────────────────────────────

    private function render_explorer(): void {
        $wftp_user = AWFTP_Session::get_current_user();
        ?>
        <div class="wrap awftp-wrap">

            <h1 class="awftp-title">
                <span class="awftp-logo">⚡</span>
                Arsys WebFTP
                <span class="awftp-badge">SFTP</span>
                <span class="awftp-user-info">
                    👤 <?php echo esc_html( $wftp_user ? $wftp_user->display_name : '' ); ?>
                    <button id="awftp-logout-btn" class="button button-small">🚪 Cerrar sesión</button>
                </span>
            </h1>

            <div id="awftp-app">

                <!-- Toolbar -->
                <div class="awftp-toolbar">
                    <div class="awftp-path-bar">
                        <span class="awftp-path-label">📁</span>
                        <input type="text" id="awftp-current-path" readonly value="/" />
                        <button id="awftp-btn-up">↑ Subir</button>
                        <button id="awftp-btn-refresh">↻ Recargar</button>
                    </div>
                    <div class="awftp-actions">
                        <button id="awftp-btn-new-folder" class="button button-secondary">📁 Nueva carpeta</button>
                        <button id="awftp-btn-new-file"   class="button button-secondary">📄 Nuevo archivo</button>
                        <label class="button button-primary" id="awftp-upload-label">
                            ⬆ Subir archivo
                            <input type="file" id="awftp-upload-input" multiple style="display:none" />
                        </label>
                    </div>
                </div>

                <!-- Barra de progreso de subida -->
                <div id="awftp-upload-progress" style="display:none">
                    <div class="awftp-progress-bar">
                        <div class="awftp-progress-fill" id="awftp-progress-fill"></div>
                    </div>
                    <span id="awftp-progress-text">Subiendo...</span>
                </div>

                <!-- Tabla de archivos -->
                <div class="awftp-explorer">
                    <table class="awftp-table wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th class="col-icon"></th>
                                <th class="col-name">Nombre</th>
                                <th class="col-size">Tamaño</th>
                                <th class="col-date">Modificado</th>
                                <th class="col-perms">Permisos</th>
                                <th class="col-actions">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="awftp-file-list">
                            <tr>
                                <td colspan="6" class="awftp-loading">
                                    <span class="awftp-spinner"></span> Cargando...
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

            </div><!-- /#awftp-app -->

            <?php $this->render_modals(); ?>

            <div id="awftp-overlay" class="awftp-overlay" style="display:none"></div>
            <div id="awftp-notifications"></div>

        </div><!-- /.wrap -->
        <?php
    }

    // ── Modales ───────────────────────────────────────────────────────────────

    private function render_modals(): void {
        ?>
        <!-- Modal: Editor de texto -->
        <div id="awftp-modal-editor" class="awftp-modal" style="display:none">
            <div class="awftp-modal-content awftp-modal-large">
                <div class="awftp-modal-header">
                    <h2>✏️ Editar: <span id="awftp-editor-filename"></span></h2>
                    <button class="awftp-modal-close" data-modal="awftp-modal-editor">✕</button>
                </div>
                <div class="awftp-modal-body">
                    <textarea id="awftp-editor-content" spellcheck="false"></textarea>
                </div>
                <div class="awftp-modal-footer">
                    <button id="awftp-btn-save-file" class="button button-primary">💾 Guardar</button>
                    <button class="button awftp-modal-close" data-modal="awftp-modal-editor">Cancelar</button>
                </div>
            </div>
        </div>

        <!-- Modal: Renombrar -->
        <div id="awftp-modal-rename" class="awftp-modal" style="display:none">
            <div class="awftp-modal-content">
                <div class="awftp-modal-header">
                    <h2>✏️ Renombrar</h2>
                    <button class="awftp-modal-close" data-modal="awftp-modal-rename">✕</button>
                </div>
                <div class="awftp-modal-body">
                    <label>Nuevo nombre:</label>
                    <input type="text" id="awftp-rename-input" class="regular-text" />
                    <input type="hidden" id="awftp-rename-old" />
                </div>
                <div class="awftp-modal-footer">
                    <button id="awftp-btn-confirm-rename" class="button button-primary">Renombrar</button>
                    <button class="button awftp-modal-close" data-modal="awftp-modal-rename">Cancelar</button>
                </div>
            </div>
        </div>

        <!-- Modal: Nueva carpeta / archivo -->
        <div id="awftp-modal-new" class="awftp-modal" style="display:none">
            <div class="awftp-modal-content">
                <div class="awftp-modal-header">
                    <h2 id="awftp-modal-new-title">Crear nuevo</h2>
                    <button class="awftp-modal-close" data-modal="awftp-modal-new">✕</button>
                </div>
                <div class="awftp-modal-body">
                    <label id="awftp-modal-new-label">Nombre:</label>
                    <input type="text" id="awftp-new-name-input" class="regular-text" />
                    <input type="hidden" id="awftp-new-type" value="folder" />
                </div>
                <div class="awftp-modal-footer">
                    <button id="awftp-btn-confirm-new" class="button button-primary">Crear</button>
                    <button class="button awftp-modal-close" data-modal="awftp-modal-new">Cancelar</button>
                </div>
            </div>
        </div>

        <!-- Modal: Confirmar eliminación -->
        <div id="awftp-modal-delete" class="awftp-modal" style="display:none">
            <div class="awftp-modal-content">
                <div class="awftp-modal-header">
                    <h2>🗑 Confirmar eliminación</h2>
                    <button class="awftp-modal-close" data-modal="awftp-modal-delete">✕</button>
                </div>
                <div class="awftp-modal-body">
                    <p>¿Eliminar <strong id="awftp-delete-name"></strong>?</p>
                    <p class="awftp-warning">⚠️ Esta acción no se puede deshacer.</p>
                    <input type="hidden" id="awftp-delete-path" />
                </div>
                <div class="awftp-modal-footer">
                    <button id="awftp-btn-confirm-delete" class="button button-primary awftp-btn-danger">Eliminar</button>
                    <button class="button awftp-modal-close" data-modal="awftp-modal-delete">Cancelar</button>
                </div>
            </div>
        </div>
        <?php
    }

    // ── Página de configuración ───────────────────────────────────────────────

    public function render_settings(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Acceso no autorizado.' );
        }

        $creds = AWFTP_Credentials::get();
        $saved = isset( $_GET['saved'] );
        ?>
        <div class="wrap">
            <h1>⚙️ Configuración SFTP — Arsys WebFTP</h1>

            <?php if ( $saved ) : ?>
                <div class="notice notice-success is-dismissible">
                    <p>✅ Credenciales guardadas correctamente.</p>
                </div>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <?php wp_nonce_field( 'awftp_save_credentials', 'awftp_credentials_nonce' ); ?>
                <input type="hidden" name="action" value="awftp_save_credentials" />

                <table class="form-table" role="presentation">
                    <tr>
                        <th><label for="awftp_host">Host SFTP</label></th>
                        <td>
                            <input type="text" name="awftp_host" id="awftp_host" class="regular-text"
                                value="<?php echo esc_attr( $creds['host'] ?? '' ); ?>"
                                placeholder="sftp.arsys.es" required />
                            <p class="description">Hostname del servidor SFTP (sin protocolo).</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="awftp_port">Puerto</label></th>
                        <td>
                            <input type="number" name="awftp_port" id="awftp_port" class="small-text"
                                value="<?php echo esc_attr( $creds['port'] ?? 22 ); ?>"
                                min="1" max="65535" />
                        </td>
                    </tr>
                    <tr>
                        <th><label for="awftp_username">Usuario SFTP</label></th>
                        <td>
                            <input type="text" name="awftp_username" id="awftp_username" class="regular-text"
                                value="<?php echo esc_attr( $creds['username'] ?? '' ); ?>"
                                autocomplete="off" required />
                        </td>
                    </tr>
                    <tr>
                        <th><label for="awftp_password">Contraseña SFTP</label></th>
                        <td>
                            <input type="password" name="awftp_password" id="awftp_password" class="regular-text"
                                value="" autocomplete="new-password" />
                            <p class="description">Déjala en blanco para mantener la guardada.</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="awftp_root_path">Directorio raíz</label></th>
                        <td>
                            <input type="text" name="awftp_root_path" id="awftp_root_path" class="regular-text"
                                value="<?php echo esc_attr( $creds['root_path'] ?? '/' ); ?>"
                                placeholder="/home/usuario/public_html" />
                            <p class="description">Ruta base de navegación. Por defecto: <code>/</code></p>
                        </td>
                    </tr>
                </table>

                <h2>Prueba de conexión</h2>
                <p>
                    <button type="button" id="awftp-test-connection" class="button button-secondary">
                        🔌 Probar conexión SFTP
                    </button>
                    <span id="awftp-test-result" style="margin-left:12px;font-weight:600;"></span>
                </p>

                <?php submit_button( '💾 Guardar credenciales' ); ?>
            </form>

            <hr />

            <h2>Usuarios con acceso</h2>
            <p>Pueden acceder a WebFTP los usuarios con rol <strong>Administrador</strong>:</p>
            <ul>
                <?php
                $admins = get_users( [ 'role' => 'administrator', 'fields' => [ 'display_name', 'user_login' ] ] );
                foreach ( $admins as $u ) {
                    printf(
                        '<li>👤 <strong>%s</strong> <code>(%s)</code></li>',
                        esc_html( $u->display_name ),
                        esc_html( $u->user_login )
                    );
                }
                ?>
            </ul>
        </div>

        <script>
        jQuery(function($){
            $('#awftp-test-connection').on('click', function(){
                var $btn = $(this), $r = $('#awftp-test-result');
                $btn.prop('disabled', true).text('Conectando...');
                $r.text('').css('color', '');
                $.post(ajaxurl, {
                    action:   'awftp_test_connection',
                    nonce:    '<?php echo wp_create_nonce( "awftp_nonce" ); ?>',
                    host:     $('#awftp_host').val(),
                    port:     $('#awftp_port').val(),
                    username: $('#awftp_username').val(),
                    password: $('#awftp_password').val(),
                }, function(res){
                    if (res.success) $r.text('✅ ' + res.data.message).css('color', '#057a55');
                    else             $r.text('❌ ' + res.data.message).css('color', '#e02424');
                }).always(function(){
                    $btn.prop('disabled', false).text('🔌 Probar conexión SFTP');
                });
            });
        });
        </script>
        <?php
    }

    // ── Handler: guardar credenciales ─────────────────────────────────────────

    public function handle_save_credentials(): void {
        check_admin_referer( 'awftp_save_credentials', 'awftp_credentials_nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Acceso no autorizado.' );
        }

        $existing = AWFTP_Credentials::get();
        $password = $_POST['awftp_password'] ?? '';

        // Mantener contraseña existente si no se envía una nueva
        if ( empty( $password ) && ! empty( $existing['password'] ) ) {
            $password = $existing['password'];
        }

        AWFTP_Credentials::save([
            'host'      => sanitize_text_field( $_POST['awftp_host']      ?? '' ),
            'port'      => absint( $_POST['awftp_port'] ?? 22 ),
            'username'  => sanitize_text_field( $_POST['awftp_username']  ?? '' ),
            'password'  => $password,
            'root_path' => sanitize_text_field( $_POST['awftp_root_path'] ?? '/' ),
        ]);

        wp_redirect( admin_url( 'admin.php?page=arsys-webftp-settings&saved=1' ) );
        exit;
    }

    // ── Limpieza de sesiones expiradas ────────────────────────────────────────

    public static function cleanup_sessions(): void {
        AWFTP_Session::cleanup_expired();
    }
}
