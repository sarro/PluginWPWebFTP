<?php
defined( 'ABSPATH' ) || exit;

use phpseclib3\Net\SFTP;

/**
 * Capa de abstracción sobre phpseclib3\Net\SFTP.
 *
 * Todas las rutas que entran son normalizadas y validadas
 * contra path traversal antes de ejecutar cualquier operación.
 */
class AWFTP_SFTP_Manager {

    private SFTP   $sftp;
    private string $root;

    public function __construct( SFTP $sftp, string $root = '/' ) {
        $this->sftp = $sftp;
        $this->root = rtrim( $root, '/' );
    }

    // ── Conexión estática ────────────────────────────────────────────────────

    /**
     * Crea una instancia conectada usando las credenciales guardadas.
     *
     * @throws \RuntimeException si la conexión o autenticación fallan.
     */
    public static function connect(): self {
        $creds = AWFTP_Credentials::get();

        if ( empty( $creds['host'] ) ) {
            throw new \RuntimeException( 'No hay credenciales SFTP configuradas.' );
        }

        $sftp = new SFTP( $creds['host'], (int) ( $creds['port'] ?? 22 ) );

        if ( ! $sftp->login( $creds['username'], $creds['password'] ) ) {
            throw new \RuntimeException( 'Autenticación SFTP fallida. Verifica usuario y contraseña.' );
        }

        return new self( $sftp, $creds['root_path'] ?? '/' );
    }

    /**
     * Conexión temporal con credenciales explícitas (para prueba de conexión).
     *
     * @throws \RuntimeException si la conexión o autenticación fallan.
     */
    public static function connect_with( string $host, int $port, string $username, string $password ): self {
        $sftp = new SFTP( $host, $port );

        if ( ! $sftp->login( $username, $password ) ) {
            throw new \RuntimeException( 'Autenticación fallida. Verifica las credenciales.' );
        }

        return new self( $sftp, '/' );
    }

    // ── Directorio ───────────────────────────────────────────────────────────

    /**
     * Lista el contenido de un directorio.
     *
     * @return array<int, array{name: string, type: string, size: int, modified: int, permissions: string}>
     * @throws \RuntimeException
     */
    public function list_directory( string $path ): array {
        $full  = $this->full_path( $path );
        $items = $this->sftp->rawlist( $full );

        if ( false === $items ) {
            throw new \RuntimeException( "No se puede listar el directorio: {$path}" );
        }

        $result = [];
        foreach ( $items as $name => $info ) {
            if ( $name === '.' || $name === '..' ) continue;

            $result[] = [
                'name'        => $name,
                'type'        => $info['type'] === NET_SFTP_TYPE_DIRECTORY ? 'dir' : 'file',
                'size'        => (int) ( $info['size'] ?? 0 ),
                'modified'    => (int) ( $info['mtime'] ?? 0 ),
                'permissions' => $this->format_permissions( (int) ( $info['permissions'] ?? 0 ) ),
            ];
        }

        // Carpetas primero, luego alfabético
        usort( $result, function ( $a, $b ) {
            if ( $a['type'] !== $b['type'] ) {
                return $a['type'] === 'dir' ? -1 : 1;
            }
            return strcasecmp( $a['name'], $b['name'] );
        });

        return $result;
    }

    /**
     * Crea un directorio de forma recursiva.
     *
     * @throws \RuntimeException
     */
    public function create_directory( string $path ): void {
        $full = $this->full_path( $path );
        if ( ! $this->sftp->mkdir( $full, 0755, true ) ) {
            throw new \RuntimeException( "No se pudo crear el directorio: {$path}" );
        }
    }

    /**
     * Devuelve el directorio de trabajo actual en el servidor.
     */
    public function pwd(): string {
        return $this->sftp->pwd() ?: '/';
    }

    // ── Archivo ──────────────────────────────────────────────────────────────

    /**
     * Descarga el contenido de un archivo como string.
     *
     * @throws \RuntimeException
     */
    public function get_file( string $path ): string {
        $full    = $this->full_path( $path );
        $content = $this->sftp->get( $full );

        if ( false === $content ) {
            throw new \RuntimeException( "No se puede leer el archivo: {$path}" );
        }

        return $content;
    }

    /**
     * Escribe contenido (string) en una ruta remota.
     *
     * @throws \RuntimeException
     */
    public function put_file( string $path, string $content ): void {
        $full = $this->full_path( $path );
        if ( ! $this->sftp->put( $full, $content ) ) {
            throw new \RuntimeException( "No se pudo guardar el archivo: {$path}" );
        }
    }

    /**
     * Sube un archivo local (ruta tmp de $_FILES) a una ruta remota.
     *
     * @throws \RuntimeException
     */
    public function upload_file( string $remote_path, string $local_tmp ): void {
        $full = $this->full_path( $remote_path );
        if ( ! $this->sftp->put( $full, $local_tmp, SFTP::SOURCE_LOCAL_FILE ) ) {
            throw new \RuntimeException( "Error al subir el archivo a: {$remote_path}" );
        }
    }

    /**
     * Crea un archivo vacío (o con contenido inicial).
     *
     * @throws \RuntimeException
     */
    public function create_file( string $path, string $content = '' ): void {
        $this->put_file( $path, $content );
    }

    /**
     * Elimina un archivo o directorio (recursivo si es carpeta).
     *
     * @throws \RuntimeException
     */
    public function delete( string $path ): void {
        $full = $this->full_path( $path );
        $stat = $this->sftp->stat( $full );

        if ( false === $stat ) {
            throw new \RuntimeException( "No existe: {$path}" );
        }

        $is_dir = $stat['type'] === NET_SFTP_TYPE_DIRECTORY;

        if ( ! $this->sftp->delete( $full, $is_dir ) ) {
            throw new \RuntimeException( "No se pudo eliminar: {$path}" );
        }
    }

    /**
     * Renombra o mueve un elemento.
     *
     * @throws \RuntimeException
     */
    public function rename( string $old_path, string $new_path ): void {
        $old = $this->full_path( $old_path );
        $new = $this->full_path( $new_path );

        if ( ! $this->sftp->rename( $old, $new ) ) {
            throw new \RuntimeException( "No se pudo renombrar: {$old_path} → {$new_path}" );
        }
    }

    // ── Helpers privados ─────────────────────────────────────────────────────

    /**
     * Construye la ruta absoluta y previene path traversal.
     *
     * @throws \RuntimeException si la ruta resultante queda fuera del root.
     */
    private function full_path( string $relative ): string {
        $relative = str_replace( '\\', '/', $relative );
        $full     = $this->root . '/' . ltrim( $relative, '/' );

        // Resolver segmentos . y ..
        $parts    = explode( '/', $full );
        $resolved = [];
        foreach ( $parts as $part ) {
            if ( $part === '' || $part === '.' ) continue;
            if ( $part === '..' ) {
                array_pop( $resolved );
            } else {
                $resolved[] = $part;
            }
        }

        $safe = '/' . implode( '/', $resolved );

        // Garantizar que la ruta no escapa del root
        if ( $this->root !== '' && ! str_starts_with( $safe, $this->root ) ) {
            throw new \RuntimeException( 'Ruta no permitida (path traversal detectado).' );
        }

        return $safe;
    }

    /**
     * Convierte modo octal a notación Unix (ej: drwxr-xr-x).
     */
    private function format_permissions( int $mode ): string {
        $types = [
            0140000 => 's', 0120000 => 'l', 0100000 => '-',
            0060000 => 'b', 0040000 => 'd', 0020000 => 'c', 0010000 => 'p',
        ];

        $type = '-';
        foreach ( $types as $mask => $char ) {
            if ( ( $mode & 0170000 ) === $mask ) {
                $type = $char;
                break;
            }
        }

        $bit = fn( int $b ): bool => (bool) ( $mode & $b );

        return $type
            . ( $bit( 0400 ) ? 'r' : '-' ) . ( $bit( 0200 ) ? 'w' : '-' ) . ( $bit( 0100 ) ? 'x' : '-' )
            . ( $bit( 0040 ) ? 'r' : '-' ) . ( $bit( 0020 ) ? 'w' : '-' ) . ( $bit( 0010 ) ? 'x' : '-' )
            . ( $bit( 0004 ) ? 'r' : '-' ) . ( $bit( 0002 ) ? 'w' : '-' ) . ( $bit( 0001 ) ? 'x' : '-' );
    }
}
