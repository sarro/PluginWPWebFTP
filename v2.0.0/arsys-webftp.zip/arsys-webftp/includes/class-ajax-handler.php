<?php
defined( 'ABSPATH' ) || exit;

/**
 * Registra y gestiona todos los endpoints AJAX del plugin.
 *
 * Seguridad en dos capas:
 *  1. Nonce de WordPress (awftp_nonce) en todas las peticiones
 *  2. Sesión WebFTP activa (AWFTP_Session) en todas excepto login
 *
 * Los endpoints están registrados tanto para usuarios logados en WP
 * como para no logados, ya que la autenticación la gestiona el plugin.
 */
class AWFTP_Ajax_Handler {

    public static function init(): void {
        $actions = [
            'awftp_login',
            'awftp_logout',
            'awftp_list_directory',
            'awftp_get_file',
            'awftp_save_file',
            'awftp_upload_file',
            'awftp_delete',
            'awftp_rename',
            'awftp_create_folder',
            'awftp_create_file',
            'awftp_download_file',
            'awftp_test_connection',
        ];

        foreach ( $actions as $action ) {
            add_action( 'wp_ajax_'        . $action, [ self::class, 'dispatch' ] );
            add_action( 'wp_ajax_nopriv_' . $action, [ self::class, 'dispatch' ] );
        }
    }

    // ── Dispatcher central ────────────────────────────────────────────────────

    public static function dispatch(): void {
        $action = sanitize_text_field( $_REQUEST['action'] ?? '' );

        // Login solo necesita su propio nonce
        if ( $action === 'awftp_login' ) {
            self::verify_nonce( 'awftp_login_nonce' );
            self::handle_login();
            return;
        }

        // Resto de acciones: nonce general + sesión activa
        self::verify_nonce( 'awftp_nonce' );

        if ( $action === 'awftp_logout' ) {
            self::handle_logout();
            return;
        }

        // Download usa salida directa, se gestiona aparte
        if ( $action === 'awftp_download_file' ) {
            self::require_session();
            self::handle_download();
            return;
        }

        // Resto de acciones SFTP
        self::require_session();

        try {
            switch ( $action ) {
                case 'awftp_list_directory': self::handle_list_directory(); break;
                case 'awftp_get_file':       self::handle_get_file();       break;
                case 'awftp_save_file':      self::handle_save_file();      break;
                case 'awftp_upload_file':    self::handle_upload_file();    break;
                case 'awftp_delete':         self::handle_delete();         break;
                case 'awftp_rename':         self::handle_rename();         break;
                case 'awftp_create_folder':  self::handle_create_folder();  break;
                case 'awftp_create_file':    self::handle_create_file();    break;
                case 'awftp_test_connection':self::handle_test_connection(); break;
                default:
                    wp_send_json_error( [ 'message' => 'Acción desconocida.' ], 400 );
            }
        } catch ( \RuntimeException $e ) {
            wp_send_json_error( [ 'message' => $e->getMessage() ] );
        } catch ( \Exception $e ) {
            wp_send_json_error( [ 'message' => 'Error interno: ' . $e->getMessage() ] );
        }
    }

    // ── Auth ──────────────────────────────────────────────────────────────────

    private static function handle_login(): void {
        $username = sanitize_text_field( $_POST['username'] ?? '' );
        $password = $_POST['password'] ?? '';

        if ( empty( $username ) || empty( $password ) ) {
            wp_send_json_error( [ 'message' => 'Introduce usuario y contraseña.' ] );
        }

        $result = AWFTP_Session::login( $username, $password );

        if ( $result['success'] ) {
            wp_send_json_success( [
                'message' => '¡Bienvenido, ' . esc_html( $result['user'] ) . '!',
                'reload'  => true,
            ]);
        } else {
            wp_send_json_error( [ 'message' => $result['error'] ] );
        }
    }

    private static function handle_logout(): void {
        AWFTP_Session::logout();
        wp_send_json_success( [ 'message' => 'Sesión cerrada.', 'reload' => true ] );
    }

    // ── Operaciones SFTP ──────────────────────────────────────────────────────

    private static function handle_list_directory(): void {
        $path  = self::param( 'path', '/' );
        $sftp  = AWFTP_SFTP_Manager::connect();
        $items = $sftp->list_directory( $path );
        wp_send_json_success( [ 'items' => $items, 'path' => $path ] );
    }

    private static function handle_get_file(): void {
        $path    = self::param( 'path' );
        $sftp    = AWFTP_SFTP_Manager::connect();
        $content = $sftp->get_file( $path );
        wp_send_json_success( [ 'content' => $content, 'path' => $path ] );
    }

    private static function handle_save_file(): void {
        $path    = self::param( 'path' );
        $content = wp_unslash( $_POST['content'] ?? '' );
        AWFTP_SFTP_Manager::connect()->put_file( $path, $content );
        wp_send_json_success( [ 'message' => 'Archivo guardado correctamente.' ] );
    }

    private static function handle_upload_file(): void {
        if ( empty( $_FILES['file'] ) ) {
            throw new \RuntimeException( 'No se recibió ningún archivo.' );
        }

        $dir   = self::param( 'path', '/' );
        $sftp  = AWFTP_SFTP_Manager::connect();
        $files = self::normalize_files_array( $_FILES['file'] );

        $uploaded = [];
        $errors   = [];

        foreach ( $files as $file ) {
            if ( $file['error'] !== UPLOAD_ERR_OK ) {
                $errors[] = $file['name'] . ': error al recibir el archivo.';
                continue;
            }

            $remote = rtrim( $dir, '/' ) . '/' . basename( $file['name'] );

            try {
                $sftp->upload_file( $remote, $file['tmp_name'] );
                $uploaded[] = $file['name'];
            } catch ( \Exception $e ) {
                $errors[] = $file['name'] . ': ' . $e->getMessage();
            }
        }

        if ( empty( $uploaded ) && ! empty( $errors ) ) {
            throw new \RuntimeException( implode( ' | ', $errors ) );
        }

        wp_send_json_success( [
            'message'  => count( $uploaded ) . ' archivo(s) subido(s) correctamente.',
            'uploaded' => $uploaded,
            'errors'   => $errors,
        ]);
    }

    private static function handle_delete(): void {
        $path = self::param( 'path' );
        AWFTP_SFTP_Manager::connect()->delete( $path );
        wp_send_json_success( [ 'message' => 'Eliminado correctamente.' ] );
    }

    private static function handle_rename(): void {
        $old_path = self::param( 'old_path' );
        $new_name = sanitize_text_field( self::param( 'new_name' ) );

        if ( empty( $new_name ) ) {
            throw new \RuntimeException( 'El nuevo nombre no puede estar vacío.' );
        }

        $dir      = dirname( $old_path );
        $new_path = ( $dir === '.' ? '' : $dir ) . '/' . $new_name;

        AWFTP_SFTP_Manager::connect()->rename( $old_path, $new_path );
        wp_send_json_success( [ 'message' => 'Renombrado correctamente.' ] );
    }

    private static function handle_create_folder(): void {
        $parent = self::param( 'path', '/' );
        $name   = sanitize_text_field( self::param( 'name' ) );

        if ( empty( $name ) ) {
            throw new \RuntimeException( 'El nombre de la carpeta no puede estar vacío.' );
        }

        $full_path = rtrim( $parent, '/' ) . '/' . $name;
        AWFTP_SFTP_Manager::connect()->create_directory( $full_path );
        wp_send_json_success( [ 'message' => 'Carpeta creada correctamente.' ] );
    }

    private static function handle_create_file(): void {
        $parent = self::param( 'path', '/' );
        $name   = sanitize_text_field( self::param( 'name' ) );

        if ( empty( $name ) ) {
            throw new \RuntimeException( 'El nombre del archivo no puede estar vacío.' );
        }

        $full_path = rtrim( $parent, '/' ) . '/' . $name;
        AWFTP_SFTP_Manager::connect()->create_file( $full_path, '' );
        wp_send_json_success( [ 'message' => 'Archivo creado correctamente.' ] );
    }

    private static function handle_download(): void {
        $path = self::param( 'path' );

        if ( empty( $path ) ) {
            wp_die( 'Ruta no especificada.' );
        }

        $content  = AWFTP_SFTP_Manager::connect()->get_file( $path );
        $filename = basename( $path );

        header( 'Content-Type: application/octet-stream' );
        header( 'Content-Disposition: attachment; filename="' . rawurlencode( $filename ) . '"' );
        header( 'Content-Length: ' . strlen( $content ) );
        header( 'Cache-Control: no-cache, no-store, must-revalidate' );
        header( 'Pragma: no-cache' );
        header( 'Expires: 0' );

        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo $content;
        exit;
    }

    private static function handle_test_connection(): void {
        $host     = sanitize_text_field( $_POST['host']     ?? '' );
        $port     = absint( $_POST['port'] ?? 22 );
        $username = sanitize_text_field( $_POST['username'] ?? '' );
        $password = $_POST['password'] ?? '';

        if ( empty( $host ) || empty( $username ) ) {
            throw new \RuntimeException( 'Host y usuario son obligatorios.' );
        }

        $sftp = AWFTP_SFTP_Manager::connect_with( $host, $port, $username, $password );

        wp_send_json_success( [
            'message' => 'Conexión exitosa. Directorio remoto: ' . $sftp->pwd(),
        ]);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /**
     * Verifica el nonce de la petición. Termina con error 403 si no es válido.
     */
    private static function verify_nonce( string $nonce_action ): void {
        $nonce = sanitize_text_field( $_REQUEST['nonce'] ?? '' );
        if ( ! wp_verify_nonce( $nonce, $nonce_action ) ) {
            wp_send_json_error( [ 'message' => 'Petición no válida. Recarga la página.' ], 403 );
        }
    }

    /**
     * Verifica que hay una sesión WebFTP activa.
     * Si no la hay, responde con session_expired para que el JS redirija al login.
     */
    private static function require_session(): void {
        if ( ! AWFTP_Session::is_logged_in() ) {
            wp_send_json_error(
                [ 'message' => 'Sesión expirada. Vuelve a iniciar sesión.', 'session_expired' => true ],
                401
            );
        }
    }

    /**
     * Obtiene un parámetro de la petición (POST o GET) sin slashes.
     */
    private static function param( string $key, string $default = '' ): string {
        return wp_unslash( (string) ( $_REQUEST[ $key ] ?? $default ) );
    }

    /**
     * Normaliza $_FILES para soportar subida múltiple (file[] o file).
     *
     * @return array<int, array{name: string, tmp_name: string, error: int, size: int}>
     */
    private static function normalize_files_array( array $files ): array {
        if ( ! is_array( $files['name'] ) ) {
            return [ $files ];
        }

        $result = [];
        $count  = count( $files['name'] );

        for ( $i = 0; $i < $count; $i++ ) {
            $result[] = [
                'name'     => $files['name'][ $i ],
                'tmp_name' => $files['tmp_name'][ $i ],
                'error'    => $files['error'][ $i ],
                'size'     => $files['size'][ $i ],
            ];
        }

        return $result;
    }
}
