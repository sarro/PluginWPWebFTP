<?php
defined( 'ABSPATH' ) || exit;

/**
 * Sistema de auto-actualización desde GitHub Releases.
 *
 * Flujo:
 *  1. WordPress llama a pre_set_site_transient_update_plugins
 *  2. Consultamos la API de GitHub: api.github.com/repos/sarro/PluginWPWebFTP/releases/latest
 *  3. Si el tag de la release > versión instalada → inyectamos la actualización en el transient
 *  4. WP muestra el aviso nativo "Nueva versión disponible"
 *  5. Al hacer clic en Actualizar, WP descarga el ZIP adjunto a la release y lo instala
 *  6. plugins_api devuelve los detalles de la release para el modal "Ver detalles"
 */
class AWFTP_Updater {

    const GITHUB_USER = 'sarro';
    const GITHUB_REPO = 'PluginWPWebFTP';
    const GITHUB_API  = 'https://api.github.com/repos/sarro/PluginWPWebFTP/releases/latest';

    /** Cuánto tiempo cachear la respuesta de GitHub (en segundos) */
    const CACHE_TTL = 43200; // 12 horas
    const CACHE_KEY = 'awftp_github_release';

    private string $plugin_file;
    private string $plugin_slug;
    private string $current_version;

    public function __construct( string $plugin_file, string $current_version ) {
        $this->plugin_file     = $plugin_file;
        $this->plugin_slug     = plugin_basename( $plugin_file );
        $this->current_version = $current_version;
    }

    // ── Init ─────────────────────────────────────────────────────────────────

    public static function init(): void {
        $instance = new self( AWFTP_DIR . 'arsys-webftp.php', AWFTP_VERSION );

        // Inyectar en el sistema de actualizaciones de WP
        add_filter( 'pre_set_site_transient_update_plugins', [ $instance, 'check_for_update' ] );

        // Proporcionar info al modal "Ver detalles"
        add_filter( 'plugins_api', [ $instance, 'plugin_info' ], 20, 3 );

        // Limpiar caché tras actualizar
        add_action( 'upgrader_process_complete', [ $instance, 'clear_cache' ], 10, 2 );
    }

    // ── Comprobar actualización ───────────────────────────────────────────────

    /**
     * Hook: pre_set_site_transient_update_plugins
     * Se ejecuta cuando WP comprueba actualizaciones de plugins.
     */
    public function check_for_update( $transient ) {
        if ( empty( $transient->checked ) ) {
            return $transient;
        }

        $release = $this->get_latest_release();

        if ( ! $release ) {
            return $transient;
        }

        $latest_version = ltrim( $release['tag_name'], 'v' );

        if ( version_compare( $latest_version, $this->current_version, '>' ) ) {
            $download_url = $this->get_download_url( $release );

            if ( $download_url ) {
                $transient->response[ $this->plugin_slug ] = (object) [
                    'id'            => $this->plugin_slug,
                    'slug'          => dirname( $this->plugin_slug ),
                    'plugin'        => $this->plugin_slug,
                    'new_version'   => $latest_version,
                    'url'           => 'https://github.com/' . self::GITHUB_USER . '/' . self::GITHUB_REPO,
                    'package'       => $download_url,
                    'icons'         => [],
                    'banners'       => [],
                    'banners_rtl'   => [],
                    'tested'        => '6.5',
                    'requires_php'  => '7.4',
                    'compatibility' => new \stdClass(),
                ];
            }
        }

        return $transient;
    }

    // ── Info del plugin (modal "Ver detalles") ────────────────────────────────

    /**
     * Hook: plugins_api
     * Rellena el modal de detalles cuando el usuario hace clic en "Ver detalles".
     */
    public function plugin_info( $result, string $action, $args ) {
        if ( $action !== 'plugin_information' ) {
            return $result;
        }

        if ( ! isset( $args->slug ) || $args->slug !== dirname( $this->plugin_slug ) ) {
            return $result;
        }

        $release = $this->get_latest_release();

        if ( ! $release ) {
            return $result;
        }

        $latest_version = ltrim( $release['tag_name'], 'v' );
        $download_url   = $this->get_download_url( $release );
        $changelog      = $this->format_changelog( $release['body'] ?? '' );

        return (object) [
            'name'          => 'Arsys WebFTP',
            'slug'          => dirname( $this->plugin_slug ),
            'version'       => $latest_version,
            'author'        => '<a href="https://www.arsys.es">Arsys (IONOS Group)</a>',
            'homepage'      => 'https://github.com/' . self::GITHUB_USER . '/' . self::GITHUB_REPO,
            'requires'      => '6.0',
            'tested'        => '6.5',
            'requires_php'  => '7.4',
            'last_updated'  => $release['published_at'] ?? '',
            'sections'      => [
                'description' => 'Explorador SFTP integrado en WordPress. Acceso protegido con login de usuario WordPress. Sin dependencias externas.',
                'changelog'   => $changelog,
            ],
            'download_link' => $download_url,
        ];
    }

    // ── Limpiar caché ─────────────────────────────────────────────────────────

    /**
     * Hook: upgrader_process_complete
     * Limpia la caché de la release tras una actualización.
     */
    public function clear_cache( $upgrader, array $hook_extra ): void {
        if (
            isset( $hook_extra['type'] ) && $hook_extra['type'] === 'plugin' &&
            isset( $hook_extra['plugins'] ) && in_array( $this->plugin_slug, $hook_extra['plugins'], true )
        ) {
            delete_transient( self::CACHE_KEY );
        }
    }

    // ── API GitHub ────────────────────────────────────────────────────────────

    /**
     * Obtiene la última release de GitHub.
     * Cachea el resultado en un transient de WP para no saturar la API.
     *
     * @return array|null
     */
    private function get_latest_release(): ?array {
        // Intentar desde caché
        $cached = get_transient( self::CACHE_KEY );
        if ( false !== $cached ) {
            return $cached;
        }

        $response = wp_remote_get( self::GITHUB_API, [
            'timeout' => 10,
            'headers' => [
                'Accept'     => 'application/vnd.github.v3+json',
                'User-Agent' => 'ArsysWebFTP/' . AWFTP_VERSION . '; WordPress/' . get_bloginfo( 'version' ),
            ],
        ]);

        if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
            return null;
        }

        $body    = wp_remote_retrieve_body( $response );
        $release = json_decode( $body, true );

        if ( ! is_array( $release ) || empty( $release['tag_name'] ) ) {
            return null;
        }

        // Guardar en caché
        set_transient( self::CACHE_KEY, $release, self::CACHE_TTL );

        return $release;
    }

    /**
     * Obtiene la URL de descarga del ZIP adjunto a la release.
     * Busca primero un asset adjunto, luego usa el zipball de GitHub.
     *
     * @param array $release
     * @return string|null
     */
    private function get_download_url( array $release ): ?string {
        // Buscar asset adjunto que sea un ZIP del plugin
        if ( ! empty( $release['assets'] ) ) {
            foreach ( $release['assets'] as $asset ) {
                if (
                    isset( $asset['browser_download_url'] ) &&
                    str_ends_with( strtolower( $asset['name'] ), '.zip' )
                ) {
                    return $asset['browser_download_url'];
                }
            }
        }

        // Fallback: zipball automático de GitHub
        return $release['zipball_url'] ?? null;
    }

    /**
     * Formatea el body de la release como HTML para el modal de WP.
     *
     * @param string $markdown
     * @return string
     */
    private function format_changelog( string $markdown ): string {
        if ( empty( $markdown ) ) {
            return '<p>Sin notas de versión.</p>';
        }

        // Conversión básica Markdown → HTML
        $html = esc_html( $markdown );
        $html = preg_replace( '/^### (.+)$/m', '<h4>$1</h4>', $html );
        $html = preg_replace( '/^## (.+)$/m',  '<h3>$1</h3>', $html );
        $html = preg_replace( '/^# (.+)$/m',   '<h2>$1</h2>', $html );
        $html = preg_replace( '/^\* (.+)$/m',  '<li>$1</li>', $html );
        $html = preg_replace( '/^- (.+)$/m',   '<li>$1</li>', $html );
        $html = preg_replace( '/(<li>.*<\/li>)/s', '<ul>$1</ul>', $html );
        $html = preg_replace( '/`([^`]+)`/', '<code>$1</code>', $html );
        $html = nl2br( $html );

        return $html;
    }
}
