/* global AWFTP, jQuery */
/* Arsys WebFTP v2.2.0 */
(function($){'use strict';
var currentPath='/',editorPath='';
$(function(){if(AWFTP.logged_in==='1')initExplorer();else initLogin();});

function initLogin(){
    $('#awftp-login-btn').on('click',doLogin);
    $('#awftp-login-pass').on('keydown',function(e){if(e.key==='Enter')doLogin();});
    $('#awftp-login-user').on('keydown',function(e){if(e.key==='Enter')$('#awftp-login-pass').focus();});
}
function doLogin(){
    var user=$('#awftp-login-user').val().trim(),pass=$('#awftp-login-pass').val(),$btn=$('#awftp-login-btn'),$err=$('#awftp-login-error');
    if(!user||!pass){showLoginError('Introduce usuario y contraseña.');return;}
    $btn.prop('disabled',true);$btn.find('.awftp-login-btn-text').text('Verificando...');$btn.find('.awftp-login-spinner').show();$err.hide();
    $.post(AWFTP.ajax_url,{action:'awftp_login',nonce:AWFTP.login_nonce,username:user,password:pass})
    .done(function(res){
        if(res.success&&res.data.reload){window.location.reload();}
        else{showLoginError(res.data&&res.data.message?res.data.message:'Error desconocido.');resetLoginBtn();$('#awftp-login-pass').val('').focus();}
    }).fail(function(){showLoginError('Error de red. Inténtalo de nuevo.');resetLoginBtn();});
}
function showLoginError(msg){$('#awftp-login-error').text(msg).show();$('#awftp-login-card').addClass('awftp-login-shake');setTimeout(function(){$('#awftp-login-card').removeClass('awftp-login-shake');},500);}
function resetLoginBtn(){var $btn=$('#awftp-login-btn');$btn.prop('disabled',false);$btn.find('.awftp-login-btn-text').text('Acceder al explorador');$btn.find('.awftp-login-spinner').hide();}

function initExplorer(){loadDirectory('/');bindEvents();}
function bindEvents(){
    $('#awftp-btn-up').on('click',navigateUp);
    $('#awftp-btn-refresh').on('click',function(){loadDirectory(currentPath);});
    $('#awftp-btn-new-folder').on('click',function(){openNewModal('folder');});
    $('#awftp-btn-new-file').on('click',function(){openNewModal('file');});
    $('#awftp-btn-confirm-new').on('click',confirmNew);
    $('#awftp-upload-input').on('change',handleUpload);
    $('#awftp-btn-save-file').on('click',saveFile);
    $('#awftp-btn-confirm-rename').on('click',confirmRename);
    $('#awftp-btn-confirm-delete').on('click',confirmDelete);
    $('#awftp-logout-btn').on('click',doLogout);
    $(document).on('click','.awftp-modal-close',function(){closeModal($(this).data('modal'));});
    $('#awftp-overlay').on('click',closeAllModals);
    $('#awftp-rename-input').on('keydown',function(e){if(e.key==='Enter')confirmRename();});
    $('#awftp-new-name-input').on('keydown',function(e){if(e.key==='Enter')confirmNew();});
    $(document).on('click','.awftp-entry-name[data-type="dir"]',function(){navigateTo($(this).data('path'));});
    $(document).on('click','.awftp-btn-edit',function(){openEditor($(this).data('path'));});
    $(document).on('click','.awftp-btn-rename',function(){openRenameModal($(this).data('path'),$(this).data('name'));});
    $(document).on('click','.awftp-btn-delete',function(){openDeleteModal($(this).data('path'),$(this).data('name'));});
    $(document).on('click','.awftp-btn-download',function(){downloadFile($(this).data('path'));});
}
function doLogout(){ajaxCall('awftp_logout',{},function(){window.location.reload();});}
function navigateTo(path){loadDirectory(path);}
function navigateUp(){if(currentPath==='/'||currentPath==='')return;var parts=currentPath.replace(/\/$/,'').split('/');parts.pop();loadDirectory(parts.join('/')||'/');}
function loadDirectory(path){
    currentPath=path;$('#awftp-current-path').val(path);
    $('#awftp-file-list').html('<tr><td colspan="6" class="awftp-loading"><span class="awftp-spinner"></span> Cargando...</td></tr>');
    ajaxCall('awftp_list_directory',{path:path},function(data){renderFileList(data.items,path);});
}
function renderFileList(items,path){
    var $tbody=$('#awftp-file-list');$tbody.empty();
    if(!items||!items.length){$tbody.html('<tr><td colspan="6" class="awftp-empty">📭 Directorio vacío</td></tr>');return;}
    $.each(items,function(i,item){
        var itemPath=path.replace(/\/$/,'')+'/'+item.name;
        var icon=item.type==='dir'?'📁':getFileIcon(item.name);
        var size=item.type==='dir'?'—':formatSize(item.size);
        var date=item.modified?new Date(item.modified*1000).toLocaleString('es-ES',{dateStyle:'short',timeStyle:'short'}):'—';
        var $name=item.type==='dir'
            ?$('<span>').addClass('awftp-entry-name awftp-dir').attr({'data-type':'dir','data-path':itemPath}).text(item.name)
            :$('<span>').addClass('awftp-entry-name awftp-file').text(item.name);
        var $actions=$('<div>').addClass('awftp-action-btns');
        if(item.type==='file'){
            $actions.append(mkBtn('⬇','Descargar','awftp-btn-download',itemPath,item.name));
            if(isEditable(item.name))$actions.append(mkBtn('✏️ Editar','Editar','awftp-btn-edit',itemPath,item.name));
        }
        $actions.append(mkBtn('Renombrar','Renombrar','awftp-btn-rename',itemPath,item.name),mkBtn('🗑','Eliminar','awftp-btn-delete awftp-btn-danger-sm',itemPath,item.name));
        $tbody.append($('<tr>').append(
            $('<td>').addClass('col-icon').text(icon),
            $('<td>').addClass('col-name').append($name),
            $('<td>').addClass('col-size').text(size),
            $('<td>').addClass('col-date').text(date),
            $('<td>').addClass('col-perms').append($('<code>').text(item.permissions)),
            $('<td>').addClass('col-actions').append($actions)
        ));
    });
}
function mkBtn(label,title,classes,path,name){return $('<button>').addClass('button button-small '+classes).attr({title:title,'data-path':path,'data-name':name}).html(label);}
function openEditor(path){editorPath=path;$('#awftp-editor-filename').text(path.split('/').pop());$('#awftp-editor-content').val('Cargando...');openModal('awftp-modal-editor');ajaxCall('awftp_get_file',{path:path},function(data){$('#awftp-editor-content').val(data.content);});}
function saveFile(){var content=$('#awftp-editor-content').val(),$btn=$('#awftp-btn-save-file').prop('disabled',true).text('Guardando...');ajaxCall('awftp_save_file',{path:editorPath,content:content},function(data){notify('success',data.message);closeModal('awftp-modal-editor');},null,function(){$btn.prop('disabled',false).text('💾 Guardar');});}
function handleUpload(){
    var files=this.files;if(!files.length)return;
    var fd=new FormData();fd.append('action','awftp_upload_file');fd.append('nonce',AWFTP.nonce);fd.append('path',currentPath);
    for(var i=0;i<files.length;i++)fd.append('file[]',files[i]);
    var $prog=$('#awftp-upload-progress').show(),$fill=$('#awftp-progress-fill'),$txt=$('#awftp-progress-text');
    $.ajax({url:AWFTP.ajax_url,type:'POST',data:fd,processData:false,contentType:false,
        xhr:function(){var xhr=new XMLHttpRequest();xhr.upload.addEventListener('progress',function(e){if(e.lengthComputable){var pct=Math.round(e.loaded/e.total*100);$fill.css('width',pct+'%');$txt.text('Subiendo... '+pct+'%');}});return xhr;},
        success:function(res){if(res.success){notify('success',res.data.message);loadDirectory(currentPath);}else notify('error',res.data?res.data.message:'Error al subir.');},
        error:function(){notify('error','Error de red al subir archivos.');},
        complete:function(){setTimeout(function(){$prog.hide();$fill.css('width','0');},1800);$('#awftp-upload-input').val('');}
    });
}
function downloadFile(path){window.location.href=AWFTP.ajax_url+'?action=awftp_download_file&nonce='+encodeURIComponent(AWFTP.nonce)+'&path='+encodeURIComponent(path);}
function openRenameModal(path,name){$('#awftp-rename-old').val(path);$('#awftp-rename-input').val(name);openModal('awftp-modal-rename');setTimeout(function(){$('#awftp-rename-input').select();},200);}
function confirmRename(){var oldPath=$('#awftp-rename-old').val(),newName=$('#awftp-rename-input').val().trim();if(!newName){notify('error','El nombre no puede estar vacío.');return;}ajaxCall('awftp_rename',{old_path:oldPath,new_name:newName},function(data){notify('success',data.message);closeModal('awftp-modal-rename');loadDirectory(currentPath);});}
function openNewModal(type){$('#awftp-new-type').val(type);$('#awftp-modal-new-title').text(type==='folder'?'📁 Nueva carpeta':'📄 Nuevo archivo');$('#awftp-modal-new-label').text(type==='folder'?'Nombre de la carpeta:':'Nombre del archivo:');$('#awftp-new-name-input').val('');openModal('awftp-modal-new');setTimeout(function(){$('#awftp-new-name-input').focus();},200);}
function confirmNew(){var type=$('#awftp-new-type').val(),name=$('#awftp-new-name-input').val().trim();if(!name){notify('error','El nombre no puede estar vacío.');return;}ajaxCall(type==='folder'?'awftp_create_folder':'awftp_create_file',{path:currentPath,name:name},function(data){notify('success',data.message);closeModal('awftp-modal-new');loadDirectory(currentPath);});}
function openDeleteModal(path,name){$('#awftp-delete-path').val(path);$('#awftp-delete-name').text(name);openModal('awftp-modal-delete');}
function confirmDelete(){ajaxCall('awftp_delete',{path:$('#awftp-delete-path').val()},function(data){notify('success',data.message);closeModal('awftp-modal-delete');loadDirectory(currentPath);});}
function openModal(id){closeAllModals();$('#'+id+', #awftp-overlay').fadeIn(160);}
function closeModal(id){$('#'+id).fadeOut(160);if(!$('.awftp-modal:visible').length)$('#awftp-overlay').fadeOut(160);}
function closeAllModals(){$('.awftp-modal, #awftp-overlay').fadeOut(160);}
function notify(type,msg){var icons={success:'✅',error:'❌',warning:'⚠️',info:'ℹ️'};var $n=$('<div>').addClass('awftp-notification awftp-notification-'+type).html((icons[type]||'')+' '+$('<div>').text(msg).html());$('#awftp-notifications').append($n);setTimeout(function(){$n.addClass('awftp-notification-out');setTimeout(function(){$n.remove();},400);},4200);}
function ajaxCall(action,data,onSuccess,onError,onComplete){
    $.ajax({url:AWFTP.ajax_url,type:'POST',data:$.extend({action:action,nonce:AWFTP.nonce},data),
        success:function(res){if(res.success){if(onSuccess)onSuccess(res.data);}else{var msg=res.data&&res.data.message?res.data.message:'Error desconocido.';if(res.data&&res.data.session_expired){notify('warning','Sesión expirada. Redirigiendo...');setTimeout(function(){window.location.reload();},2000);return;}notify('error',msg);if(onError)onError(res.data);}},
        error:function(){notify('error','Error de red.');if(onError)onError();},
        complete:function(){if(onComplete)onComplete();}
    });
}
function formatSize(bytes){if(!bytes||bytes===0)return'0 B';var u=['B','KB','MB','GB','TB'],i=Math.floor(Math.log(bytes)/Math.log(1024));return(bytes/Math.pow(1024,i)).toFixed(i>0?1:0)+' '+u[i];}
function getFileIcon(name){var m={php:'🐘',html:'🌐',htm:'🌐',css:'🎨',js:'⚡',ts:'⚡',jsx:'⚡',tsx:'⚡',json:'{}',xml:'📋',yml:'📋',yaml:'📋',txt:'📝',md:'📝',log:'📝',sql:'🗄',csv:'📊',xls:'📊',xlsx:'📊',zip:'📦',tar:'📦',gz:'📦',rar:'📦','7z':'📦',jpg:'🖼',jpeg:'🖼',png:'🖼',gif:'🖼',webp:'🖼',svg:'🖼',pdf:'📄',sh:'⚙️',bash:'⚙️',htaccess:'🔒',env:'🔒',key:'🔒'};return m[(name.split('.').pop()||'').toLowerCase()]||'📄';}
var EDITABLE=['php','html','htm','css','js','ts','jsx','tsx','json','xml','yml','yaml','ini','conf','config','txt','md','sql','sh','bash','htaccess','env','log','twig','blade','vue'];
function isEditable(name){return EDITABLE.indexOf((name.split('.').pop()||'').toLowerCase())>-1;}
})(jQuery);
