<?php
defined( 'ABSPATH' ) || exit;

class AWFTP_Ajax_Handler {

    public static function init(): void {
        $actions = [ 'awftp_login','awftp_logout','awftp_list_directory','awftp_get_file','awftp_save_file','awftp_upload_file','awftp_delete','awftp_rename','awftp_create_folder','awftp_create_file','awftp_download_file','awftp_test_connection' ];
        foreach ( $actions as $action ) {
            add_action( 'wp_ajax_'        . $action, [ self::class, 'dispatch' ] );
            add_action( 'wp_ajax_nopriv_' . $action, [ self::class, 'dispatch' ] );
        }
    }

    public static function dispatch(): void {
        $action = sanitize_text_field( $_REQUEST['action'] ?? '' );

        if ( $action === 'awftp_login' ) {
            self::verify_nonce( 'awftp_login_nonce' );
            self::handle_login();
            return;
        }

        self::verify_nonce( 'awftp_nonce' );

        if ( $action === 'awftp_logout' ) { self::handle_logout(); return; }
        if ( $action === 'awftp_download_file' ) { self::require_session(); self::handle_download(); return; }

        self::require_session();

        try {
            switch ( $action ) {
                case 'awftp_list_directory': self::handle_list_directory(); break;
                case 'awftp_get_file':       self::handle_get_file();       break;
                case 'awftp_save_file':      self::handle_save_file();      break;
                case 'awftp_upload_file':    self::handle_upload_file();    break;
                case 'awftp_delete':         self::handle_delete();         break;
                case 'awftp_rename':         self::handle_rename();         break;
                case 'awftp_create_folder':  self::handle_create_folder();  break;
                case 'awftp_create_file':    self::handle_create_file();    break;
                case 'awftp_test_connection':self::handle_test_connection(); break;
                default: wp_send_json_error( [ 'message' => 'Acción desconocida.' ], 400 );
            }
        } catch ( \RuntimeException $e ) {
            wp_send_json_error( [ 'message' => $e->getMessage() ] );
        } catch ( \Exception $e ) {
            wp_send_json_error( [ 'message' => 'Error interno: ' . $e->getMessage() ] );
        }
    }

    private static function handle_login(): void {
        $username = sanitize_text_field( $_POST['username'] ?? '' );
        $password = $_POST['password'] ?? '';
        if ( empty( $username ) || empty( $password ) ) wp_send_json_error( [ 'message' => 'Introduce usuario y contraseña.' ] );
        $result = AWFTP_Session::login( $username, $password );
        if ( $result['success'] ) wp_send_json_success( [ 'message' => '¡Bienvenido, ' . esc_html( $result['user'] ) . '!', 'reload' => true ] );
        else wp_send_json_error( [ 'message' => $result['error'] ] );
    }

    private static function handle_logout(): void {
        AWFTP_Session::logout();
        wp_send_json_success( [ 'message' => 'Sesión cerrada.', 'reload' => true ] );
    }

    private static function handle_list_directory(): void {
        $path = self::param( 'path', '/' );
        wp_send_json_success( [ 'items' => AWFTP_SFTP_Manager::connect()->list_directory( $path ), 'path' => $path ] );
    }

    private static function handle_get_file(): void {
        $path = self::param( 'path' );
        wp_send_json_success( [ 'content' => AWFTP_SFTP_Manager::connect()->get_file( $path ), 'path' => $path ] );
    }

    private static function handle_save_file(): void {
        AWFTP_SFTP_Manager::connect()->put_file( self::param( 'path' ), wp_unslash( $_POST['content'] ?? '' ) );
        wp_send_json_success( [ 'message' => 'Archivo guardado correctamente.' ] );
    }

    private static function handle_upload_file(): void {
        if ( empty( $_FILES['file'] ) ) throw new \RuntimeException( 'No se recibió ningún archivo.' );
        $dir = self::param( 'path', '/' ); $sftp = AWFTP_SFTP_Manager::connect();
        $files = self::normalize_files( $_FILES['file'] ); $ok = []; $errs = [];
        foreach ( $files as $file ) {
            if ( $file['error'] !== UPLOAD_ERR_OK ) { $errs[] = $file['name'] . ': error.'; continue; }
            try { $sftp->upload_file( rtrim($dir,'/').'/'.$file['name'], $file['tmp_name'] ); $ok[] = $file['name']; }
            catch ( \Exception $e ) { $errs[] = $file['name'].': '.$e->getMessage(); }
        }
        if ( empty($ok) && !empty($errs) ) throw new \RuntimeException( implode(' | ',$errs) );
        wp_send_json_success( [ 'message' => count($ok).' archivo(s) subido(s).', 'uploaded' => $ok, 'errors' => $errs ] );
    }

    private static function handle_delete(): void {
        AWFTP_SFTP_Manager::connect()->delete( self::param('path') );
        wp_send_json_success( [ 'message' => 'Eliminado correctamente.' ] );
    }

    private static function handle_rename(): void {
        $old = self::param('old_path'); $new_name = sanitize_text_field( self::param('new_name') );
        if ( empty($new_name) ) throw new \RuntimeException('Nombre vacío.');
        $dir = dirname($old); $new = ($dir==='.'?'':$dir).'/'.$new_name;
        AWFTP_SFTP_Manager::connect()->rename( $old, $new );
        wp_send_json_success( [ 'message' => 'Renombrado correctamente.' ] );
    }

    private static function handle_create_folder(): void {
        $name = sanitize_text_field( self::param('name') );
        if ( empty($name) ) throw new \RuntimeException('Nombre vacío.');
        AWFTP_SFTP_Manager::connect()->create_directory( rtrim(self::param('path','/'),'/').'/'.$name );
        wp_send_json_success( [ 'message' => 'Carpeta creada.' ] );
    }

    private static function handle_create_file(): void {
        $name = sanitize_text_field( self::param('name') );
        if ( empty($name) ) throw new \RuntimeException('Nombre vacío.');
        AWFTP_SFTP_Manager::connect()->create_file( rtrim(self::param('path','/'),'/').'/'.$name, '' );
        wp_send_json_success( [ 'message' => 'Archivo creado.' ] );
    }

    private static function handle_download(): void {
        $path = self::param('path');
        if ( empty($path) ) wp_die('Ruta no especificada.');

        $content  = AWFTP_SFTP_Manager::connect()->get_file( $path );
        $filename = basename( $path );
        $safe_name = str_replace( ['"', '\', "", "
"], '', $filename );

        header( 'Content-Type: application/octet-stream' );
        header( 'Content-Disposition: attachment; filename="' . $safe_name . '"; filename*=UTF-8\'\'' . rawurlencode( $filename ) );
        header( 'Content-Length: ' . strlen( $content ) );
        header( 'Cache-Control: no-cache, no-store, must-revalidate' );
        header( 'Pragma: no-cache' );
        header( 'Expires: 0' );

        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo $content;
        exit;
    }

    private static function handle_test_connection(): void {
        $host = sanitize_text_field($_POST['host']??''); $port = absint($_POST['port']??22);
        $user = sanitize_text_field($_POST['username']??''); $pass = $_POST['password']??'';
        if ( empty($host)||empty($user) ) throw new \RuntimeException('Host y usuario son obligatorios.');
        $sftp = AWFTP_SFTP_Manager::connect_with( $host, $port, $user, $pass, '/' );
        wp_send_json_success( [ 'message' => 'Conexión exitosa. Directorio raíz: '.$sftp->pwd() ] );
    }

    private static function verify_nonce( string $action ): void {
        if ( ! wp_verify_nonce( sanitize_text_field($_REQUEST['nonce']??''), $action ) ) {
            wp_send_json_error( [ 'message' => 'Petición no válida. Recarga la página.' ], 403 );
        }
    }

    private static function require_session(): void {
        if ( ! AWFTP_Session::is_logged_in() ) {
            wp_send_json_error( [ 'message' => 'Sesión expirada. Vuelve a iniciar sesión.', 'session_expired' => true ], 401 );
        }
    }

    private static function param( string $key, string $default = '' ): string {
        return wp_unslash( (string)($_REQUEST[$key] ?? $default) );
    }

    private static function normalize_files( array $f ): array {
        if ( ! is_array($f['name']) ) return [$f];
        $out = [];
        for ($i=0;$i<count($f['name']);$i++) $out[] = ['name'=>$f['name'][$i],'tmp_name'=>$f['tmp_name'][$i],'error'=>$f['error'][$i],'size'=>$f['size'][$i]];
        return $out;
    }
}
