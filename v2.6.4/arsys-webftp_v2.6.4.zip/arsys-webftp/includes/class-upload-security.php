<?php
defined( 'ABSPATH' ) || exit;

/**
 * Validacion de seguridad en subida de archivos.
 *
 * Seguridad (OWASP A03 - Injection):
 *  - Lista negra de extensiones peligrosas configurable desde el panel
 *  - Desactivada por defecto para no romper el flujo existente
 *  - El admin puede activarla y personalizar la lista desde Configuracion
 *  - Doble validacion: extension del nombre + tipo MIME real del archivo
 */
class AWFTP_Upload_Security {

    const OPTION_ENABLED    = 'awftp_blacklist_enabled';
    const OPTION_EXTENSIONS = 'awftp_blacklist_extensions';

    /**
     * Extensiones bloqueadas por defecto cuando se activa la lista negra.
     * Basado en extensiones que pueden ejecutarse en servidores web.
     */
    const DEFAULT_BLACKLIST = [
        // PHP y variantes
        'php', 'php2', 'php3', 'php4', 'php5', 'php6', 'php7', 'php8',
        'phtml', 'phar', 'phps',
        // Ejecutables servidor
        'asp', 'aspx', 'asax', 'ashx', 'asmx',
        'cfm', 'cfc',
        'pl', 'py', 'rb', 'cgi',
        'sh', 'bash', 'zsh', 'ksh',
        // Ejecutables sistema
        'exe', 'dll', 'so', 'bat', 'cmd', 'com', 'msi',
        // Otros peligrosos
        'htaccess', 'htpasswd',
        'shtml', 'shtm',
    ];

    // ── Validacion ────────────────────────────────────────────────────────────

    /**
     * Valida un archivo antes de subirlo.
     *
     * @param string $filename  Nombre original del archivo
     * @param string $tmp_path  Ruta temporal del archivo subido
     * @return array{valid: bool, error?: string}
     */
    public static function validate( string $filename, string $tmp_path ): array {
        // Si la lista negra esta desactivada, permitir todo
        if ( ! self::is_enabled() ) {
            return [ 'valid' => true ];
        }

        $blacklist = self::get_blacklist();

        // Validacion 1: Extension del nombre de archivo
        $ext = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );

        if ( in_array( $ext, $blacklist, true ) ) {
            return [
                'valid' => false,
                'error' => sprintf(
                    'El archivo "%s" no esta permitido. Extension bloqueada: .%s',
                    esc_html( $filename ),
                    esc_html( $ext )
                ),
            ];
        }

        // Validacion 2: Tipo MIME real del archivo (si fileinfo esta disponible)
        if ( function_exists( 'finfo_open' ) && file_exists( $tmp_path ) ) {
            $finfo     = finfo_open( FILEINFO_MIME_TYPE );
            $mime_type = finfo_file( $finfo, $tmp_path );
            finfo_close( $finfo );

            if ( self::is_dangerous_mime( $mime_type ) ) {
                return [
                    'valid' => false,
                    'error' => sprintf(
                        'El archivo "%s" no esta permitido. Tipo de contenido bloqueado: %s',
                        esc_html( $filename ),
                        esc_html( $mime_type )
                    ),
                ];
            }
        }

        return [ 'valid' => true ];
    }

    /**
     * Tipos MIME considerados peligrosos independientemente de la extension.
     */
    private static function is_dangerous_mime( string $mime ): bool {
        $dangerous_mimes = [
            'application/x-php',
            'application/php',
            'application/x-httpd-php',
            'application/x-httpd-php-source',
            'text/x-php',
            'application/x-executable',
            'application/x-msdownload',
            'application/x-msdos-program',
            'application/x-sh',
            'application/x-csh',
        ];
        return in_array( strtolower( $mime ), $dangerous_mimes, true );
    }

    // ── Configuracion ─────────────────────────────────────────────────────────

    public static function is_enabled(): bool {
        return (bool) get_option( self::OPTION_ENABLED, false );
    }

    /**
     * Devuelve la lista negra activa como array de extensiones.
     */
    public static function get_blacklist(): array {
        $saved = get_option( self::OPTION_EXTENSIONS, '' );

        if ( empty( $saved ) ) {
            return self::DEFAULT_BLACKLIST;
        }

        // Parsear: una extension por linea, limpiar espacios y puntos
        $lines = explode( "\n", $saved );
        $exts  = [];
        foreach ( $lines as $line ) {
            $ext = strtolower( trim( $line, " \t\n\r\0\x0B." ) );
            if ( ! empty( $ext ) ) {
                $exts[] = $ext;
            }
        }

        return ! empty( $exts ) ? $exts : self::DEFAULT_BLACKLIST;
    }

    /**
     * Devuelve la lista negra como string (para mostrar en el textarea).
     */
    public static function get_blacklist_as_text(): string {
        $saved = get_option( self::OPTION_EXTENSIONS, '' );
        if ( ! empty( $saved ) ) return $saved;
        return implode( "\n", self::DEFAULT_BLACKLIST );
    }

    /**
     * Guarda la configuracion de seguridad de subidas.
     */
    public static function save_settings( bool $enabled, string $extensions_text ): void {
        update_option( self::OPTION_ENABLED, $enabled ? 1 : 0 );

        // Sanitizar: solo letras, numeros, puntos, guiones y saltos de linea
        $clean = preg_replace( '/[^a-zA-Z0-9\.\-\n]/', '', $extensions_text );
        update_option( self::OPTION_EXTENSIONS, trim( $clean ) );
    }

    // ── Limite de tamano para edicion (OWASP A05) ─────────────────────────────

    const OPTION_MAX_EDIT_ENABLED = 'awftp_max_edit_enabled';
    const OPTION_MAX_EDIT_MB      = 'awftp_max_edit_mb';
    const DEFAULT_MAX_EDIT_MB     = 2;

    public static function is_max_edit_enabled(): bool {
        return (bool) get_option( self::OPTION_MAX_EDIT_ENABLED, false );
    }

    public static function get_max_edit_mb(): int {
        return (int) get_option( self::OPTION_MAX_EDIT_MB, self::DEFAULT_MAX_EDIT_MB );
    }

    /**
     * Comprueba si un archivo supera el limite de tamano para edicion.
     * Devuelve true si el archivo PUEDE editarse, false si es demasiado grande.
     */
    public static function can_edit_file( int $file_size_bytes ): bool {
        if ( ! self::is_max_edit_enabled() ) return true;
        $max_bytes = self::get_max_edit_mb() * 1024 * 1024;
        return $file_size_bytes <= $max_bytes;
    }

    // ── Timeout busqueda recursiva (OWASP A05) ────────────────────────────────

    const OPTION_SEARCH_TIMEOUT_ENABLED = 'awftp_search_timeout_enabled';
    const OPTION_SEARCH_TIMEOUT_SECS    = 'awftp_search_timeout_secs';
    const DEFAULT_SEARCH_TIMEOUT_SECS   = 10;

    public static function is_search_timeout_enabled(): bool {
        return (bool) get_option( self::OPTION_SEARCH_TIMEOUT_ENABLED, false );
    }

    public static function get_search_timeout_secs(): int {
        return (int) get_option( self::OPTION_SEARCH_TIMEOUT_SECS, self::DEFAULT_SEARCH_TIMEOUT_SECS );
    }

    /**
     * Guarda toda la configuracion de seguridad de una vez.
     */
    public static function save_all_settings( array $data ): void {
        // Lista negra subidas
        update_option( self::OPTION_ENABLED, ! empty( $data['blacklist_enabled'] ) ? 1 : 0 );
        $clean = preg_replace( '/[^a-zA-Z0-9\.\-\n]/', '', $data['extensions'] ?? '' );
        update_option( self::OPTION_EXTENSIONS, trim( $clean ) );

        // Limite edicion
        update_option( self::OPTION_MAX_EDIT_ENABLED, ! empty( $data['max_edit_enabled'] ) ? 1 : 0 );
        update_option( self::OPTION_MAX_EDIT_MB, max( 1, min( 50, (int) ( $data['max_edit_mb'] ?? self::DEFAULT_MAX_EDIT_MB ) ) ) );

        // Timeout busqueda
        update_option( self::OPTION_SEARCH_TIMEOUT_ENABLED, ! empty( $data['search_timeout_enabled'] ) ? 1 : 0 );
        update_option( self::OPTION_SEARCH_TIMEOUT_SECS, max( 5, min( 60, (int) ( $data['search_timeout_secs'] ?? self::DEFAULT_SEARCH_TIMEOUT_SECS ) ) ) );
    }
}
