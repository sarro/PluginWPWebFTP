<?php
defined( 'ABSPATH' ) || exit;

/**
 * Capa de abstracción SFTP usando la extensión nativa php-ssh2.
 *
 * Seguridad (OWASP A02 - Cryptographic Failures):
 *  - Soporte de autenticación por clave privada SSH (más seguro que contraseña)
 *  - La clave privada se almacena cifrada junto al resto de credenciales
 *  - Fallback a autenticación por contraseña si no hay clave configurada
 *
 * Protección path traversal en full_path().
 */
class AWFTP_SFTP_Manager {

    private $ssh;
    private $sftp;
    private string $root;

    public function __construct( $ssh, $sftp, string $root = '/' ) {
        $this->ssh  = $ssh;
        $this->sftp = $sftp;
        $this->root = rtrim( $root, '/' );
    }

    // ── Conexión ──────────────────────────────────────────────────────────────

    public static function connect(): self {
        $creds = AWFTP_Credentials::get();
        if ( empty( $creds['host'] ) ) {
            throw new \RuntimeException( 'No hay credenciales SFTP configuradas.' );
        }
        return self::connect_with(
            $creds['host'],
            (int) ( $creds['port'] ?? 22 ),
            $creds['username'],
            $creds['password']       ?? '',
            $creds['root_path']      ?? '/',
            $creds['private_key']    ?? '',
            $creds['key_passphrase'] ?? ''
        );
    }

    /**
     * Conexión explícita con credenciales.
     * Intenta autenticación por clave privada primero, luego por contraseña.
     *
     * @throws \RuntimeException
     */
    public static function connect_with(
        string $host,
        int    $port,
        string $username,
        string $password      = '',
        string $root          = '/',
        string $private_key   = '',
        string $key_passphrase= ''
    ): self {
        $ssh = @ssh2_connect( $host, $port );
        if ( ! $ssh ) {
            throw new \RuntimeException( "No se pudo conectar a {$host}:{$port}. Verifica el host y el puerto." );
        }

        $authenticated = false;

        // Método 1: Clave privada SSH (más seguro)
        if ( ! empty( $private_key ) ) {
            $authenticated = self::auth_with_key( $ssh, $username, $private_key, $key_passphrase );
        }

        // Método 2: Contraseña (fallback)
        if ( ! $authenticated && ! empty( $password ) ) {
            $authenticated = @ssh2_auth_password( $ssh, $username, $password );
        }

        if ( ! $authenticated ) {
            throw new \RuntimeException( 'Autenticacion fallida. Verifica las credenciales.' );
        }

        $sftp = @ssh2_sftp( $ssh );
        if ( ! $sftp ) {
            throw new \RuntimeException( 'No se pudo iniciar el subsistema SFTP.' );
        }

        return new self( $ssh, $sftp, $root );
    }

    /**
     * Autenticación por clave privada SSH.
     * Guarda la clave en archivos temporales seguros y los elimina tras autenticar.
     */
    private static function auth_with_key( $ssh, string $username, string $private_key, string $passphrase ): bool {
        $tmp_dir = get_temp_dir();

        // Archivos temporales con permisos restrictivos
        $pub_file  = $tmp_dir . 'awftp_' . bin2hex( random_bytes( 8 ) ) . '.pub';
        $priv_file = $tmp_dir . 'awftp_' . bin2hex( random_bytes( 8 ) ) . '.pem';

        try {
            // Extraer clave pública de la privada si no se proporciona
            // Para ssh2_auth_pubkey_file necesitamos ambas
            file_put_contents( $priv_file, $private_key );
            chmod( $priv_file, 0600 );

            // Intentar auth con clave privada
            // ssh2_auth_pubkey_file requiere fichero de clave pública separado
            // Usamos ssh2_auth_hostbased o generamos la pública
            $pub_key = self::extract_public_key( $private_key, $passphrase );

            if ( $pub_key ) {
                file_put_contents( $pub_file, $pub_key );
                chmod( $pub_file, 0600 );
                $result = @ssh2_auth_pubkey_file( $ssh, $username, $pub_file, $priv_file, $passphrase ?: null );
            } else {
                $result = false;
            }
        } finally {
            // Limpiar archivos temporales siempre
            if ( file_exists( $pub_file ) )  @unlink( $pub_file );
            if ( file_exists( $priv_file ) ) @unlink( $priv_file );
        }

        return (bool) $result;
    }

    /**
     * Extrae la clave pública desde una clave privada PEM.
     * Requiere extensión openssl.
     */
    private static function extract_public_key( string $private_key_pem, string $passphrase ): string|false {
        if ( ! function_exists( 'openssl_pkey_get_private' ) ) return false;

        $key = @openssl_pkey_get_private( $private_key_pem, $passphrase ?: null );
        if ( ! $key ) return false;

        $details = openssl_pkey_get_details( $key );
        return $details['key'] ?? false;
    }

    public function pwd(): string {
        return $this->root ?: '/';
    }

    // ── Directorio ────────────────────────────────────────────────────────────

    public function list_directory( string $path ): array {
        $full   = $this->full_path( $path );
        $handle = @opendir( $this->sftp_url( $full ) );
        if ( ! $handle ) throw new \RuntimeException( "No se puede listar: {$path}" );

        $result = [];
        while ( false !== ( $entry = readdir( $handle ) ) ) {
            if ( $entry === '.' || $entry === '..' ) continue;
            $stat = @ssh2_sftp_stat( $this->sftp, $full . '/' . $entry );
            if ( ! $stat ) continue;
            $is_dir   = ( $stat['mode'] & 0170000 ) === 0040000;
            $result[] = [
                'name'        => $entry,
                'type'        => $is_dir ? 'dir' : 'file',
                'size'        => (int) ( $stat['size'] ?? 0 ),
                'modified'    => (int) ( $stat['mtime'] ?? 0 ),
                'permissions' => $this->format_permissions( (int) ( $stat['mode'] ?? 0 ) ),
            ];
        }
        closedir( $handle );

        usort( $result, function ( $a, $b ) {
            if ( $a['type'] !== $b['type'] ) return $a['type'] === 'dir' ? -1 : 1;
            return strcasecmp( $a['name'], $b['name'] );
        });

        return $result;
    }

    public function create_directory( string $path ): void {
        if ( ! @ssh2_sftp_mkdir( $this->sftp, $this->full_path( $path ), 0755, true ) ) {
            throw new \RuntimeException( "No se pudo crear el directorio: {$path}" );
        }
    }

    // ── Archivo ───────────────────────────────────────────────────────────────

    public function get_file( string $path ): string {
        $content = @file_get_contents( $this->sftp_url( $this->full_path( $path ) ) );
        if ( false === $content ) throw new \RuntimeException( "No se puede leer: {$path}" );
        return $content;
    }

    public function put_file( string $path, string $content ): void {
        if ( false === @file_put_contents( $this->sftp_url( $this->full_path( $path ) ), $content ) ) {
            throw new \RuntimeException( "No se pudo guardar: {$path}" );
        }
    }

    public function upload_file( string $remote_path, string $local_tmp ): void {
        $content = @file_get_contents( $local_tmp );
        if ( false === $content ) throw new \RuntimeException( 'No se puede leer el archivo temporal.' );
        if ( false === @file_put_contents( $this->sftp_url( $this->full_path( $remote_path ) ), $content ) ) {
            throw new \RuntimeException( "Error al subir: {$remote_path}" );
        }
    }

    public function create_file( string $path, string $content = '' ): void {
        $this->put_file( $path, $content );
    }

    public function delete( string $path ): void {
        $full = $this->full_path( $path );
        $stat = @ssh2_sftp_stat( $this->sftp, $full );
        if ( ! $stat ) throw new \RuntimeException( "No existe: {$path}" );
        $is_dir = ( $stat['mode'] & 0170000 ) === 0040000;
        if ( $is_dir ) {
            $this->delete_recursive( $full );
        } elseif ( ! @ssh2_sftp_unlink( $this->sftp, $full ) ) {
            throw new \RuntimeException( "No se pudo eliminar: {$path}" );
        }
    }

    /**
     * Cambia los permisos de un archivo o directorio.
     * @param string $path Ruta relativa
     * @param int    $mode Permisos en octal (ej: 0755)
     * @throws \RuntimeException
     */
    public function chmod( string $path, int $mode ): void {
        $full = $this->full_path( $path );
        if ( ! @ssh2_sftp_chmod( $this->sftp, $full, $mode ) ) {
            throw new \RuntimeException( "No se pudieron cambiar los permisos de: {$path}" );
        }
    }

    public function rename( string $old_path, string $new_path ): void {
        if ( ! @ssh2_sftp_rename( $this->sftp, $this->full_path( $old_path ), $this->full_path( $new_path ) ) ) {
            throw new \RuntimeException( "No se pudo renombrar." );
        }
    }

    // ── Helpers privados ──────────────────────────────────────────────────────

    private function delete_recursive( string $full_path ): void {
        $handle = @opendir( $this->sftp_url( $full_path ) );
        if ( $handle ) {
            while ( false !== ( $entry = readdir( $handle ) ) ) {
                if ( $entry === '.' || $entry === '..' ) continue;
                $entry_full = $full_path . '/' . $entry;
                $stat       = @ssh2_sftp_stat( $this->sftp, $entry_full );
                if ( $stat && ( $stat['mode'] & 0170000 ) === 0040000 ) {
                    $this->delete_recursive( $entry_full );
                } else {
                    @ssh2_sftp_unlink( $this->sftp, $entry_full );
                }
            }
            closedir( $handle );
        }
        if ( ! @ssh2_sftp_rmdir( $this->sftp, $full_path ) ) {
            throw new \RuntimeException( "No se pudo eliminar directorio: {$full_path}" );
        }
    }

    private function sftp_url( string $full_path ): string {
        return 'ssh2.sftp://' . intval( $this->sftp ) . $full_path;
    }

    private function full_path( string $relative ): string {
        $relative = str_replace( '\\', '/', $relative );
        $full     = $this->root . '/' . ltrim( $relative, '/' );
        $parts    = explode( '/', $full );
        $resolved = [];
        foreach ( $parts as $part ) {
            if ( $part === '' || $part === '.' ) continue;
            if ( $part === '..' ) array_pop( $resolved );
            else $resolved[] = $part;
        }
        $safe = '/' . implode( '/', $resolved );
        if ( $this->root !== '' && strpos( $safe, $this->root ) !== 0 ) {
            throw new \RuntimeException( 'Ruta no permitida (path traversal detectado).' );
        }
        return $safe;
    }

    private function format_permissions( int $mode ): string {
        $types = [ 0140000=>'s', 0120000=>'l', 0100000=>'-', 0060000=>'b', 0040000=>'d', 0020000=>'c', 0010000=>'p' ];
        $type  = '-';
        foreach ( $types as $mask => $char ) {
            if ( ( $mode & 0170000 ) === $mask ) { $type = $char; break; }
        }
        return $type
            . (($mode&0400)?'r':'-').(($mode&0200)?'w':'-').(($mode&0100)?'x':'-')
            . (($mode&0040)?'r':'-').(($mode&0020)?'w':'-').(($mode&0010)?'x':'-')
            . (($mode&0004)?'r':'-').(($mode&0002)?'w':'-').(($mode&0001)?'x':'-');
    }
}
