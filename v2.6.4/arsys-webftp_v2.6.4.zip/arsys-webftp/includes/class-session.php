<?php
defined( 'ABSPATH' ) || exit;

/**
 * Gestión de sesiones WebFTP con rate limiting en el login.
 *
 * Seguridad (OWASP A07 - Identification and Authentication Failures):
 *  - Máximo 5 intentos de login fallidos por IP
 *  - Bloqueo automático de 15 minutos tras superar el límite
 *  - Mensaje genérico (no revela si el usuario existe o no)
 *  - Contador se resetea tras login exitoso
 *  - Almacenado en transients de WP (sin nueva tabla de BD)
 */
class AWFTP_Session {

    const COOKIE_NAME      = 'awftp_session';
    const SESSION_HOURS    = 8;
    const MAX_LOGIN_ATTEMPTS = 5;
    const LOCKOUT_MINUTES  = 15;
    const RATE_LIMIT_PREFIX = 'awftp_login_attempts_';

    // ── Login con rate limiting ───────────────────────────────────────────────

    public static function login( string $username, string $password ): array {
        $ip = self::get_client_ip();

        // Comprobar si la IP está bloqueada
        if ( self::is_locked_out( $ip ) ) {
            $remaining = self::lockout_remaining( $ip );
            return [
                'success'  => false,
                'error'    => sprintf(
                    'Demasiados intentos fallidos. Intenta de nuevo en %d minuto(s).',
                    $remaining
                ),
                'locked'   => true,
            ];
        }

        $user = wp_authenticate( $username, $password );

        if ( is_wp_error( $user ) ) {
            self::record_failed_attempt( $ip );
            $attempts_left = self::MAX_LOGIN_ATTEMPTS - self::get_attempts( $ip );

            return [
                'success' => false,
                // Mensaje genérico: no revela si el usuario existe
                'error'   => $attempts_left > 0
                    ? sprintf( 'Credenciales incorrectas. %d intento(s) restante(s).', $attempts_left )
                    : sprintf( 'Demasiados intentos fallidos. Bloqueado %d minutos.', self::LOCKOUT_MINUTES ),
            ];
        }

        $required_cap = apply_filters( 'awftp_required_capability', 'manage_options' );

        if ( ! user_can( $user, $required_cap ) ) {
            // También contar como intento fallido
            self::record_failed_attempt( $ip );
            return [ 'success' => false, 'error' => 'Credenciales incorrectas.' ];
        }

        // Login exitoso: limpiar contador de intentos
        self::clear_attempts( $ip );

        $token = self::create_session( $user->ID );

        return [ 'success' => true, 'token' => $token, 'user' => $user->display_name ];
    }

    // ── Rate limiting ─────────────────────────────────────────────────────────

    /**
     * Registra un intento fallido para la IP dada.
     * Bloquea automáticamente si se supera el máximo.
     */
    private static function record_failed_attempt( string $ip ): void {
        $key      = self::RATE_LIMIT_PREFIX . md5( $ip );
        $attempts = (int) get_transient( $key );
        $attempts++;

        // Guardar con TTL de LOCKOUT_MINUTES
        set_transient( $key, $attempts, self::LOCKOUT_MINUTES * 60 );
    }

    /**
     * Devuelve el número de intentos fallidos actuales para la IP.
     */
    private static function get_attempts( string $ip ): int {
        $key = self::RATE_LIMIT_PREFIX . md5( $ip );
        return (int) get_transient( $key );
    }

    /**
     * Comprueba si la IP está bloqueada.
     */
    private static function is_locked_out( string $ip ): bool {
        return self::get_attempts( $ip ) >= self::MAX_LOGIN_ATTEMPTS;
    }

    /**
     * Minutos restantes de bloqueo (aproximado).
     */
    private static function lockout_remaining( string $ip ): int {
        // WP no expone el TTL restante de un transient directamente
        // Usamos una clave secundaria con el timestamp de inicio del bloqueo
        $ts_key = self::RATE_LIMIT_PREFIX . 'ts_' . md5( $ip );
        $ts     = (int) get_transient( $ts_key );
        if ( ! $ts ) return self::LOCKOUT_MINUTES;
        $elapsed  = (int) floor( ( time() - $ts ) / 60 );
        $remaining= self::LOCKOUT_MINUTES - $elapsed;
        return max( 1, $remaining );
    }

    /**
     * Limpia el contador de intentos tras login exitoso.
     */
    private static function clear_attempts( string $ip ): void {
        $key    = self::RATE_LIMIT_PREFIX . md5( $ip );
        $ts_key = self::RATE_LIMIT_PREFIX . 'ts_' . md5( $ip );
        delete_transient( $key );
        delete_transient( $ts_key );
    }

    /**
     * Obtiene la IP real del cliente de forma segura.
     * Solo usa REMOTE_ADDR (fiable) — no cabeceras manipulables como X-Forwarded-For.
     */
    private static function get_client_ip(): string {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '0.0.0.0';
    }

    // ── Sesión ────────────────────────────────────────────────────────────────

    public static function create_session( int $user_id ): string {
        global $wpdb;

        $wpdb->delete( $wpdb->prefix . 'awftp_sessions', [ 'user_id' => $user_id ], [ '%d' ] );

        $token      = bin2hex( random_bytes( 32 ) );
        $expires_at = gmdate( 'Y-m-d H:i:s', time() + self::SESSION_HOURS * 3600 );

        $wpdb->insert(
            $wpdb->prefix . 'awftp_sessions',
            [ 'user_id' => $user_id, 'session_token' => $token, 'expires_at' => $expires_at ],
            [ '%d', '%s', '%s' ]
        );

        setcookie( self::COOKIE_NAME, $token, [
            'expires'  => time() + self::SESSION_HOURS * 3600,
            'path'     => '/wp-admin/',
            'secure'   => is_ssl(),
            'httponly' => true,
            'samesite' => 'Strict',
        ]);

        return $token;
    }

    // ── Rotacion de token (OWASP A07) ─────────────────────────────────────────

    /**
     * Rota el token de sesion tras operaciones sensibles (delete, save, upload).
     * Genera un nuevo token y actualiza la cookie sin interrumpir la sesion.
     * Esto invalida tokens robados tras una operacion critica.
     */
    public static function rotate_token(): void {
        $old_token = $_COOKIE[ self::COOKIE_NAME ] ?? '';
        if ( empty( $old_token ) || strlen( $old_token ) !== 64 ) return;

        global $wpdb;

        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT user_id, expires_at FROM {$wpdb->prefix}awftp_sessions WHERE session_token = %s LIMIT 1",
            sanitize_text_field( $old_token )
        ));

        if ( ! $row ) return;

        // Generar nuevo token
        $new_token = bin2hex( random_bytes( 32 ) );

        // Actualizar en BD (mantener el mismo expires_at)
        $wpdb->update(
            $wpdb->prefix . 'awftp_sessions',
            [ 'session_token' => $new_token ],
            [ 'session_token' => $old_token ],
            [ '%s' ],
            [ '%s' ]
        );

        // Actualizar cookie con el nuevo token
        $expires = strtotime( $row->expires_at );
        setcookie( self::COOKIE_NAME, $new_token, [
            'expires'  => $expires,
            'path'     => '/wp-admin/',
            'secure'   => is_ssl(),
            'httponly' => true,
            'samesite' => 'Strict',
        ]);

        // Actualizar la cookie en la peticion actual
        $_COOKIE[ self::COOKIE_NAME ] = $new_token;
    }

    public static function validate(): int|false {
        $token = $_COOKIE[ self::COOKIE_NAME ] ?? '';

        if ( empty( $token ) || strlen( $token ) !== 64 ) return false;

        global $wpdb;

        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT user_id, expires_at FROM {$wpdb->prefix}awftp_sessions WHERE session_token = %s LIMIT 1",
            sanitize_text_field( $token )
        ));

        if ( ! $row ) return false;

        if ( strtotime( $row->expires_at ) < time() ) {
            $wpdb->delete( $wpdb->prefix . 'awftp_sessions', [ 'session_token' => $token ], [ '%s' ] );
            return false;
        }

        $required_cap = apply_filters( 'awftp_required_capability', 'manage_options' );
        if ( ! user_can( (int) $row->user_id, $required_cap ) ) return false;

        return (int) $row->user_id;
    }

    public static function is_logged_in(): bool {
        return self::validate() !== false;
    }

    public static function logout(): void {
        $token = $_COOKIE[ self::COOKIE_NAME ] ?? '';

        if ( ! empty( $token ) ) {
            global $wpdb;
            $wpdb->delete(
                $wpdb->prefix . 'awftp_sessions',
                [ 'session_token' => sanitize_text_field( $token ) ],
                [ '%s' ]
            );
        }

        setcookie( self::COOKIE_NAME, '', [
            'expires'  => time() - 3600,
            'path'     => '/wp-admin/',
            'secure'   => is_ssl(),
            'httponly' => true,
            'samesite' => 'Strict',
        ]);
    }

    public static function get_current_user(): ?\WP_User {
        $user_id = self::validate();
        if ( ! $user_id ) return null;
        return get_user_by( 'id', $user_id ) ?: null;
    }

    public static function cleanup_expired(): void {
        global $wpdb;
        $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$wpdb->prefix}awftp_sessions WHERE expires_at < %s",
            gmdate( 'Y-m-d H:i:s' )
        ));
    }
}
