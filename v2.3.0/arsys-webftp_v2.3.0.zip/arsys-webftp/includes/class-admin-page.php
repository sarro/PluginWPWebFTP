<?php
defined( 'ABSPATH' ) || exit;

class AWFTP_Admin_Page {

    public static function init(): void {
        $self = new self();
        add_action( 'admin_menu',            [ $self, 'register_menu' ] );
        add_action( 'admin_enqueue_scripts', [ $self, 'enqueue_assets' ] );
        add_action( 'admin_post_awftp_save_credentials', [ $self, 'handle_save_credentials' ] );
        add_action( 'wp_scheduled_delete',   [ self::class, 'cleanup_sessions' ] );
    }

    public function register_menu(): void {
        add_menu_page( 'Arsys WebFTP', 'WebFTP', 'read', 'arsys-webftp',
            [ $this, 'render_page' ], 'dashicons-portfolio', 80 );
        add_submenu_page( 'arsys-webftp', 'Explorador', 'Explorador',
            'read', 'arsys-webftp', [ $this, 'render_page' ] );
        add_submenu_page( 'arsys-webftp', 'Configuracion SFTP', 'Configuracion',
            'manage_options', 'arsys-webftp-settings', [ $this, 'render_settings' ] );
    }

    public function enqueue_assets( string $hook ): void {
        if ( strpos( $hook, 'arsys-webftp' ) === false ) return;
        wp_enqueue_style(  'awftp-style', AWFTP_URL . 'assets/css/webftp.css', [], AWFTP_VERSION );
        wp_enqueue_script( 'awftp-app',   AWFTP_URL . 'assets/js/webftp.js', [ 'jquery' ], AWFTP_VERSION, true );
        wp_localize_script( 'awftp-app', 'AWFTP', [
            'ajax_url'    => admin_url( 'admin-ajax.php' ),
            'nonce'       => wp_create_nonce( 'awftp_nonce' ),
            'login_nonce' => wp_create_nonce( 'awftp_login_nonce' ),
            'logged_in'   => AWFTP_Session::is_logged_in() ? '1' : '0',
            'root'        => AWFTP_Credentials::get()['root_path'] ?? '/',
        ]);
    }

    public function render_page(): void {
        if ( ! AWFTP_Session::is_logged_in() ) { $this->render_login(); return; }
        if ( ! AWFTP_Credentials::has_credentials() ) {
            echo '<div class="wrap"><div class="notice notice-warning"><p>';
            echo current_user_can( 'manage_options' )
                ? 'WebFTP no esta configurado. <a href="' . esc_url( admin_url( 'admin.php?page=arsys-webftp-settings' ) ) . '">Ir a Configuracion</a>'
                : 'WebFTP no esta configurado. Contacta con el administrador.';
            echo '</p></div></div>';
            return;
        }
        $this->render_explorer();
    }

    // ── Login ─────────────────────────────────────────────────────────────────

    private function render_login(): void {
        $u = wp_get_current_user();
        ?>
        <div class="awftp-login-wrap">
            <div class="awftp-login-card" id="awftp-login-card">
                <div class="awftp-login-logo">
                    <span class="awftp-login-icon">&#9889;</span>
                    <h1>Arsys <strong>WebFTP</strong></h1>
                    <p class="awftp-login-sub">Explorador SFTP seguro</p>
                </div>
                <div id="awftp-login-error" class="awftp-login-error" style="display:none"></div>
                <div class="awftp-login-form">
                    <div class="awftp-field">
                        <label for="awftp-login-user">Usuario de WordPress</label>
                        <div class="awftp-input-wrap">
                            <span class="awftp-input-icon">&#128100;</span>
                            <input type="text" id="awftp-login-user" value="<?php echo esc_attr( $u->user_login ?? '' ); ?>" placeholder="usuario" autocomplete="username" />
                        </div>
                    </div>
                    <div class="awftp-field">
                        <label for="awftp-login-pass">Contrasena</label>
                        <div class="awftp-input-wrap">
                            <span class="awftp-input-icon">&#128273;</span>
                            <input type="password" id="awftp-login-pass" placeholder="&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;" autocomplete="current-password" />
                        </div>
                    </div>
                    <button id="awftp-login-btn" class="awftp-login-submit">
                        <span class="awftp-login-btn-text">Acceder al explorador</span>
                        <span class="awftp-login-spinner" style="display:none"><span class="awftp-spinner"></span></span>
                    </button>
                </div>
                <p class="awftp-login-note">&#128274; Usa tu usuario y contrasena de WordPress.<br><small>Solo administradores pueden acceder.</small></p>
            </div>
        </div>
        <?php
    }

    // ── Explorador ────────────────────────────────────────────────────────────

    private function render_explorer(): void {
        $wftp_user = AWFTP_Session::get_current_user();
        ?>
        <div class="wrap awftp-wrap">
            <h1 class="awftp-title">
                <span class="awftp-logo">&#9889;</span> Arsys WebFTP
                <span class="awftp-badge">SFTP</span>
                <span class="awftp-user-info">
                    &#128100; <?php echo esc_html( $wftp_user ? $wftp_user->display_name : '' ); ?>
                    <button id="awftp-logout-btn" class="button button-small">&#128682; Cerrar sesion</button>
                </span>
            </h1>

            <div id="awftp-app">
                <!-- Toolbar -->
                <div class="awftp-toolbar">
                    <div class="awftp-path-bar">
                        <span class="awftp-path-label">&#128193;</span>
                        <input type="text" id="awftp-current-path" readonly value="/" />
                        <button id="awftp-btn-up">&#8593; Subir</button>
                        <button id="awftp-btn-refresh">&#8635; Recargar</button>
                    </div>
                    <div class="awftp-actions">
                        <button id="awftp-btn-new-folder" class="button button-secondary">&#128193; Nueva carpeta</button>
                        <button id="awftp-btn-new-file"   class="button button-secondary">&#128196; Nuevo archivo</button>
                        <label class="button button-primary" id="awftp-upload-label">
                            &#11014; Subir archivo
                            <input type="file" id="awftp-upload-input" multiple style="display:none" />
                        </label>
                    </div>
                </div>

                <!-- Barra de busqueda -->
                <div class="awftp-search-bar">
                    <span style="font-size:15px">&#128269;</span>
                    <input type="text" id="awftp-search-input" placeholder="Buscar archivos en el directorio actual y subdirectorios..." />
                    <button id="awftp-search-btn" class="button button-secondary">Buscar</button>
                    <button id="awftp-search-clear" class="button button-secondary">&#10005; Limpiar</button>
                </div>

                <!-- Resultados de busqueda -->
                <div id="awftp-search-results" style="display:none">
                    <div class="awftp-search-header">
                        <span>Resultados de busqueda</span>
                        <span id="awftp-search-count"></span>
                    </div>
                    <table class="awftp-search-table">
                        <tbody id="awftp-search-list"></tbody>
                    </table>
                </div>

                <!-- Progreso de subida -->
                <div id="awftp-upload-progress" style="display:none">
                    <div class="awftp-progress-bar"><div class="awftp-progress-fill" id="awftp-progress-fill"></div></div>
                    <span id="awftp-progress-text">Subiendo...</span>
                </div>

                <!-- Tabla de archivos -->
                <div class="awftp-explorer">
                    <table class="awftp-table wp-list-table widefat fixed striped">
                        <thead><tr>
                            <th class="col-icon"></th>
                            <th class="col-name">Nombre</th>
                            <th class="col-size">Tamano</th>
                            <th class="col-date">Modificado</th>
                            <th class="col-perms">Permisos</th>
                            <th class="col-actions">Acciones</th>
                        </tr></thead>
                        <tbody id="awftp-file-list">
                            <tr><td colspan="6" class="awftp-loading"><span class="awftp-spinner"></span> Cargando...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <?php $this->render_modals(); ?>
            <div id="awftp-overlay" class="awftp-overlay" style="display:none"></div>
            <div id="awftp-notifications"></div>
        </div>
        <?php
    }

    // ── Modales ───────────────────────────────────────────────────────────────

    private function render_modals(): void { ?>
        <!-- Editor -->
        <div id="awftp-modal-editor" class="awftp-modal" style="display:none">
            <div class="awftp-modal-content awftp-modal-large">
                <div class="awftp-modal-header">
                    <h2>Editar: <span id="awftp-editor-filename"></span></h2>
                    <button class="awftp-modal-close" data-modal="awftp-modal-editor">&#10005;</button>
                </div>
                <div class="awftp-modal-body"><textarea id="awftp-editor-content" spellcheck="false"></textarea></div>
                <div class="awftp-modal-footer">
                    <button id="awftp-btn-save-file" class="button button-primary">Guardar</button>
                    <button class="button awftp-modal-close" data-modal="awftp-modal-editor">Cancelar</button>
                </div>
            </div>
        </div>
        <!-- Vista previa -->
        <div id="awftp-modal-preview" class="awftp-modal" style="display:none">
            <div class="awftp-modal-content awftp-modal-preview-size">
                <div class="awftp-modal-header">
                    <h2>&#128247; Vista previa: <span id="awftp-preview-filename"></span></h2>
                    <button class="awftp-modal-close" data-modal="awftp-modal-preview">&#10005;</button>
                </div>
                <div class="awftp-modal-body">
                    <div class="awftp-preview-container">
                        <img id="awftp-preview-img" src="" alt="Vista previa" />
                    </div>
                    <p id="awftp-preview-info"></p>
                </div>
                <div class="awftp-modal-footer">
                    <button class="button awftp-modal-close" data-modal="awftp-modal-preview">Cerrar</button>
                </div>
            </div>
        </div>
        <!-- Renombrar -->
        <div id="awftp-modal-rename" class="awftp-modal" style="display:none">
            <div class="awftp-modal-content">
                <div class="awftp-modal-header">
                    <h2>Renombrar</h2>
                    <button class="awftp-modal-close" data-modal="awftp-modal-rename">&#10005;</button>
                </div>
                <div class="awftp-modal-body">
                    <label>Nuevo nombre:</label>
                    <input type="text" id="awftp-rename-input" class="regular-text" />
                    <input type="hidden" id="awftp-rename-old" />
                </div>
                <div class="awftp-modal-footer">
                    <button id="awftp-btn-confirm-rename" class="button button-primary">Renombrar</button>
                    <button class="button awftp-modal-close" data-modal="awftp-modal-rename">Cancelar</button>
                </div>
            </div>
        </div>
        <!-- Crear -->
        <div id="awftp-modal-new" class="awftp-modal" style="display:none">
            <div class="awftp-modal-content">
                <div class="awftp-modal-header">
                    <h2 id="awftp-modal-new-title">Crear nuevo</h2>
                    <button class="awftp-modal-close" data-modal="awftp-modal-new">&#10005;</button>
                </div>
                <div class="awftp-modal-body">
                    <label id="awftp-modal-new-label">Nombre:</label>
                    <input type="text" id="awftp-new-name-input" class="regular-text" />
                    <input type="hidden" id="awftp-new-type" value="folder" />
                </div>
                <div class="awftp-modal-footer">
                    <button id="awftp-btn-confirm-new" class="button button-primary">Crear</button>
                    <button class="button awftp-modal-close" data-modal="awftp-modal-new">Cancelar</button>
                </div>
            </div>
        </div>
        <!-- Borrar -->
        <div id="awftp-modal-delete" class="awftp-modal" style="display:none">
            <div class="awftp-modal-content">
                <div class="awftp-modal-header">
                    <h2>Confirmar eliminacion</h2>
                    <button class="awftp-modal-close" data-modal="awftp-modal-delete">&#10005;</button>
                </div>
                <div class="awftp-modal-body">
                    <p>Eliminar <strong id="awftp-delete-name"></strong>?</p>
                    <p class="awftp-warning">Esta accion no se puede deshacer.</p>
                    <input type="hidden" id="awftp-delete-path" />
                </div>
                <div class="awftp-modal-footer">
                    <button id="awftp-btn-confirm-delete" class="button button-primary awftp-btn-danger">Eliminar</button>
                    <button class="button awftp-modal-close" data-modal="awftp-modal-delete">Cancelar</button>
                </div>
            </div>
        </div>
    <?php }

    // ── Configuracion ─────────────────────────────────────────────────────────

    public function render_settings(): void {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Acceso no autorizado.' );
        $tab   = sanitize_text_field( $_GET['tab'] ?? 'sftp' );
        $creds = AWFTP_Credentials::get();
        ?>
        <div class="wrap">
            <h1>&#9881; Configuracion — Arsys WebFTP <span style="font-size:13px;font-weight:400;color:#6b7280">v<?php echo AWFTP_VERSION; ?></span></h1>

            <!-- Pestanas -->
            <nav class="nav-tab-wrapper" style="margin-bottom:20px">
                <a href="?page=arsys-webftp-settings&tab=sftp"  class="nav-tab <?php echo $tab==='sftp'  ?'nav-tab-active':''; ?>">&#128274; Conexion SFTP</a>
                <a href="?page=arsys-webftp-settings&tab=log"   class="nav-tab <?php echo $tab==='log'   ?'nav-tab-active':''; ?>">&#128196; Log de actividad</a>
                <a href="?page=arsys-webftp-settings&tab=users" class="nav-tab <?php echo $tab==='users' ?'nav-tab-active':''; ?>">&#128100; Usuarios</a>
            </nav>

            <?php if ( $tab === 'sftp' ) : ?>
                <?php if ( isset($_GET['saved']) ) : ?>
                    <div class="notice notice-success is-dismissible"><p>Credenciales guardadas correctamente.</p></div>
                <?php endif; ?>
                <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
                    <?php wp_nonce_field( 'awftp_save_credentials', 'awftp_credentials_nonce' ); ?>
                    <input type="hidden" name="action" value="awftp_save_credentials" />
                    <table class="form-table" role="presentation">
                        <tr><th><label for="awftp_host">Host SFTP</label></th><td>
                            <input type="text" name="awftp_host" id="awftp_host" class="regular-text" value="<?php echo esc_attr($creds['host']??''); ?>" placeholder="sftp.arsys.es" required />
                        </td></tr>
                        <tr><th><label for="awftp_port">Puerto</label></th><td>
                            <input type="number" name="awftp_port" id="awftp_port" class="small-text" value="<?php echo esc_attr($creds['port']??22); ?>" min="1" max="65535" />
                        </td></tr>
                        <tr><th><label for="awftp_username">Usuario SFTP</label></th><td>
                            <input type="text" name="awftp_username" id="awftp_username" class="regular-text" value="<?php echo esc_attr($creds['username']??''); ?>" autocomplete="off" required />
                        </td></tr>
                        <tr><th><label for="awftp_password">Contrasena SFTP</label></th><td>
                            <input type="password" name="awftp_password" id="awftp_password" class="regular-text" value="" autocomplete="new-password" />
                            <p class="description">Dejala en blanco para mantener la guardada.</p>
                        </td></tr>
                        <tr><th><label for="awftp_root_path">Directorio raiz</label></th><td>
                            <input type="text" name="awftp_root_path" id="awftp_root_path" class="regular-text" value="<?php echo esc_attr($creds['root_path']??'/'); ?>" placeholder="/home/usuario/public_html" />
                            <p class="description">Ruta base de navegacion.</p>
                        </td></tr>
                    </table>
                    <h2>Prueba de conexion</h2>
                    <p>
                        <button type="button" id="awftp-test-connection" class="button button-secondary">Probar conexion SFTP</button>
                        <span id="awftp-test-result" style="margin-left:12px;font-weight:600;"></span>
                    </p>
                    <?php submit_button( 'Guardar credenciales' ); ?>
                </form>

            <?php elseif ( $tab === 'log' ) : ?>
                <div id="awftp-log-section">
                    <div class="awftp-log-filters">
                        <div>
                            <label>Accion</label>
                            <select id="awftp-log-filter-action">
                                <option value="">Todas</option>
                                <?php foreach(['login','logout','list','download','upload','edit','delete','rename','create_file','create_dir','search'] as $a): ?>
                                    <option value="<?php echo $a; ?>"><?php echo AWFTP_Activity_Log::action_label($a); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label>Usuario</label>
                            <input type="text" id="awftp-log-filter-user" placeholder="nombre..." style="width:140px" />
                        </div>
                        <div>
                            <label>Desde</label>
                            <input type="date" id="awftp-log-date-from" />
                        </div>
                        <div>
                            <label>Hasta</label>
                            <input type="date" id="awftp-log-date-to" />
                        </div>
                        <div style="padding-top:20px">
                            <button id="awftp-log-btn-filter" class="button button-secondary">Filtrar</button>
                            <button id="awftp-log-btn-reset"  class="button button-secondary">Limpiar</button>
                        </div>
                        <div style="padding-top:20px;margin-left:auto">
                            <button id="awftp-log-btn-clear" class="button awftp-btn-danger">Vaciar log</button>
                        </div>
                    </div>
                    <table class="awftp-log-table widefat">
                        <thead><tr>
                            <th>Fecha</th><th>Usuario</th><th>Accion</th><th>Ruta</th><th>Extra</th><th>IP</th>
                        </tr></thead>
                        <tbody id="awftp-log-body">
                            <tr><td colspan="6" style="text-align:center;padding:20px;color:#6b7280"><span class="awftp-spinner"></span> Cargando...</td></tr>
                        </tbody>
                    </table>
                    <div class="awftp-log-pagination" id="awftp-log-pagination"></div>
                </div>

            <?php elseif ( $tab === 'users' ) : ?>
                <h2>Usuarios con acceso a WebFTP</h2>
                <p>Pueden acceder los usuarios con rol <strong>Administrador</strong>:</p>
                <ul>
                    <?php foreach ( get_users(['role'=>'administrator','fields'=>['display_name','user_login']]) as $u ) {
                        printf('<li>&#128100; <strong>%s</strong> <code>(%s)</code></li>', esc_html($u->display_name), esc_html($u->user_login));
                    } ?>
                </ul>
                <p class="description">Para cambiar los permisos de acceso usa el filtro <code>awftp_required_capability</code> en tu tema o plugin.</p>
            <?php endif; ?>
        </div>

        <script>
        jQuery(function($){
            // Test conexion
            $('#awftp-test-connection').on('click',function(){
                var $btn=$(this),$r=$('#awftp-test-result');
                $btn.prop('disabled',true).text('Conectando...');$r.text('').css('color','');
                $.post(ajaxurl,{action:'awftp_test_connection',nonce:'<?php echo wp_create_nonce("awftp_nonce"); ?>',
                    host:$('#awftp_host').val(),port:$('#awftp_port').val(),username:$('#awftp_username').val(),password:$('#awftp_password').val()
                },function(res){
                    if(res.success)$r.text('OK: '+res.data.message).css('color','#057a55');
                    else $r.text('Error: '+res.data.message).css('color','#e02424');
                }).always(function(){$btn.prop('disabled',false).text('Probar conexion SFTP');});
            });

            // Log
            var logPage=1,logAction='',logUser='',logFrom='',logTo='';
            function loadLog(page){
                logPage=page||1;
                $('#awftp-log-body').html('<tr><td colspan="6" style="text-align:center;padding:20px"><span class="awftp-spinner"></span></td></tr>');
                $.post(ajaxurl,{action:'awftp_get_log',nonce:'<?php echo wp_create_nonce("awftp_nonce"); ?>',
                    page:logPage,filter_action:logAction,filter_user:logUser,date_from:logFrom,date_to:logTo
                },function(res){
                    if(!res.success){$('#awftp-log-body').html('<tr><td colspan="6">Error al cargar el log.</td></tr>');return;}
                    var d=res.data,$b=$('#awftp-log-body');$b.empty();
                    if(!d.entries||!d.entries.length){$b.html('<tr><td colspan="6" style="text-align:center;padding:20px;color:#6b7280">Sin registros</td></tr>');return;}
                    $.each(d.entries,function(i,e){
                        var date=new Date(e.created_at.replace(' ','T')).toLocaleString('es-ES',{dateStyle:'short',timeStyle:'short'});
                        $b.append('<tr><td>'+date+'</td><td>'+$('<span>').text(e.username).html()+'</td><td>'+$('<span>').text(e.action).html()+'</td><td class="awftp-log-path">'+$('<span>').text(e.path||'').html()+'</td><td>'+$('<span>').text(e.extra||'').html()+'</td><td>'+$('<span>').text(e.ip).html()+'</td></tr>');
                    });
                    var $p=$('#awftp-log-pagination');$p.empty();
                    $p.append('<span>Total: '+d.total+' registros</span>');
                    if(d.pages>1){
                        if(d.page>1)$p.append(' <button class="button button-small awftp-log-prev">Anterior</button> ');
                        $p.append('<span>Pag. '+d.page+' / '+d.pages+'</span>');
                        if(d.page<d.pages)$p.append(' <button class="button button-small awftp-log-next">Siguiente</button>');
                    }
                });
            }
            $('#awftp-log-btn-filter').on('click',function(){logAction=$('#awftp-log-filter-action').val();logUser=$('#awftp-log-filter-user').val();logFrom=$('#awftp-log-date-from').val();logTo=$('#awftp-log-date-to').val();loadLog(1);});
            $('#awftp-log-btn-reset').on('click',function(){$('#awftp-log-filter-action').val('');$('#awftp-log-filter-user').val('');$('#awftp-log-date-from').val('');$('#awftp-log-date-to').val('');logAction=logUser=logFrom=logTo='';loadLog(1);});
            $(document).on('click','.awftp-log-prev',function(){loadLog(logPage-1);});
            $(document).on('click','.awftp-log-next',function(){loadLog(logPage+1);});
            $('#awftp-log-btn-clear').on('click',function(){
                if(!confirm('Vaciar el log de actividad? Esta accion no se puede deshacer.'))return;
                $.post(ajaxurl,{action:'awftp_clear_log',nonce:'<?php echo wp_create_nonce("awftp_nonce"); ?>'},function(res){
                    if(res.success){loadLog(1);alert(res.data.message);}
                });
            });
            if($('#awftp-log-body').length) loadLog(1);
        });
        </script>
        <?php
    }

    public function handle_save_credentials(): void {
        check_admin_referer( 'awftp_save_credentials', 'awftp_credentials_nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Acceso no autorizado.' );
        $existing = AWFTP_Credentials::get();
        $password = $_POST['awftp_password'] ?? '';
        if ( empty($password) && ! empty($existing['password']) ) $password = $existing['password'];
        AWFTP_Credentials::save([
            'host'      => sanitize_text_field( $_POST['awftp_host']      ?? '' ),
            'port'      => absint( $_POST['awftp_port'] ?? 22 ),
            'username'  => sanitize_text_field( $_POST['awftp_username']  ?? '' ),
            'password'  => $password,
            'root_path' => sanitize_text_field( $_POST['awftp_root_path'] ?? '/' ),
        ]);
        wp_redirect( admin_url('admin.php?page=arsys-webftp-settings&saved=1') );
        exit;
    }

    public static function cleanup_sessions(): void {
        AWFTP_Session::cleanup_expired();
    }
}
