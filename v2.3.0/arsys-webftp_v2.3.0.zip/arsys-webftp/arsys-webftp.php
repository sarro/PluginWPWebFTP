<?php
/**
 * Plugin Name:       Arsys WebFTP
 * Plugin URI:        https://www.arsys.es
 * Description:       Explorador SFTP integrado en WordPress. Acceso protegido con login de usuario WordPress. Sin dependencias externas.
 * Version:           2.3.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Arsys (IONOS Group)
 * License:           GPL-2.0+
 * Text Domain:       arsys-webftp
 */

defined( 'ABSPATH' ) || exit;

define( 'AWFTP_VERSION',  '2.3.0' );
define( 'AWFTP_DIR',      plugin_dir_path( __FILE__ ) );
define( 'AWFTP_URL',      plugin_dir_url( __FILE__ ) );
define( 'AWFTP_BASENAME', plugin_basename( __FILE__ ) );

function awftp_check_requirements(): bool {
    return extension_loaded( 'ssh2' );
}

register_activation_hook( __FILE__, 'awftp_activate' );
function awftp_activate(): void {
    if ( ! awftp_check_requirements() ) {
        deactivate_plugins( plugin_basename( __FILE__ ) );
        wp_die(
            '<p><strong>Arsys WebFTP</strong> requiere la extension PHP <code>ssh2</code>.</p>' .
            '<p>Activala desde el panel de control de tu hosting.</p>' .
            '<p><a href="' . esc_url( admin_url( 'plugins.php' ) ) . '">&laquo; Volver a plugins</a></p>',
            'Requisito no cumplido',
            [ 'back_link' => false ]
        );
    }
    awftp_create_tables();
}

function awftp_create_tables(): void {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    // Tabla de sesiones
    $sessions = $wpdb->prefix . 'awftp_sessions';
    dbDelta( "CREATE TABLE IF NOT EXISTS {$sessions} (
        id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id       BIGINT UNSIGNED NOT NULL,
        session_token VARCHAR(64)     NOT NULL,
        created_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        expires_at    DATETIME        NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY session_token (session_token),
        KEY user_id (user_id)
    ) {$charset};" );

    // Tabla de log de actividad
    $log = $wpdb->prefix . 'awftp_activity_log';
    dbDelta( "CREATE TABLE IF NOT EXISTS {$log} (
        id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id    BIGINT UNSIGNED NOT NULL DEFAULT 0,
        username   VARCHAR(100)    NOT NULL DEFAULT '',
        action     VARCHAR(30)     NOT NULL DEFAULT '',
        path       TEXT,
        extra      VARCHAR(255)    DEFAULT NULL,
        ip         VARCHAR(45)     NOT NULL DEFAULT '',
        created_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY user_id    (user_id),
        KEY action     (action),
        KEY created_at (created_at)
    ) {$charset};" );
}

register_deactivation_hook( __FILE__, 'awftp_deactivate' );
function awftp_deactivate(): void {
    global $wpdb;
    $wpdb->query( "DELETE FROM {$wpdb->prefix}awftp_sessions WHERE 1=1" );
}

add_action( 'plugins_loaded', function () {
    if ( ! awftp_check_requirements() ) {
        add_action( 'admin_notices', function () {
            echo '<div class="notice notice-error"><p>';
            echo '<strong>Arsys WebFTP:</strong> La extension PHP <code>ssh2</code> no esta disponible. ';
            echo 'Activala desde tu panel de hosting.';
            echo '</p></div>';
        });
        return;
    }

    require_once AWFTP_DIR . 'includes/class-credentials.php';
    require_once AWFTP_DIR . 'includes/class-session.php';
    require_once AWFTP_DIR . 'includes/class-sftp-manager.php';
    require_once AWFTP_DIR . 'includes/class-activity-log.php';
    require_once AWFTP_DIR . 'includes/class-admin-page.php';
    require_once AWFTP_DIR . 'includes/class-ajax-handler.php';
    require_once AWFTP_DIR . 'includes/class-updater.php';

    AWFTP_Admin_Page::init();
    AWFTP_Ajax_Handler::init();
    AWFTP_Updater::init();
});
