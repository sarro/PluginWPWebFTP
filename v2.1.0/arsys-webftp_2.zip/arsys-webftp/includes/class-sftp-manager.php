<?php
defined( 'ABSPATH' ) || exit;

/**
 * Capa de abstracción SFTP usando la extensión nativa php-ssh2.
 *
 * No requiere Composer ni dependencias externas.
 * Requiere: extension_loaded('ssh2') → php-ssh2 instalado en el servidor.
 *
 * Todas las rutas son normalizadas y validadas contra path traversal.
 */
class AWFTP_SFTP_Manager {

    /** @var resource Conexión SSH2 */
    private $ssh;

    /** @var resource Subsistema SFTP */
    private $sftp;

    private string $root;

    /**
     * @param resource $ssh  Conexión SSH2 autenticada
     * @param resource $sftp Subsistema SFTP
     * @param string   $root Directorio raíz de navegación
     */
    public function __construct( $ssh, $sftp, string $root = '/' ) {
        $this->ssh  = $ssh;
        $this->sftp = $sftp;
        $this->root = rtrim( $root, '/' );
    }

    // ── Conexión estática ─────────────────────────────────────────────────────

    /**
     * Crea una instancia conectada usando las credenciales guardadas.
     *
     * @throws \RuntimeException
     */
    public static function connect(): self {
        $creds = AWFTP_Credentials::get();

        if ( empty( $creds['host'] ) ) {
            throw new \RuntimeException( 'No hay credenciales SFTP configuradas.' );
        }

        return self::connect_with(
            $creds['host'],
            (int) ( $creds['port'] ?? 22 ),
            $creds['username'],
            $creds['password'],
            $creds['root_path'] ?? '/'
        );
    }

    /**
     * Conexión explícita con credenciales (para prueba de conexión).
     *
     * @throws \RuntimeException
     */
    public static function connect_with( string $host, int $port, string $username, string $password, string $root = '/' ): self {
        // Suprimir warnings de ssh2_connect para capturarlos como excepción
        $ssh = @ssh2_connect( $host, $port );

        if ( ! $ssh ) {
            throw new \RuntimeException( "No se pudo conectar a {$host}:{$port}. Verifica el host y el puerto." );
        }

        if ( ! @ssh2_auth_password( $ssh, $username, $password ) ) {
            throw new \RuntimeException( 'Autenticación fallida. Verifica usuario y contraseña.' );
        }

        $sftp = @ssh2_sftp( $ssh );

        if ( ! $sftp ) {
            throw new \RuntimeException( 'No se pudo iniciar el subsistema SFTP.' );
        }

        return new self( $ssh, $sftp, $root );
    }

    // ── Directorio ────────────────────────────────────────────────────────────

    /**
     * Lista el contenido de un directorio.
     *
     * @return array<int, array{name: string, type: string, size: int, modified: int, permissions: string}>
     * @throws \RuntimeException
     */
    public function list_directory( string $path ): array {
        $full      = $this->full_path( $path );
        $sftp_url  = $this->sftp_url( $full );
        $handle    = @opendir( $sftp_url );

        if ( ! $handle ) {
            throw new \RuntimeException( "No se puede listar el directorio: {$path}" );
        }

        $result = [];

        while ( false !== ( $entry = readdir( $handle ) ) ) {
            if ( $entry === '.' || $entry === '..' ) continue;

            $entry_path = $full . '/' . $entry;
            $stat       = @ssh2_sftp_stat( $this->sftp, $entry_path );

            if ( ! $stat ) continue;

            $is_dir = ( $stat['mode'] & 0170000 ) === 0040000;

            $result[] = [
                'name'        => $entry,
                'type'        => $is_dir ? 'dir' : 'file',
                'size'        => (int) ( $stat['size'] ?? 0 ),
                'modified'    => (int) ( $stat['mtime'] ?? 0 ),
                'permissions' => $this->format_permissions( (int) ( $stat['mode'] ?? 0 ) ),
            ];
        }

        closedir( $handle );

        // Carpetas primero, luego alfabético
        usort( $result, function ( $a, $b ) {
            if ( $a['type'] !== $b['type'] ) {
                return $a['type'] === 'dir' ? -1 : 1;
            }
            return strcasecmp( $a['name'], $b['name'] );
        });

        return $result;
    }

    /**
     * Crea un directorio de forma recursiva.
     *
     * @throws \RuntimeException
     */
    public function create_directory( string $path ): void {
        $full = $this->full_path( $path );

        if ( ! @ssh2_sftp_mkdir( $this->sftp, $full, 0755, true ) ) {
            throw new \RuntimeException( "No se pudo crear el directorio: {$path}" );
        }
    }

    /**
     * Devuelve el directorio raíz configurado.
     */
    public function pwd(): string {
        return $this->root ?: '/';
    }

    // ── Archivo ───────────────────────────────────────────────────────────────

    /**
     * Descarga el contenido de un archivo como string.
     *
     * @throws \RuntimeException
     */
    public function get_file( string $path ): string {
        $full    = $this->full_path( $path );
        $sftp_url = $this->sftp_url( $full );

        $content = @file_get_contents( $sftp_url );

        if ( false === $content ) {
            throw new \RuntimeException( "No se puede leer el archivo: {$path}" );
        }

        return $content;
    }

    /**
     * Escribe contenido (string) en una ruta remota.
     *
     * @throws \RuntimeException
     */
    public function put_file( string $path, string $content ): void {
        $full     = $this->full_path( $path );
        $sftp_url = $this->sftp_url( $full );

        $bytes = @file_put_contents( $sftp_url, $content );

        if ( false === $bytes ) {
            throw new \RuntimeException( "No se pudo guardar el archivo: {$path}" );
        }
    }

    /**
     * Sube un archivo local (ruta tmp de $_FILES) a una ruta remota.
     *
     * @throws \RuntimeException
     */
    public function upload_file( string $remote_path, string $local_tmp ): void {
        $full     = $this->full_path( $remote_path );
        $sftp_url = $this->sftp_url( $full );

        // Leer el archivo local y escribirlo en remoto
        $content = @file_get_contents( $local_tmp );

        if ( false === $content ) {
            throw new \RuntimeException( "No se puede leer el archivo temporal." );
        }

        $bytes = @file_put_contents( $sftp_url, $content );

        if ( false === $bytes ) {
            throw new \RuntimeException( "Error al subir el archivo a: {$remote_path}" );
        }
    }

    /**
     * Crea un archivo vacío (o con contenido inicial).
     *
     * @throws \RuntimeException
     */
    public function create_file( string $path, string $content = '' ): void {
        $this->put_file( $path, $content );
    }

    /**
     * Elimina un archivo o directorio (recursivo si es carpeta).
     *
     * @throws \RuntimeException
     */
    public function delete( string $path ): void {
        $full = $this->full_path( $path );
        $stat = @ssh2_sftp_stat( $this->sftp, $full );

        if ( ! $stat ) {
            throw new \RuntimeException( "No existe: {$path}" );
        }

        $is_dir = ( $stat['mode'] & 0170000 ) === 0040000;

        if ( $is_dir ) {
            $this->delete_directory_recursive( $full );
        } else {
            if ( ! @ssh2_sftp_unlink( $this->sftp, $full ) ) {
                throw new \RuntimeException( "No se pudo eliminar: {$path}" );
            }
        }
    }

    /**
     * Renombra o mueve un elemento.
     *
     * @throws \RuntimeException
     */
    public function rename( string $old_path, string $new_path ): void {
        $old = $this->full_path( $old_path );
        $new = $this->full_path( $new_path );

        if ( ! @ssh2_sftp_rename( $this->sftp, $old, $new ) ) {
            throw new \RuntimeException( "No se pudo renombrar: {$old_path} → {$new_path}" );
        }
    }

    // ── Helpers privados ──────────────────────────────────────────────────────

    /**
     * Elimina un directorio y todo su contenido de forma recursiva.
     *
     * @throws \RuntimeException
     */
    private function delete_directory_recursive( string $full_path ): void {
        $sftp_url = $this->sftp_url( $full_path );
        $handle   = @opendir( $sftp_url );

        if ( $handle ) {
            while ( false !== ( $entry = readdir( $handle ) ) ) {
                if ( $entry === '.' || $entry === '..' ) continue;

                $entry_full = $full_path . '/' . $entry;
                $stat       = @ssh2_sftp_stat( $this->sftp, $entry_full );

                if ( $stat && ( $stat['mode'] & 0170000 ) === 0040000 ) {
                    $this->delete_directory_recursive( $entry_full );
                } else {
                    @ssh2_sftp_unlink( $this->sftp, $entry_full );
                }
            }
            closedir( $handle );
        }

        if ( ! @ssh2_sftp_rmdir( $this->sftp, $full_path ) ) {
            throw new \RuntimeException( "No se pudo eliminar el directorio: {$full_path}" );
        }
    }

    /**
     * Construye la URL de stream ssh2.sftp:// para operaciones con file_*
     *
     * @param string $full_path Ruta absoluta en el servidor remoto
     */
    private function sftp_url( string $full_path ): string {
        return 'ssh2.sftp://' . intval( $this->sftp ) . $full_path;
    }

    /**
     * Construye la ruta absoluta y previene path traversal.
     *
     * @throws \RuntimeException si la ruta queda fuera del root.
     */
    private function full_path( string $relative ): string {
        $relative = str_replace( '\\', '/', $relative );
        $full     = $this->root . '/' . ltrim( $relative, '/' );

        $parts    = explode( '/', $full );
        $resolved = [];

        foreach ( $parts as $part ) {
            if ( $part === '' || $part === '.' ) continue;
            if ( $part === '..' ) {
                array_pop( $resolved );
            } else {
                $resolved[] = $part;
            }
        }

        $safe = '/' . implode( '/', $resolved );

        if ( $this->root !== '' && strpos( $safe, $this->root ) !== 0 ) {
            throw new \RuntimeException( 'Ruta no permitida (path traversal detectado).' );
        }

        return $safe;
    }

    /**
     * Convierte modo octal a notación Unix (ej: drwxr-xr-x).
     */
    private function format_permissions( int $mode ): string {
        $types = [
            0140000 => 's', 0120000 => 'l', 0100000 => '-',
            0060000 => 'b', 0040000 => 'd', 0020000 => 'c', 0010000 => 'p',
        ];

        $type = '-';
        foreach ( $types as $mask => $char ) {
            if ( ( $mode & 0170000 ) === $mask ) {
                $type = $char;
                break;
            }
        }

        $b = fn( int $bit ): string => ( $mode & $bit ) ? '1' : '0';

        return $type
            . ( ( $mode & 0400 ) ? 'r' : '-' ) . ( ( $mode & 0200 ) ? 'w' : '-' ) . ( ( $mode & 0100 ) ? 'x' : '-' )
            . ( ( $mode & 0040 ) ? 'r' : '-' ) . ( ( $mode & 0020 ) ? 'w' : '-' ) . ( ( $mode & 0010 ) ? 'x' : '-' )
            . ( ( $mode & 0004 ) ? 'r' : '-' ) . ( ( $mode & 0002 ) ? 'w' : '-' ) . ( ( $mode & 0001 ) ? 'x' : '-' );
    }
}
