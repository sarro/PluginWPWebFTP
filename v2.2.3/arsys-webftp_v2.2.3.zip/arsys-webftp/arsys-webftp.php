<?php
/**
 * Plugin Name:       Arsys WebFTP
 * Plugin URI:        https://www.arsys.es
 * Description:       Explorador SFTP integrado en WordPress. Acceso protegido con login de usuario WordPress. Sin dependencias externas.
 * Version:           2.2.3
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Arsys (IONOS Group)
 * License:           GPL-2.0+
 * Text Domain:       arsys-webftp
 */

defined( 'ABSPATH' ) || exit;

define( 'AWFTP_VERSION',  '2.2.3' );
define( 'AWFTP_DIR',      plugin_dir_path( __FILE__ ) );
define( 'AWFTP_URL',      plugin_dir_url( __FILE__ ) );
define( 'AWFTP_BASENAME', plugin_basename( __FILE__ ) );

// ── Comprobación de requisitos ────────────────────────────────────────────────
function awftp_check_requirements(): bool {
    return extension_loaded( 'ssh2' );
}

// ── Activación ────────────────────────────────────────────────────────────────
register_activation_hook( __FILE__, 'awftp_activate' );
function awftp_activate(): void {
    if ( ! awftp_check_requirements() ) {
        deactivate_plugins( plugin_basename( __FILE__ ) );
        wp_die(
            '<p><strong>Arsys WebFTP</strong> requiere la extensión PHP <code>ssh2</code>.</p>' .
            '<p>Actívala desde el panel de control de tu hosting (sección PHP o extensiones).</p>' .
            '<p><a href="' . esc_url( admin_url( 'plugins.php' ) ) . '">&laquo; Volver a plugins</a></p>',
            'Requisito no cumplido',
            [ 'back_link' => false ]
        );
    }
    awftp_create_session_table();
}

function awftp_create_session_table(): void {
    global $wpdb;
    $table   = $wpdb->prefix . 'awftp_sessions';
    $charset = $wpdb->get_charset_collate();
    $sql     = "CREATE TABLE IF NOT EXISTS {$table} (
        id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id       BIGINT UNSIGNED NOT NULL,
        session_token VARCHAR(64)     NOT NULL,
        created_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        expires_at    DATETIME        NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY session_token (session_token),
        KEY user_id (user_id)
    ) {$charset};";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql );
}

// ── Desactivación ─────────────────────────────────────────────────────────────
register_deactivation_hook( __FILE__, 'awftp_deactivate' );
function awftp_deactivate(): void {
    global $wpdb;
    $wpdb->query( "DELETE FROM {$wpdb->prefix}awftp_sessions WHERE 1=1" );
}

// ── Arranque ──────────────────────────────────────────────────────────────────
add_action( 'plugins_loaded', function () {

    if ( ! awftp_check_requirements() ) {
        add_action( 'admin_notices', function () {
            echo '<div class="notice notice-error"><p>';
            echo '<strong>Arsys WebFTP:</strong> La extensión PHP <code>ssh2</code> no está disponible. ';
            echo 'Actívala desde tu panel de hosting.';
            echo '</p></div>';
        });
        return;
    }

    require_once AWFTP_DIR . 'includes/class-credentials.php';
    require_once AWFTP_DIR . 'includes/class-session.php';
    require_once AWFTP_DIR . 'includes/class-sftp-manager.php';
    require_once AWFTP_DIR . 'includes/class-admin-page.php';
    require_once AWFTP_DIR . 'includes/class-ajax-handler.php';
    require_once AWFTP_DIR . 'includes/class-updater.php';

    AWFTP_Admin_Page::init();
    AWFTP_Ajax_Handler::init();
    AWFTP_Updater::init();

} );
