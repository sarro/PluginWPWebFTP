<?php
defined( 'ABSPATH' ) || exit;

/**
 * Gestiona las credenciales SFTP guardadas en wp_options.
 *
 * Seguridad (OWASP A02 - Cryptographic Failures):
 *  - Cifrado AES-256-CBC con openssl_encrypt
 *  - Clave derivada de AUTH_KEY + AUTH_SALT de wp-config.php via PBKDF2
 *  - IV aleatorio por cada operacion de cifrado
 *  - HMAC-SHA256 para verificar integridad antes de descifrar
 *  - Migración automática desde base64 (versiones anteriores)
 */
class AWFTP_Credentials {

    const OPTION_KEY  = 'awftp_sftp_credentials';
    const CIPHER      = 'AES-256-CBC';
    const HMAC_ALGO   = 'sha256';
    const KEY_LENGTH  = 32; // 256 bits
    const FORMAT_V2   = 'awftp_v2:'; // Prefijo para identificar cifrado real vs base64 legacy

    // ── Guardar ───────────────────────────────────────────────────────────────

    public static function save( array $data ): void {
        $sanitized = [
            'host'      => sanitize_text_field( $data['host']      ?? '' ),
            'port'      => absint( $data['port'] ?? 22 ),
            'username'  => sanitize_text_field( $data['username']  ?? '' ),
            'password'  => $data['password'] ?? '',
            'root_path' => trailingslashit( sanitize_text_field( $data['root_path'] ?? '/' ) ),
        ];

        $encrypted = self::encrypt( wp_json_encode( $sanitized ) );
        update_option( self::OPTION_KEY, $encrypted, false );
    }

    // ── Recuperar ─────────────────────────────────────────────────────────────

    public static function get(): array {
        $raw = get_option( self::OPTION_KEY, '' );
        if ( empty( $raw ) ) return [];

        // Migración automática: si es base64 legacy, descifrar y re-guardar con cifrado real
        if ( ! str_starts_with( $raw, self::FORMAT_V2 ) ) {
            return self::migrate_legacy( $raw );
        }

        $json = self::decrypt( $raw );
        if ( false === $json ) return [];

        $data = json_decode( $json, true );
        return is_array( $data ) ? $data : [];
    }

    public static function has_credentials(): bool {
        $c = self::get();
        return ! empty( $c['host'] ) && ! empty( $c['username'] );
    }

    public static function delete(): void {
        delete_option( self::OPTION_KEY );
    }

    // ── Cifrado ───────────────────────────────────────────────────────────────

    /**
     * Cifra un string con AES-256-CBC + HMAC-SHA256.
     *
     * Formato del resultado:
     *   awftp_v2:<base64(iv)>:<base64(ciphertext)>:<base64(hmac)>
     */
    private static function encrypt( string $plaintext ): string {
        $key        = self::derive_key();
        $iv_length  = openssl_cipher_iv_length( self::CIPHER );
        $iv         = openssl_random_pseudo_bytes( $iv_length );
        $ciphertext = openssl_encrypt( $plaintext, self::CIPHER, $key, OPENSSL_RAW_DATA, $iv );

        if ( false === $ciphertext ) {
            // Fallback a base64 si openssl falla (no debería ocurrir)
            return base64_encode( $plaintext );
        }

        // HMAC sobre IV + ciphertext para verificar integridad
        $hmac = hash_hmac( self::HMAC_ALGO, $iv . $ciphertext, $key, true );

        return self::FORMAT_V2
            . base64_encode( $iv ) . ':'
            . base64_encode( $ciphertext ) . ':'
            . base64_encode( $hmac );
    }

    /**
     * Descifra un string cifrado con encrypt().
     * Verifica HMAC antes de descifrar para prevenir ataques de padding oracle.
     *
     * @return string|false Plaintext o false si falla la verificación
     */
    private static function decrypt( string $encrypted ) {
        // Quitar prefijo
        $data = substr( $encrypted, strlen( self::FORMAT_V2 ) );
        $parts = explode( ':', $data );

        if ( count( $parts ) !== 3 ) return false;

        $iv         = base64_decode( $parts[0], true );
        $ciphertext = base64_decode( $parts[1], true );
        $hmac       = base64_decode( $parts[2], true );

        if ( false === $iv || false === $ciphertext || false === $hmac ) return false;

        $key = self::derive_key();

        // Verificar HMAC primero (timing-safe)
        $expected_hmac = hash_hmac( self::HMAC_ALGO, $iv . $ciphertext, $key, true );
        if ( ! hash_equals( $expected_hmac, $hmac ) ) {
            return false; // Integridad comprometida
        }

        $plaintext = openssl_decrypt( $ciphertext, self::CIPHER, $key, OPENSSL_RAW_DATA, $iv );
        return $plaintext;
    }

    /**
     * Deriva una clave de 256 bits a partir de las AUTH_KEY y AUTH_SALT de wp-config.php.
     * Usa PBKDF2 con SHA-256 y 10.000 iteraciones.
     */
    private static function derive_key(): string {
        $secret = ( defined('AUTH_KEY')  ? AUTH_KEY  : 'awftp_fallback_key_1' )
                . ( defined('AUTH_SALT') ? AUTH_SALT : 'awftp_fallback_salt_1' );

        // Salt fijo derivado del sitio (no secreto, solo para diversificación)
        $salt = 'awftp_credential_key_v2_' . parse_url( get_site_url(), PHP_URL_HOST );

        return hash_pbkdf2( 'sha256', $secret, $salt, 10000, self::KEY_LENGTH, true );
    }

    // ── Migración desde base64 ────────────────────────────────────────────────

    /**
     * Migra credenciales almacenadas en base64 (v2.4.3 y anteriores)
     * al nuevo formato cifrado, re-guardándolas automáticamente.
     */
    private static function migrate_legacy( string $raw ): array {
        $json = base64_decode( $raw, true );
        if ( false === $json ) return [];

        $data = json_decode( $json, true );
        if ( ! is_array( $data ) ) return [];

        // Re-guardar con cifrado real de forma transparente
        self::save( $data );

        return $data;
    }
}
