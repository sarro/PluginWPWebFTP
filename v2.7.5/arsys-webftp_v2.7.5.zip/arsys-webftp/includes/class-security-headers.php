<?php
defined( 'ABSPATH' ) || exit;

/**
 * Headers de seguridad HTTP para Arsys WebFTP.
 *
 * Seguridad (OWASP A05 - Security Misconfiguration):
 *
 *  - X-Content-Type-Options: evita que el navegador interprete
 *    archivos con un tipo MIME diferente al declarado (MIME sniffing)
 *
 *  - X-Frame-Options: evita que la página del plugin se cargue
 *    en un iframe (clickjacking)
 *
 *  - X-XSS-Protection: activa el filtro XSS del navegador (legacy,
 *    pero útil para navegadores antiguos)
 *
 *  - Referrer-Policy: evita que la URL del panel de administración
 *    se filtre a recursos externos
 *
 *  - Content-Security-Policy: restringe los orígenes de scripts,
 *    estilos e iframes permitidos en la página del plugin
 *
 *  - Permissions-Policy: desactiva APIs del navegador que el plugin
 *    no necesita (cámara, micrófono, geolocalización...)
 */
class AWFTP_Security_Headers {

    public static function init(): void {
        // Headers en la página del explorador (admin)
        add_action( 'admin_init', [ self::class, 'send_page_headers' ] );

        // Headers en todas las respuestas AJAX del plugin
        add_filter( 'wp_doing_ajax', [ self::class, 'maybe_send_ajax_headers' ] );
    }

    /**
     * Envía headers de seguridad en las páginas del plugin dentro de wp-admin.
     */
    public static function send_page_headers(): void {
        // Solo en las páginas del plugin
        $page = sanitize_text_field( $_GET['page'] ?? '' );
        if ( strpos( $page, 'arsys-webftp' ) === false ) return;

        if ( headers_sent() ) return;

        self::output_headers();
    }

    /**
     * Envía headers de seguridad en peticiones AJAX del plugin.
     */
    public static function maybe_send_ajax_headers( bool $doing_ajax ): bool {
        if ( ! $doing_ajax ) return $doing_ajax;

        $action = sanitize_text_field( $_REQUEST['action'] ?? '' );
        if ( strpos( $action, 'awftp_' ) !== 0 ) return $doing_ajax;

        if ( headers_sent() ) return $doing_ajax;

        self::output_headers();

        return $doing_ajax;
    }

    /**
     * Escribe los headers HTTP de seguridad.
     */
    private static function output_headers(): void {
        // Evita MIME type sniffing
        header( 'X-Content-Type-Options: nosniff' );

        // Evita clickjacking — la página no puede cargarse en iframes
        header( 'X-Frame-Options: SAMEORIGIN' );

        // Filtro XSS legacy (útil para IE/Edge antiguos)
        header( 'X-XSS-Protection: 1; mode=block' );

        // No enviar el Referer a recursos externos
        header( 'Referrer-Policy: strict-origin-when-cross-origin' );

        // Desactivar APIs del navegador que el plugin no usa
        header( 'Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()' );

        // Content Security Policy restrictiva para las páginas del plugin
        // - default-src 'self': solo recursos del mismo origen
        // - script-src: permite scripts del mismo origen + inline necesarios para WP admin
        // - style-src: permite estilos del mismo origen + inline (WP admin los usa)
        // - img-src: permite imágenes del mismo origen + data: (para previsualizaciones)
        // - connect-src: solo AJAX al mismo origen
        // - frame-ancestors: solo permite embeber desde el mismo origen
        $csp = implode( '; ', [
            "default-src 'self'",
            "script-src 'self' 'unsafe-inline'",  // unsafe-inline necesario para WP admin
            "style-src 'self' 'unsafe-inline'",   // unsafe-inline necesario para WP admin
            "img-src 'self' data: blob:",          // blob: para vista previa de imágenes
            "connect-src 'self'",
            "font-src 'self'",
            "object-src 'none'",
            "base-uri 'self'",
            "frame-ancestors 'self'",
        ]);

        header( 'Content-Security-Policy: ' . $csp );
    }
}
