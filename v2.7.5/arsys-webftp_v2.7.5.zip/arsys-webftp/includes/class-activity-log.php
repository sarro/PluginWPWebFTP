<?php
defined( 'ABSPATH' ) || exit;

/**
 * Registro de actividad WebFTP.
 *
 * Guarda en BD todas las operaciones realizadas:
 * quién, qué acción, sobre qué ruta, cuándo y desde qué IP.
 * Accesible desde WebFTP → Configuración → Log de actividad.
 */
class AWFTP_Activity_Log {

    const TABLE_SUFFIX = 'awftp_activity_log';
    const MAX_ENTRIES  = 1000; // Máximo de entradas a conservar

    // Tipos de acción
    const ACTION_LOGIN       = 'login';
    const ACTION_LOGOUT      = 'logout';
    const ACTION_LIST        = 'list';
    const ACTION_DOWNLOAD    = 'download';
    const ACTION_UPLOAD      = 'upload';
    const ACTION_EDIT        = 'edit';
    const ACTION_DELETE      = 'delete';
    const ACTION_RENAME      = 'rename';
    const ACTION_CREATE_FILE = 'create_file';
    const ACTION_CREATE_DIR  = 'create_dir';
    const ACTION_SEARCH      = 'search';

    // ── Tabla ─────────────────────────────────────────────────────────────────

    public static function create_table(): void {
        global $wpdb;
        $table   = $wpdb->prefix . self::TABLE_SUFFIX;
        $charset = $wpdb->get_charset_collate();
        $sql     = "CREATE TABLE IF NOT EXISTS {$table} (
            id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id    BIGINT UNSIGNED NOT NULL DEFAULT 0,
            username   VARCHAR(100)    NOT NULL DEFAULT '',
            action     VARCHAR(30)     NOT NULL DEFAULT '',
            path       TEXT,
            extra      VARCHAR(255)    DEFAULT NULL,
            ip         VARCHAR(45)     NOT NULL DEFAULT '',
            created_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id   (user_id),
            KEY action    (action),
            KEY created_at (created_at)
        ) {$charset};";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    public static function drop_table(): void {
        global $wpdb;
        $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}" . self::TABLE_SUFFIX );
    }

    // ── Registrar ─────────────────────────────────────────────────────────────

    /**
     * Registra una acción en el log.
     *
     * @param string      $action  Tipo de acción (usar constantes de clase)
     * @param string      $path    Ruta afectada
     * @param string|null $extra   Info adicional (ej: nuevo nombre en rename)
     */
    public static function log( string $action, string $path = '', ?string $extra = null ): void {
        global $wpdb;

        $user    = AWFTP_Session::get_current_user();
        $user_id = $user ? $user->ID         : 0;
        $username= $user ? $user->user_login : 'system';

        $wpdb->insert(
            $wpdb->prefix . self::TABLE_SUFFIX,
            [
                'user_id'  => $user_id,
                'username' => $username,
                'action'   => sanitize_text_field( $action ),
                'path'     => $path,
                'extra'    => $extra ? substr( $extra, 0, 255 ) : null,
                'ip'       => self::get_ip(),
            ],
            [ '%d', '%s', '%s', '%s', '%s', '%s' ]
        );

        // Limpiar entradas antiguas si superamos el máximo
        self::maybe_prune();
    }

    // ── Consultar ─────────────────────────────────────────────────────────────

    /**
     * Obtiene entradas del log con filtros opcionales.
     *
     * @param array $args {
     *   int    $limit    Número de entradas (default 50)
     *   int    $offset   Offset para paginación
     *   string $action   Filtrar por tipo de acción
     *   string $username Filtrar por usuario
     *   string $date_from Fecha inicio (Y-m-d)
     *   string $date_to   Fecha fin (Y-m-d)
     * }
     * @return array
     */
    public static function get_entries( array $args = [] ): array {
        global $wpdb;

        $limit    = (int) ( $args['limit']    ?? 50 );
        $offset   = (int) ( $args['offset']   ?? 0 );
        $action   = sanitize_text_field( $args['action']   ?? '' );
        $username = sanitize_text_field( $args['username'] ?? '' );
        $date_from= sanitize_text_field( $args['date_from'] ?? '' );
        $date_to  = sanitize_text_field( $args['date_to']   ?? '' );

        $table  = $wpdb->prefix . self::TABLE_SUFFIX;
        $where  = [ '1=1' ];
        $params = [];

        if ( $action ) {
            $where[]  = 'action = %s';
            $params[] = $action;
        }
        if ( $username ) {
            $where[]  = 'username LIKE %s';
            $params[] = '%' . $wpdb->esc_like( $username ) . '%';
        }
        if ( $date_from ) {
            $where[]  = 'created_at >= %s';
            $params[] = $date_from . ' 00:00:00';
        }
        if ( $date_to ) {
            $where[]  = 'created_at <= %s';
            $params[] = $date_to . ' 23:59:59';
        }

        $where_sql = implode( ' AND ', $where );
        $params[]  = $limit;
        $params[]  = $offset;

        $sql = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY created_at DESC LIMIT %d OFFSET %d";

        if ( ! empty( array_filter( $params ) ) ) {
            return $wpdb->get_results( $wpdb->prepare( $sql, ...$params ), ARRAY_A ) ?: [];
        }

        return $wpdb->get_results( $sql, ARRAY_A ) ?: [];
    }

    /**
     * Total de entradas (para paginación).
     */
    public static function count_entries( array $args = [] ): int {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_SUFFIX;
        return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
    }

    /**
     * Vacía el log completo.
     */
    public static function clear(): void {
        global $wpdb;
        $wpdb->query( "TRUNCATE TABLE {$wpdb->prefix}" . self::TABLE_SUFFIX );
    }

    // ── Labels para la UI ─────────────────────────────────────────────────────

    public static function action_label( string $action ): string {
        $labels = [
            self::ACTION_LOGIN       => __( '🔑 Login', 'arsys-webftp' ),
            self::ACTION_LOGOUT      => __( '🚪 Logout', 'arsys-webftp' ),
            self::ACTION_LIST        => __( '📂 Listado', 'arsys-webftp' ),
            self::ACTION_DOWNLOAD    => __( '⬇ Descarga', 'arsys-webftp' ),
            self::ACTION_UPLOAD      => __( '⬆ Subida', 'arsys-webftp' ),
            self::ACTION_EDIT        => __( '✏️ Edicion', 'arsys-webftp' ),
            self::ACTION_DELETE      => __( '🗑 Eliminacion', 'arsys-webftp' ),
            self::ACTION_RENAME      => __( '✏️ Renombrado', 'arsys-webftp' ),
            self::ACTION_CREATE_FILE => __( '📄 Crear archivo', 'arsys-webftp' ),
            self::ACTION_CREATE_DIR  => __( '📁 Crear carpeta', 'arsys-webftp' ),
            self::ACTION_SEARCH      => __( '🔍 Busqueda', 'arsys-webftp' ),
        ];
        return $labels[ $action ] ?? $action;
    }

    // ── Helpers privados ──────────────────────────────────────────────────────

    private static function get_ip(): string {
        $keys = [ 'HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' ];
        foreach ( $keys as $key ) {
            if ( ! empty( $_SERVER[ $key ] ) ) {
                $ip = trim( explode( ',', $_SERVER[ $key ] )[0] );
                if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) return $ip;
            }
        }
        return '0.0.0.0';
    }

    private static function maybe_prune(): void {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_SUFFIX;
        $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
        if ( $count > self::MAX_ENTRIES ) {
            $wpdb->query( $wpdb->prepare(
                "DELETE FROM {$table} ORDER BY created_at ASC LIMIT %d",
                $count - self::MAX_ENTRIES
            ));
        }
    }
}
