<?php
defined( 'ABSPATH' ) || exit;

class AWFTP_Admin_Page {

    public static function init(): void {
        $self = new self();
        add_action( 'admin_menu',            [ $self, 'register_menu' ] );
        add_action( 'admin_enqueue_scripts', [ $self, 'enqueue_assets' ] );
        add_action( 'admin_post_awftp_save_credentials', [ $self, 'handle_save_credentials' ] );
        add_action( 'wp_scheduled_delete',   [ self::class, 'cleanup_sessions' ] );
    }

    public function register_menu(): void {
        add_menu_page( __( 'Arsys WebFTP', 'arsys-webftp' ), __( 'WebFTP', 'arsys-webftp' ), 'read', 'arsys-webftp',
            [ $this, 'render_page' ], 'dashicons-portfolio', 80 );
        add_submenu_page( 'arsys-webftp', __( 'Explorador', 'arsys-webftp' ), __( 'Explorador', 'arsys-webftp' ),
            'read', 'arsys-webftp', [ $this, 'render_page' ] );
        add_submenu_page( 'arsys-webftp', __( 'Configuracion SFTP', 'arsys-webftp' ), __( 'Configuracion', 'arsys-webftp' ),
            'manage_options', 'arsys-webftp-settings', [ $this, 'render_settings' ] );
    }

    public function enqueue_assets( string $hook ): void {
        if ( strpos( $hook, 'arsys-webftp' ) === false ) return;
        wp_enqueue_style(  'awftp-style',      AWFTP_URL . 'assets/css/webftp.css', [], AWFTP_VERSION );
        wp_enqueue_style(  'codemirror-style', 'https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/codemirror.min.css', [], '5.65.16' );
        wp_enqueue_style(  'codemirror-theme', 'https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/theme/dracula.min.css', [], '5.65.16' );
        wp_enqueue_script( 'codemirror-core',  'https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/codemirror.min.js', [], '5.65.16', true );
        wp_enqueue_script( 'codemirror-auto',  'https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/addon/mode/loadmode.min.js', [ 'codemirror-core' ], '5.65.16', true );
        wp_enqueue_script( 'codemirror-info',  'https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/addon/mode/multiplex.min.js', [ 'codemirror-core' ], '5.65.16', true );
        wp_enqueue_script( 'awftp-app',        AWFTP_URL . 'assets/js/webftp.js', [ 'jquery', 'codemirror-core' ], AWFTP_VERSION, true );
        wp_localize_script( 'awftp-app', 'AWFTP', [
            'ajax_url'    => admin_url( 'admin-ajax.php' ),
            'nonce'       => wp_create_nonce( 'awftp_nonce' ),
            'login_nonce' => wp_create_nonce( 'awftp_login_nonce' ),
            'logged_in'   => AWFTP_Session::is_logged_in() ? '1' : '0',
            'root'        => AWFTP_Credentials::get()['root_path'] ?? '/',
        ]);
    }

    public function render_page(): void {
        if ( ! AWFTP_Session::is_logged_in() ) { $this->render_login(); return; }
        if ( ! AWFTP_Credentials::has_credentials() ) {
            echo '<div class="wrap"><div class="notice notice-warning"><p>';
            echo current_user_can( 'manage_options' )
                ? 'WebFTP no esta configurado. <a href="' . esc_url( admin_url( 'admin.php?page=arsys-webftp-settings' ) ) . '">Ir a Configuracion</a>'
                : __( 'WebFTP no esta configurado. Contacta con el administrador.', 'arsys-webftp' );
            echo '</p></div></div>';
            return;
        }
        $this->render_explorer();
    }

    // ── Login ─────────────────────────────────────────────────────────────────

    private function render_login(): void {
        $u = wp_get_current_user();
        ?>
        <div class="awftp-login-wrap">
            <div class="awftp-login-card" id="awftp-login-card">
                <div class="awftp-login-logo">
                    <span class="awftp-login-icon">&#9889;</span>
                    <h1>Arsys <strong>WebFTP</strong></h1>
                    <p class="awftp-login-sub">Explorador SFTP seguro</p>
                </div>
                <div id="awftp-login-error" class="awftp-login-error" style="display:none"></div>
                <div class="awftp-login-form">
                    <div class="awftp-field">
                        <label for="awftp-login-user">Usuario de WordPress</label>
                        <div class="awftp-input-wrap">
                            <span class="awftp-input-icon">&#128100;</span>
                            <input type="text" id="awftp-login-user" value="<?php echo esc_attr( $u->user_login ?? '' ); ?>" placeholder="usuario" autocomplete="username" />
                        </div>
                    </div>
                    <div class="awftp-field">
                        <label for="awftp-login-pass">Contrasena</label>
                        <div class="awftp-input-wrap">
                            <span class="awftp-input-icon">&#128273;</span>
                            <input type="password" id="awftp-login-pass" placeholder="&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;" autocomplete="current-password" />
                        </div>
                    </div>
                    <button id="awftp-login-btn" class="awftp-login-submit">
                        <span class="awftp-login-btn-text">Acceder al explorador</span>
                        <span class="awftp-login-spinner" style="display:none"><span class="awftp-spinner"></span></span>
                    </button>
                </div>
                <p class="awftp-login-note">&#128274; Usa tu usuario y contrasena de WordPress.<br><small>Solo administradores pueden acceder.</small></p>
            </div>
        </div>
        <?php
    }

    // ── Explorador ────────────────────────────────────────────────────────────

    private function render_explorer(): void {
        $wftp_user = AWFTP_Session::get_current_user();
        ?>
        <div class="wrap awftp-wrap">
            <h1 class="awftp-title">
                <span class="awftp-logo">&#9889;</span> Arsys WebFTP
                <span class="awftp-badge">SFTP</span>
                <span class="awftp-user-info">
                    &#128100; <?php echo esc_html( $wftp_user ? $wftp_user->display_name : '' ); ?>
                    <button id="awftp-logout-btn" class="button button-small">&#128682; Cerrar sesion</button>
                </span>
            </h1>

            <div id="awftp-app">
                <!-- Toolbar -->
                <div class="awftp-toolbar">
                    <div class="awftp-path-bar">
                        <span class="awftp-path-label">&#128193;</span>
                        <div id="awftp-breadcrumb" class="awftp-breadcrumb"></div>
                        <input type="hidden" id="awftp-current-path" value="/" />
                        <button id="awftp-btn-up">&#8593; Subir</button>
                        <button id="awftp-btn-refresh">&#8635; Recargar</button>
                    </div>
                    <div class="awftp-actions">
                        <button id="awftp-btn-new-folder" class="button button-secondary">&#128193; Nueva carpeta</button>
                        <button id="awftp-btn-new-file"   class="button button-secondary">&#128196; Nuevo archivo</button>
                        <label class="button button-primary" id="awftp-upload-label">
                            &#11014; Subir archivo
                            <input type="file" id="awftp-upload-input" multiple style="display:none" />
                        </label>
                    </div>
                </div>

                <!-- Barra de busqueda -->
                <div class="awftp-search-bar">
                    <span style="font-size:15px">&#128269;</span>
                    <input type="text" id="awftp-search-input" placeholder="Buscar archivos en el directorio actual y subdirectorios..." />
                    <button id="awftp-search-btn" class="button button-secondary">Buscar</button>
                    <button id="awftp-search-clear" class="button button-secondary">&#10005; Limpiar</button>
                </div>

                <!-- Resultados de busqueda -->
                <div id="awftp-search-results" style="display:none">
                    <div class="awftp-search-header">
                        <span>Resultados de busqueda</span>
                        <span id="awftp-search-count"></span>
                    </div>
                    <table class="awftp-search-table">
                        <tbody id="awftp-search-list"></tbody>
                    </table>
                </div>

                <!-- Progreso de subida -->
                <div id="awftp-upload-progress" style="display:none">
                    <div class="awftp-progress-bar"><div class="awftp-progress-fill" id="awftp-progress-fill"></div></div>
                    <span id="awftp-progress-text">Subiendo...</span>
                </div>

                <!-- Tabla de archivos -->
                <div class="awftp-explorer">
                    <!-- Barra acciones en lote -->
                    <div id="awftp-bulk-bar" class="awftp-bulk-bar" style="display:none">
                        <span id="awftp-bulk-count" class="awftp-bulk-count"></span>
                        <button id="awftp-bulk-delete" class="button awftp-btn-danger">&#128465; Eliminar seleccionados</button>
                        <button id="awftp-bulk-deselect" class="button button-secondary">&#10005; Deseleccionar</button>
                    </div>

                    <table class="awftp-table wp-list-table widefat fixed striped">
                        <thead><tr>
                            <th class="col-check"><input type="checkbox" id="awftp-check-all" title="Seleccionar todo" /></th>
                            <th class="col-icon"></th>
                            <th class="col-name">Nombre</th>
                            <th class="col-size">Tamano</th>
                            <th class="col-date">Modificado</th>
                            <th class="col-perms">Permisos</th>
                            <th class="col-actions">Acciones</th>
                        </tr></thead>
                        <tbody id="awftp-file-list">
                            <tr><td colspan="7" class="awftp-loading"><span class="awftp-spinner"></span> Cargando...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <?php $this->render_modals(); ?>
            <div id="awftp-overlay" class="awftp-overlay" style="display:none"></div>
            <div id="awftp-notifications"></div>
        </div>
        <?php
    }

    // ── Modales ───────────────────────────────────────────────────────────────

    private function render_modals(): void { ?>
        <!-- Editor -->
        <div id="awftp-modal-editor" class="awftp-modal" style="display:none">
            <div class="awftp-modal-content awftp-modal-large">
                <div class="awftp-modal-header">
                    <h2>Editar: <span id="awftp-editor-filename"></span></h2>
                    <button class="awftp-modal-close" data-modal="awftp-modal-editor">&#10005;</button>
                </div>
                <div class="awftp-modal-body">
                    <textarea id="awftp-editor-content" spellcheck="false"></textarea>
                    <p class="awftp-editor-hint">&#9432; <kbd>Ctrl+S</kbd> para guardar rapidamente</p>
                </div>
                <div class="awftp-modal-footer">
                    <button id="awftp-btn-save-file" class="button button-primary">Guardar</button>
                    <button class="button" id="awftp-btn-close-editor">Cancelar</button>
                </div>
            </div>
        </div>
        <!-- Vista previa -->
        <div id="awftp-modal-preview" class="awftp-modal" style="display:none">
            <div class="awftp-modal-content awftp-modal-preview-size">
                <div class="awftp-modal-header">
                    <h2>&#128247; Vista previa: <span id="awftp-preview-filename"></span></h2>
                    <button class="awftp-modal-close" data-modal="awftp-modal-preview">&#10005;</button>
                </div>
                <div class="awftp-modal-body">
                    <div class="awftp-preview-container">
                        <img id="awftp-preview-img" src="" alt="Vista previa" />
                    </div>
                    <p id="awftp-preview-info"></p>
                </div>
                <div class="awftp-modal-footer">
                    <button class="button awftp-modal-close" data-modal="awftp-modal-preview">Cerrar</button>
                </div>
            </div>
        </div>
        <!-- Renombrar -->
        <div id="awftp-modal-rename" class="awftp-modal" style="display:none">
            <div class="awftp-modal-content">
                <div class="awftp-modal-header">
                    <h2>Renombrar</h2>
                    <button class="awftp-modal-close" data-modal="awftp-modal-rename">&#10005;</button>
                </div>
                <div class="awftp-modal-body">
                    <label>Nuevo nombre:</label>
                    <input type="text" id="awftp-rename-input" class="regular-text" />
                    <input type="hidden" id="awftp-rename-old" />
                </div>
                <div class="awftp-modal-footer">
                    <button id="awftp-btn-confirm-rename" class="button button-primary">Renombrar</button>
                    <button class="button awftp-modal-close" data-modal="awftp-modal-rename">Cancelar</button>
                </div>
            </div>
        </div>
        <!-- Crear -->
        <div id="awftp-modal-new" class="awftp-modal" style="display:none">
            <div class="awftp-modal-content">
                <div class="awftp-modal-header">
                    <h2 id="awftp-modal-new-title">Crear nuevo</h2>
                    <button class="awftp-modal-close" data-modal="awftp-modal-new">&#10005;</button>
                </div>
                <div class="awftp-modal-body">
                    <label id="awftp-modal-new-label">Nombre:</label>
                    <input type="text" id="awftp-new-name-input" class="regular-text" />
                    <input type="hidden" id="awftp-new-type" value="folder" />
                </div>
                <div class="awftp-modal-footer">
                    <button id="awftp-btn-confirm-new" class="button button-primary">Crear</button>
                    <button class="button awftp-modal-close" data-modal="awftp-modal-new">Cancelar</button>
                </div>
            </div>
        </div>
        <!-- Chmod -->
        <div id="awftp-modal-chmod" class="awftp-modal" style="display:none">
            <div class="awftp-modal-content">
                <div class="awftp-modal-header">
                    <h2>&#128274; Cambiar permisos</h2>
                    <button class="awftp-modal-close" data-modal="awftp-modal-chmod">&#10005;</button>
                </div>
                <div class="awftp-modal-body">
                    <p>Archivo: <strong id="awftp-chmod-name"></strong></p>
                    <label>Permisos (formato octal):</label>
                    <div style="display:flex;align-items:center;gap:10px;margin-top:6px">
                        <input type="text" id="awftp-chmod-input" class="regular-text"
                            placeholder="755" maxlength="4"
                            style="width:80px;font-family:monospace;font-size:16px;text-align:center" />
                        <span id="awftp-chmod-preview" style="font-size:13px;color:#6b7280;font-family:monospace"></span>
                    </div>
                    <p class="description" style="margin-top:8px">
                        Ejemplos: <code>755</code> (rwxr-xr-x) &nbsp; <code>644</code> (rw-r--r--) &nbsp; <code>777</code> (rwxrwxrwx)
                    </p>
                    <input type="hidden" id="awftp-chmod-path" />
                </div>
                <div class="awftp-modal-footer">
                    <button id="awftp-btn-confirm-chmod" class="button button-primary">Aplicar permisos</button>
                    <button class="button awftp-modal-close" data-modal="awftp-modal-chmod">Cancelar</button>
                </div>
            </div>
        </div>

        <!-- Copiar -->
        <div id="awftp-modal-copy" class="awftp-modal" style="display:none">
            <div class="awftp-modal-content">
                <div class="awftp-modal-header">
                    <h2>&#128203; Copiar archivo</h2>
                    <button class="awftp-modal-close" data-modal="awftp-modal-copy">&#10005;</button>
                </div>
                <div class="awftp-modal-body">
                    <p>Origen: <strong id="awftp-copy-src-name"></strong></p>
                    <label>Ruta de destino (ruta completa incluyendo nombre):</label>
                    <input type="text" id="awftp-copy-dest" class="regular-text"
                        style="font-family:monospace;margin-top:6px" placeholder="/ruta/destino/nuevo-nombre.ext" />
                    <p class="description">Incluye el nombre del archivo en la ruta destino.</p>
                    <input type="hidden" id="awftp-copy-src-path" />
                </div>
                <div class="awftp-modal-footer">
                    <button id="awftp-btn-confirm-copy" class="button button-primary">Copiar</button>
                    <button class="button awftp-modal-close" data-modal="awftp-modal-copy">Cancelar</button>
                </div>
            </div>
        </div>

        <!-- Borrado en lote -->
        <div id="awftp-modal-bulk-delete" class="awftp-modal" style="display:none">
            <div class="awftp-modal-content">
                <div class="awftp-modal-header">
                    <h2>&#128465; Eliminar seleccionados</h2>
                    <button class="awftp-modal-close" data-modal="awftp-modal-bulk-delete">&#10005;</button>
                </div>
                <div class="awftp-modal-body">
                    <p>Vas a eliminar <strong id="awftp-bulk-delete-count"></strong> elemento(s).</p>
                    <p class="awftp-warning">&#9888;&#65039; Esta accion no se puede deshacer.</p>
                </div>
                <div class="awftp-modal-footer">
                    <button id="awftp-btn-confirm-bulk-delete" class="button button-primary awftp-btn-danger">Eliminar todo</button>
                    <button class="button awftp-modal-close" data-modal="awftp-modal-bulk-delete">Cancelar</button>
                </div>
            </div>
        </div>

        <!-- Borrar -->
        <div id="awftp-modal-delete" class="awftp-modal" style="display:none">
            <div class="awftp-modal-content">
                <div class="awftp-modal-header">
                    <h2>Confirmar eliminacion</h2>
                    <button class="awftp-modal-close" data-modal="awftp-modal-delete">&#10005;</button>
                </div>
                <div class="awftp-modal-body">
                    <p>Eliminar <strong id="awftp-delete-name"></strong>?</p>
                    <p class="awftp-warning">Esta accion no se puede deshacer.</p>
                    <input type="hidden" id="awftp-delete-path" />
                </div>
                <div class="awftp-modal-footer">
                    <button id="awftp-btn-confirm-delete" class="button button-primary awftp-btn-danger">Eliminar</button>
                    <button class="button awftp-modal-close" data-modal="awftp-modal-delete">Cancelar</button>
                </div>
            </div>
        </div>
    <?php }

    // ── Configuracion ─────────────────────────────────────────────────────────

    public function render_settings(): void {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Acceso no autorizado.' );
        $tab   = sanitize_text_field( $_GET['tab'] ?? 'sftp' );
        $creds = AWFTP_Credentials::get();
        ?>
        <div class="wrap">
            <h1>&#9881; Configuracion — Arsys WebFTP <span style="font-size:13px;font-weight:400;color:#6b7280">v<?php echo AWFTP_VERSION; ?></span></h1>

            <!-- Pestanas -->
            <nav class="nav-tab-wrapper" style="margin-bottom:20px">
                <a href="?page=arsys-webftp-settings&tab=sftp"  class="nav-tab <?php echo $tab==='sftp'  ?'nav-tab-active':''; ?>">&#128274; Conexion SFTP</a>
                <a href="?page=arsys-webftp-settings&tab=log"   class="nav-tab <?php echo $tab==='log'   ?'nav-tab-active':''; ?>">&#128196; Log de actividad</a>
                <a href="?page=arsys-webftp-settings&tab=users"    class="nav-tab <?php echo $tab==='users'    ?'nav-tab-active':''; ?>">&#128100; Usuarios</a>
                <a href="?page=arsys-webftp-settings&tab=security" class="nav-tab <?php echo $tab==='security' ?'nav-tab-active':''; ?>">&#128274; Seguridad</a>
                <a href="?page=arsys-webftp-settings&tab=info"     class="nav-tab <?php echo $tab==='info'     ?'nav-tab-active':''; ?>">&#8505; Info del plugin</a>
            </nav>

            <?php if ( $tab === 'sftp' ) : ?>
                <?php if ( isset($_GET['saved']) ) : ?>
                    <div class="notice notice-success is-dismissible"><p>Credenciales guardadas correctamente.</p></div>
                <?php endif; ?>
                <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
                    <?php wp_nonce_field( 'awftp_save_credentials', 'awftp_credentials_nonce' ); ?>
                    <input type="hidden" name="action" value="awftp_save_credentials" />
                    <table class="form-table" role="presentation">
                        <tr><th><label for="awftp_host">Host SFTP</label></th><td>
                            <input type="text" name="awftp_host" id="awftp_host" class="regular-text" value="<?php echo esc_attr($creds['host']??''); ?>" placeholder="sftp.arsys.es" required />
                        </td></tr>
                        <tr><th><label for="awftp_port">Puerto</label></th><td>
                            <input type="number" name="awftp_port" id="awftp_port" class="small-text" value="<?php echo esc_attr($creds['port']??22); ?>" min="1" max="65535" />
                        </td></tr>
                        <tr><th><label for="awftp_username">Usuario SFTP</label></th><td>
                            <input type="text" name="awftp_username" id="awftp_username" class="regular-text" value="<?php echo esc_attr($creds['username']??''); ?>" autocomplete="off" required />
                        </td></tr>
                        <tr><th><label for="awftp_password">Contrasena SFTP</label></th><td>
                            <input type="password" name="awftp_password" id="awftp_password" class="regular-text" value="" autocomplete="new-password" />
                            <p class="description">Dejala en blanco para mantener la guardada.</p>
                        </td></tr>
                        <tr><th><label for="awftp_root_path">Directorio raiz</label></th><td>
                            <input type="text" name="awftp_root_path" id="awftp_root_path" class="regular-text" value="<?php echo esc_attr($creds['root_path']??'/'); ?>" placeholder="/home/usuario/public_html" />
                            <p class="description">Ruta base de navegacion.</p>
                        </td></tr>
                        <tr><th colspan="2"><hr /><strong>Autenticacion por clave SSH (opcional, recomendado)</strong></th></tr>
                        <tr><th><label for="awftp_private_key">Clave privada SSH</label></th><td>
                            <textarea name="awftp_private_key" id="awftp_private_key" rows="8" cols="60" style="font-family:monospace;font-size:12px" placeholder="-----BEGIN RSA PRIVATE KEY-----&#10;...&#10;-----END RSA PRIVATE KEY-----"><?php echo esc_textarea( ! empty($creds['private_key']) ? '*** clave guardada (pega una nueva para cambiarla) ***' : '' ); ?></textarea>
                            <p class="description">Pega aqui tu clave privada SSH en formato PEM. Si se configura, se usara en lugar de la contrasena. <strong>Mas seguro que contrasena.</strong></p>
                        </td></tr>
                        <tr><th><label for="awftp_key_passphrase">Passphrase de la clave</label></th><td>
                            <input type="password" name="awftp_key_passphrase" id="awftp_key_passphrase" class="regular-text" value="" autocomplete="new-password" />
                            <p class="description">Solo si tu clave privada tiene passphrase. Dejala en blanco si no la tiene.</p>
                        </td></tr>
                    </table>
                    <h2>Prueba de conexion</h2>
                    <p>
                        <button type="button" id="awftp-test-connection" class="button button-secondary">Probar conexion SFTP</button>
                        <span id="awftp-test-result" style="margin-left:12px;font-weight:600;"></span>
                    </p>
                    <?php submit_button( __( 'Guardar credenciales', 'arsys-webftp' ) ); ?>
                </form>

                <hr />
                <h2>Actualizaciones</h2>
                <p>Version instalada: <strong><?php echo AWFTP_VERSION; ?></strong></p>
                <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
                    <?php wp_nonce_field( 'awftp_force_check', '_wpnonce' ); ?>
                    <input type="hidden" name="action" value="awftp_force_update_check" />
                    <?php if ( isset($_GET['update_checked']) ) : ?>
                        <div class="notice notice-success is-dismissible"><p>Cache de actualizaciones limpiada. WordPress comprobara la nueva version en breve.</p></div>
                    <?php endif; ?>
                    <p>
                        <button type="submit" class="button button-secondary">Forzar comprobacion de actualizaciones</button>
                        <span style="margin-left:10px;color:#6b7280;font-size:13px">Limpia la cache y fuerza a WordPress a consultar GitHub ahora mismo.</span>
                    </p>
                </form>

            <?php elseif ( $tab === 'log' ) : ?>
                <div id="awftp-log-section">
                    <div class="awftp-log-filters">
                        <div>
                            <label>Accion</label>
                            <select id="awftp-log-filter-action">
                                <option value="">Todas</option>
                                <?php foreach(['login','logout','list','download','upload','edit','delete','rename','create_file','create_dir','search'] as $a): ?>
                                    <option value="<?php echo $a; ?>"><?php echo AWFTP_Activity_Log::action_label($a); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label>Usuario</label>
                            <input type="text" id="awftp-log-filter-user" placeholder="nombre..." style="width:140px" />
                        </div>
                        <div>
                            <label>Desde</label>
                            <input type="date" id="awftp-log-date-from" />
                        </div>
                        <div>
                            <label>Hasta</label>
                            <input type="date" id="awftp-log-date-to" />
                        </div>
                        <div style="padding-top:20px">
                            <button id="awftp-log-btn-filter" class="button button-secondary">Filtrar</button>
                            <button id="awftp-log-btn-reset"  class="button button-secondary">Limpiar</button>
                        </div>
                        <div style="padding-top:20px;margin-left:auto">
                            <button id="awftp-log-btn-clear" class="button awftp-btn-danger">Vaciar log</button>
                        </div>
                    </div>
                    <table class="awftp-log-table widefat">
                        <thead><tr>
                            <th>Fecha</th><th>Usuario</th><th>Accion</th><th>Ruta</th><th>Extra</th><th>IP</th>
                        </tr></thead>
                        <tbody id="awftp-log-body">
                            <tr><td colspan="6" style="text-align:center;padding:20px;color:#6b7280"><span class="awftp-spinner"></span> Cargando...</td></tr>
                        </tbody>
                    </table>
                    <div class="awftp-log-pagination" id="awftp-log-pagination"></div>
                </div>

            <?php elseif ( $tab === 'users' ) : ?>
                <h2>Usuarios con acceso a WebFTP</h2>
                <p>Pueden acceder los usuarios con rol <strong>Administrador</strong>:</p>
                <ul>
                    <?php foreach ( get_users(['role'=>'administrator','fields'=>['display_name','user_login']]) as $u ) {
                        printf('<li>&#128100; <strong>%s</strong> <code>(%s)</code></li>', esc_html($u->display_name), esc_html($u->user_login));
                    } ?>
                </ul>
                <p class="description">Para cambiar los permisos de acceso usa el filtro <code>awftp_required_capability</code> en tu tema o plugin.</p>
            <?php elseif ( $tab === 'security' ) : ?>
                <h2>Seguridad en subida de archivos</h2>
                <p>Controla que tipos de archivo se pueden subir a traves del explorador WebFTP.</p>

                <div class="notice notice-info inline">
                    <p>
                        <strong>Por defecto desactivado</strong> — el comportamiento es identico a versiones anteriores.
                        Activa la lista negra solo si necesitas restringir las subidas.
                    </p>
                </div>

                <table class="form-table" role="presentation">
                    <tr>
                        <th>Lista negra de extensiones</th>
                        <td>
                            <label>
                                <input type="checkbox" id="awftp-blacklist-enabled"
                                    <?php checked( AWFTP_Upload_Security::is_enabled() ); ?> />
                                <strong>Activar validacion de extensiones al subir archivos</strong>
                            </label>
                            <p class="description">
                                Cuando esta activado, los archivos con extensiones de la lista seran rechazados.<br>
                                Estado actual: <strong><?php echo AWFTP_Upload_Security::is_enabled() ? '<span style="color:#057a55">ACTIVADO</span>' : '<span style="color:#6b7280">DESACTIVADO</span>'; ?></strong>
                            </p>
                        </td>
                    </tr>
                    <tr id="awftp-blacklist-row" <?php echo AWFTP_Upload_Security::is_enabled() ? '' : 'style="opacity:.5"'; ?>>
                        <th><label for="awftp-blacklist-extensions">Extensiones bloqueadas</label></th>
                        <td>
                            <textarea id="awftp-blacklist-extensions" rows="12" cols="30"
                                style="font-family:monospace;font-size:12px;resize:vertical"
                                placeholder="php&#10;exe&#10;sh..."><?php echo esc_textarea( AWFTP_Upload_Security::get_blacklist_as_text() ); ?></textarea>
                            <p class="description">Una extension por linea, sin punto. Ejemplo: <code>php</code></p>
                        </td>
                    </tr>
                </table>

                <hr />
                <h2>Limite de tamano para edicion de archivos</h2>
                <p>Evita cargar archivos muy grandes en el editor (logs, dumps...) que podrian agotar la memoria del servidor.</p>

                <table class="form-table" role="presentation">
                    <tr>
                        <th>Limite de edicion</th>
                        <td>
                            <label>
                                <input type="checkbox" id="awftp-max-edit-enabled"
                                    <?php checked( AWFTP_Upload_Security::is_max_edit_enabled() ); ?> />
                                <strong>Activar limite de tamano para edicion</strong>
                            </label>
                            <p class="description">
                                Estado actual: <strong><?php echo AWFTP_Upload_Security::is_max_edit_enabled()
                                    ? '<span style="color:#057a55">ACTIVADO (' . AWFTP_Upload_Security::get_max_edit_mb() . ' MB)</span>'
                                    : '<span style="color:#6b7280">DESACTIVADO</span>'; ?></strong>
                            </p>
                        </td>
                    </tr>
                    <tr id="awftp-max-edit-row" <?php echo AWFTP_Upload_Security::is_max_edit_enabled() ? '' : 'style="opacity:.5"'; ?>>
                        <th><label for="awftp-max-edit-mb">Tamano maximo (MB)</label></th>
                        <td>
                            <input type="number" id="awftp-max-edit-mb" value="<?php echo esc_attr( AWFTP_Upload_Security::get_max_edit_mb() ); ?>"
                                min="1" max="50" style="width:80px" /> MB
                            <p class="description">Entre 1 y 50 MB. Por defecto: 2 MB.</p>
                        </td>
                    </tr>
                </table>

                <hr />
                <h2>Timeout en busqueda recursiva</h2>
                <p>Limita el tiempo de busqueda en directorios muy grandes para evitar bloqueos del servidor.</p>

                <table class="form-table" role="presentation">
                    <tr>
                        <th>Timeout de busqueda</th>
                        <td>
                            <label>
                                <input type="checkbox" id="awftp-search-timeout-enabled"
                                    <?php checked( AWFTP_Upload_Security::is_search_timeout_enabled() ); ?> />
                                <strong>Activar timeout en busqueda recursiva</strong>
                            </label>
                            <p class="description">
                                Si se supera el tiempo limite, se muestran los resultados parciales encontrados hasta ese momento.<br>
                                Estado actual: <strong><?php echo AWFTP_Upload_Security::is_search_timeout_enabled()
                                    ? '<span style="color:#057a55">ACTIVADO (' . AWFTP_Upload_Security::get_search_timeout_secs() . ' seg)</span>'
                                    : '<span style="color:#6b7280">DESACTIVADO</span>'; ?></strong>
                            </p>
                        </td>
                    </tr>
                    <tr id="awftp-search-timeout-row" <?php echo AWFTP_Upload_Security::is_search_timeout_enabled() ? '' : 'style="opacity:.5"'; ?>>
                        <th><label for="awftp-search-timeout-secs">Tiempo maximo (segundos)</label></th>
                        <td>
                            <input type="number" id="awftp-search-timeout-secs" value="<?php echo esc_attr( AWFTP_Upload_Security::get_search_timeout_secs() ); ?>"
                                min="5" max="60" style="width:80px" /> segundos
                            <p class="description">Entre 5 y 60 segundos. Por defecto: 10 segundos.</p>
                        </td>
                    </tr>
                </table>

                <p>
                    <button type="button" id="awftp-save-security" class="button button-primary">
                        Guardar configuracion de seguridad
                    </button>
                    <span id="awftp-security-result" style="margin-left:12px;font-weight:600;"></span>
                </p>

                <hr />
                <h2>Resumen de seguridad activa</h2>
                <table class="widefat" style="max-width:700px">
                    <thead><tr><th>Medida</th><th>Estado</th></tr></thead>
                    <tbody>
                        <tr><td>Cifrado AES-256-CBC de credenciales SFTP</td><td><span style="color:#057a55">&#10003; Activo</span></td></tr>
                        <tr><td>Autenticacion por clave privada SSH</td><td><span style="color:#057a55">&#10003; Disponible</span></td></tr>
                        <tr><td>Rate limiting: bloqueo tras 5 intentos fallidos</td><td><span style="color:#057a55">&#10003; Activo (15 min)</span></td></tr>
                        <tr><td>Rotacion de token de sesion</td><td><span style="color:#057a55">&#10003; Activo</span></td></tr>
                        <tr><td>Headers HTTP de seguridad (CSP, X-Frame...)</td><td><span style="color:#057a55">&#10003; Activo</span></td></tr>
                        <tr><td>Proteccion path traversal SFTP</td><td><span style="color:#057a55">&#10003; Activo</span></td></tr>
                        <tr><td>Lista negra de extensiones en subidas</td>
                            <td><?php echo AWFTP_Upload_Security::is_enabled()
                                ? '<span style="color:#057a55">&#10003; Activo</span>'
                                : '<span style="color:#6b7280">&#8212; Desactivado</span>'; ?>
                            </td>
                        </tr>
                        <tr><td>Limite de tamano para edicion</td>
                            <td><?php echo AWFTP_Upload_Security::is_max_edit_enabled()
                                ? '<span style="color:#057a55">&#10003; Activo (' . AWFTP_Upload_Security::get_max_edit_mb() . ' MB)</span>'
                                : '<span style="color:#6b7280">&#8212; Desactivado</span>'; ?>
                            </td>
                        </tr>
                        <tr><td>Timeout busqueda recursiva</td>
                            <td><?php echo AWFTP_Upload_Security::is_search_timeout_enabled()
                                ? '<span style="color:#057a55">&#10003; Activo (' . AWFTP_Upload_Security::get_search_timeout_secs() . ' seg)</span>'
                                : '<span style="color:#6b7280">&#8212; Desactivado</span>'; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>

            <?php elseif ( $tab === 'info' ) : ?>

                <h2>&#8505; Arsys WebFTP <span style="font-weight:400;color:#6b7280">v<?php echo AWFTP_VERSION; ?></span></h2>
                <p style="color:#6b7280;margin-bottom:24px">Explorador SFTP integrado en WordPress. Sin dependencias externas.</p>

                <!-- Explorador SFTP -->
                <h3 style="border-bottom:2px solid #e5e7eb;padding-bottom:8px">&#128193; Explorador de archivos</h3>
                <table class="widefat" style="max-width:800px;margin-bottom:24px">
                    <thead><tr><th>Funcionalidad</th><th>Descripcion</th></tr></thead>
                    <tbody>
                        <tr><td>&#128193; Navegacion por directorios</td><td>Navega por la estructura de carpetas del servidor SFTP</td></tr>
                        <tr><td>&#9889; Breadcrumb clickable</td><td>Barra de ruta con navegacion directa a cualquier nivel</td></tr>
                        <tr><td>&#11014; Subida de archivos</td><td>Subida multiple con barra de progreso en tiempo real</td></tr>
                        <tr><td>&#11015; Descarga de archivos</td><td>Descarga directa de cualquier archivo del servidor</td></tr>
                        <tr><td>&#128465; Eliminar</td><td>Elimina archivos y carpetas (recursivo en carpetas)</td></tr>
                        <tr><td>&#9998; Renombrar / Mover</td><td>Renombra archivos y carpetas o cambia su ubicacion</td></tr>
                        <tr><td>&#128196; Crear archivo</td><td>Crea un archivo vacio con el nombre que elijas</td></tr>
                        <tr><td>&#128193; Crear carpeta</td><td>Crea una nueva carpeta en el directorio actual</td></tr>
                        <tr><td>&#128203; Copiar archivos</td><td>Duplica archivos con ruta de destino personalizable</td></tr>
                        <tr><td>&#128274; Chmod</td><td>Cambia los permisos de archivos y carpetas (formato octal) con preview en tiempo real</td></tr>
                        <tr><td>&#9745; Seleccion multiple</td><td>Selecciona varios elementos para operar en lote (eliminar)</td></tr>
                    </tbody>
                </table>

                <!-- Drag & Drop -->
                <h3 style="border-bottom:2px solid #e5e7eb;padding-bottom:8px">&#128433; Drag &amp; Drop</h3>
                <table class="widefat" style="max-width:800px;margin-bottom:24px">
                    <thead><tr><th>Funcionalidad</th><th>Descripcion</th></tr></thead>
                    <tbody>
                        <tr><td>&#128433; Subir arrastrando</td><td>Arrastra archivos desde tu escritorio al explorador para subirlos</td></tr>
                        <tr><td>&#128257; Mover arrastrando</td><td>Arrastra archivos o carpetas sobre otra carpeta para moverlos</td></tr>
                    </tbody>
                </table>

                <!-- Editor -->
                <h3 style="border-bottom:2px solid #e5e7eb;padding-bottom:8px">&#9998; Editor de texto</h3>
                <table class="widefat" style="max-width:800px;margin-bottom:24px">
                    <thead><tr><th>Funcionalidad</th><th>Descripcion</th></tr></thead>
                    <tbody>
                        <tr><td>&#9998; Editor integrado</td><td>Edita archivos directamente en el navegador sin descargarlos</td></tr>
                        <tr><td>&#127752; Resaltado de sintaxis</td><td>CodeMirror con tema Dracula. Soporta PHP, HTML, CSS, JS, JSON, XML, YAML, SQL, Shell y mas</td></tr>
                        <tr><td>&#128190; Guardado directo</td><td>Guarda los cambios directamente en el servidor SFTP</td></tr>
                    </tbody>
                </table>

                <!-- Busqueda y vision -->
                <h3 style="border-bottom:2px solid #e5e7eb;padding-bottom:8px">&#128269; Busqueda y visualizacion</h3>
                <table class="widefat" style="max-width:800px;margin-bottom:24px">
                    <thead><tr><th>Funcionalidad</th><th>Descripcion</th></tr></thead>
                    <tbody>
                        <tr><td>&#128269; Busqueda de archivos</td><td>Busca por nombre en el directorio actual y subdirectorios (hasta 3 niveles, max 200 resultados)</td></tr>
                        <tr><td>&#128247; Vista previa de imagenes</td><td>Previsualiza JPG, PNG, GIF, SVG y WebP sin descargar. Muestra dimensiones y tamano</td></tr>
                    </tbody>
                </table>

                <!-- Log y actualizaciones -->
                <h3 style="border-bottom:2px solid #e5e7eb;padding-bottom:8px">&#128196; Log y actualizaciones</h3>
                <table class="widefat" style="max-width:800px;margin-bottom:24px">
                    <thead><tr><th>Funcionalidad</th><th>Descripcion</th></tr></thead>
                    <tbody>
                        <tr><td>&#128196; Log de actividad</td><td>Registro de todas las operaciones con usuario, accion, ruta, IP y fecha. Filtros por accion, usuario y fecha</td></tr>
                        <tr><td>&#128257; Auto-actualizacion</td><td>Detecta nuevas versiones desde GitHub Releases automaticamente cada 12 horas</td></tr>
                        <tr><td>&#128204; Forzar actualizacion</td><td>Boton para forzar la comprobacion de actualizaciones sin esperar</td></tr>
                        <tr><td>&#128736; Migraciones de BD</td><td>Las tablas de base de datos se crean y actualizan automaticamente al instalar o actualizar</td></tr>
                    </tbody>
                </table>

                <!-- Acceso y autenticacion -->
                <h3 style="border-bottom:2px solid #e5e7eb;padding-bottom:8px">&#128100; Acceso y autenticacion</h3>
                <table class="widefat" style="max-width:800px;margin-bottom:24px">
                    <thead><tr><th>Funcionalidad</th><th>Descripcion</th></tr></thead>
                    <tbody>
                        <tr><td>&#128100; Login con usuario WP</td><td>Acceso mediante usuario y contrasena de WordPress. Solo administradores</td></tr>
                        <tr><td>&#128274; Sesion propia</td><td>Token de sesion independiente de la sesion de WordPress. Duracion: 8 horas</td></tr>
                        <tr><td>&#128273; Clave privada SSH</td><td>Autenticacion por clave privada SSH como alternativa mas segura a la contrasena</td></tr>
                    </tbody>
                </table>

                <!-- Requisitos -->
                <h3 style="border-bottom:2px solid #e5e7eb;padding-bottom:8px">&#9881; Requisitos tecnicos</h3>
                <table class="widefat" style="max-width:800px;margin-bottom:24px">
                    <thead><tr><th>Requisito</th><th>Valor</th></tr></thead>
                    <tbody>
                        <tr><td>WordPress</td><td>6.0 o superior (instalado: <?php echo get_bloginfo('version'); ?>)</td></tr>
                        <tr><td>PHP</td><td>7.4 o superior (instalado: <?php echo PHP_VERSION; ?>)</td></tr>
                        <tr><td>Extension PHP</td><td>ssh2 (estado: <strong><?php echo extension_loaded('ssh2') ? '<span style="color:#057a55">&#10003; Disponible</span>' : '<span style="color:#e02424">&#10007; No disponible</span>'; ?></strong>)</td></tr>
                        <tr><td>Extension PHP</td><td>openssl para cifrado AES (estado: <strong><?php echo extension_loaded('openssl') ? '<span style="color:#057a55">&#10003; Disponible</span>' : '<span style="color:#e02424">&#10007; No disponible</span>'; ?></strong>)</td></tr>
                        <tr><td>Repositorio</td><td><a href="https://github.com/sarro/PluginWPWebFTP" target="_blank">github.com/sarro/PluginWPWebFTP</a></td></tr>
                        <tr><td>Autor</td><td>Arsys (IONOS Group)</td></tr>
                    </tbody>
                </table>

            <?php endif; ?>
        </div>

        <script>
        jQuery(function($){
            // Test conexion
            $('#awftp-test-connection').on('click',function(){
                var $btn=$(this),$r=$('#awftp-test-result');
                $btn.prop('disabled',true).text('Conectando...');$r.text('').css('color','');
                $.post(ajaxurl,{action:'awftp_test_connection',nonce:'<?php echo wp_create_nonce("awftp_nonce"); ?>',
                    host:$('#awftp_host').val(),port:$('#awftp_port').val(),username:$('#awftp_username').val(),password:$('#awftp_password').val()
                },function(res){
                    if(res.success)$r.text('OK: '+res.data.message).css('color','#057a55');
                    else $r.text('Error: '+res.data.message).css('color','#e02424');
                }).always(function(){$btn.prop('disabled',false).text('Probar conexion SFTP');});
            });

            // Log
            var logPage=1,logAction='',logUser='',logFrom='',logTo='';
            function loadLog(page){
                logPage=page||1;
                $('#awftp-log-body').html('<tr><td colspan="6" style="text-align:center;padding:20px"><span class="awftp-spinner"></span></td></tr>');
                $.post(ajaxurl,{action:'awftp_get_log',nonce:'<?php echo wp_create_nonce("awftp_nonce"); ?>',
                    page:logPage,filter_action:logAction,filter_user:logUser,date_from:logFrom,date_to:logTo
                },function(res){
                    if(!res.success){$('#awftp-log-body').html('<tr><td colspan="6">Error al cargar el log.</td></tr>');return;}
                    var d=res.data,$b=$('#awftp-log-body');$b.empty();
                    if(!d.entries||!d.entries.length){$b.html('<tr><td colspan="6" style="text-align:center;padding:20px;color:#6b7280">Sin registros</td></tr>');return;}
                    $.each(d.entries,function(i,e){
                        var date=new Date(e.created_at.replace(' ','T')).toLocaleString('es-ES',{dateStyle:'short',timeStyle:'short'});
                        $b.append('<tr><td>'+date+'</td><td>'+$('<span>').text(e.username).html()+'</td><td>'+$('<span>').text(e.action).html()+'</td><td class="awftp-log-path">'+$('<span>').text(e.path||'').html()+'</td><td>'+$('<span>').text(e.extra||'').html()+'</td><td>'+$('<span>').text(e.ip).html()+'</td></tr>');
                    });
                    var $p=$('#awftp-log-pagination');$p.empty();
                    $p.append('<span>Total: '+d.total+' registros</span>');
                    if(d.pages>1){
                        if(d.page>1)$p.append(' <button class="button button-small awftp-log-prev">Anterior</button> ');
                        $p.append('<span>Pag. '+d.page+' / '+d.pages+'</span>');
                        if(d.page<d.pages)$p.append(' <button class="button button-small awftp-log-next">Siguiente</button>');
                    }
                });
            }
            $('#awftp-log-btn-filter').on('click',function(){logAction=$('#awftp-log-filter-action').val();logUser=$('#awftp-log-filter-user').val();logFrom=$('#awftp-log-date-from').val();logTo=$('#awftp-log-date-to').val();loadLog(1);});
            $('#awftp-log-btn-reset').on('click',function(){$('#awftp-log-filter-action').val('');$('#awftp-log-filter-user').val('');$('#awftp-log-date-from').val('');$('#awftp-log-date-to').val('');logAction=logUser=logFrom=logTo='';loadLog(1);});
            $(document).on('click','.awftp-log-prev',function(){loadLog(logPage-1);});
            $(document).on('click','.awftp-log-next',function(){loadLog(logPage+1);});
            $('#awftp-log-btn-clear').on('click',function(){
                if(!confirm('Vaciar el log de actividad? Esta accion no se puede deshacer.'))return;
                $.post(ajaxurl,{action:'awftp_clear_log',nonce:'<?php echo wp_create_nonce("awftp_nonce"); ?>'},function(res){
                    if(res.success){loadLog(1);alert(res.data.message);}
                });
            });
            if($('#awftp-log-body').length) loadLog(1);

            // Seguridad: toggles
            $('#awftp-blacklist-enabled').on('change',function(){
                $('#awftp-blacklist-row').css('opacity',$(this).is(':checked')?'1':'.5');
            });
            $('#awftp-max-edit-enabled').on('change',function(){
                $('#awftp-max-edit-row').css('opacity',$(this).is(':checked')?'1':'.5');
            });
            $('#awftp-search-timeout-enabled').on('change',function(){
                $('#awftp-search-timeout-row').css('opacity',$(this).is(':checked')?'1':'.5');
            });

            // Seguridad: guardar toda la configuracion
            $('#awftp-save-security').on('click', function(){
                var $btn=$(this),$r=$('#awftp-security-result');
                $btn.prop('disabled',true).text('Guardando...');
                $r.text('').css('color','');
                $.post(ajaxurl,{
                    action:'awftp_save_upload_security',
                    nonce:'<?php echo wp_create_nonce("awftp_nonce"); ?>',
                    blacklist_enabled:     $('#awftp-blacklist-enabled').is(':checked')?1:0,
                    extensions:            $('#awftp-blacklist-extensions').val(),
                    max_edit_enabled:      $('#awftp-max-edit-enabled').is(':checked')?1:0,
                    max_edit_mb:           $('#awftp-max-edit-mb').val(),
                    search_timeout_enabled:$('#awftp-search-timeout-enabled').is(':checked')?1:0,
                    search_timeout_secs:   $('#awftp-search-timeout-secs').val()
                },function(res){
                    if(res.success) $r.html('&#10003; '+res.data.message).css('color','#057a55');
                    else $r.html('&#10007; '+res.data.message).css('color','#e02424');
                }).always(function(){
                    $btn.prop('disabled',false).text('Guardar configuracion de seguridad');
                    setTimeout(function(){location.reload();},1500);
                });
            });

        });
        </script>
        <?php
    }

    public function handle_save_credentials(): void {
        check_admin_referer( 'awftp_save_credentials', 'awftp_credentials_nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Acceso no autorizado.' );
        $existing = AWFTP_Credentials::get();

        // Contrasena: mantener la guardada si no se envia nueva
        $password = $_POST['awftp_password'] ?? '';
        if ( empty($password) && ! empty($existing['password']) ) $password = $existing['password'];

        // Clave privada: mantener la guardada si el campo contiene el placeholder
        $private_key    = $_POST['awftp_private_key']    ?? '';
        $key_passphrase = $_POST['awftp_key_passphrase'] ?? '';
        if ( str_contains( $private_key, '*** clave guardada' ) ) {
            $private_key    = $existing['private_key']    ?? '';
            $key_passphrase = ! empty($key_passphrase) ? $key_passphrase : ( $existing['key_passphrase'] ?? '' );
        }

        AWFTP_Credentials::save([
            'host'           => sanitize_text_field( $_POST['awftp_host']      ?? '' ),
            'port'           => absint( $_POST['awftp_port'] ?? 22 ),
            'username'       => sanitize_text_field( $_POST['awftp_username']  ?? '' ),
            'password'       => $password,
            'root_path'      => sanitize_text_field( $_POST['awftp_root_path'] ?? '/' ),
            'private_key'    => trim( $private_key ),
            'key_passphrase' => $key_passphrase,
        ]);
        wp_redirect( admin_url('admin.php?page=arsys-webftp-settings&saved=1') );
        exit;
    }

    public static function cleanup_sessions(): void {
        AWFTP_Session::cleanup_expired();
    }
}
